# Migração Java/Kotlin -> Rust (CatCore)

Novo módulo `:CatCore` (`CatCore/rust` = crate `catcore`, compilado por cargo-ndk como `libcatcore.so`,
mesmo esquema do PetLib). Ponte JNI: `CatCoreNative` (módulo CatCore) + fachada `CatCore` (módulo CatLauncher).

## Agora em Rust
| Área | Rust | Kotlin/Java removido ou reduzido |
|---|---|---|
| Versões | `versions.rs` (parse/merge de unlisted/ordenação/tipo), `version.rs` (comparação) | parse+merge em `MinecraftVersions.kt`, `when` de tipo em `_VersionManifest.kt` |
| Bibliotecas | `manifest.rs` (regras, caminho, filtro, substituição jna/oshi/asm, dedup, classpath, LWJGL) | `LibSortFix.kt`, `_LibraryReplacement.kt` apagados; `UniqueLibraries.kt`, `artifactToPath`, `processLibraries` viraram delegações |
| Instalação (plano) | `plan.rs` (URLs/alvos/sha1/size de bibliotecas e assets) | laços de `loadLibraryDownloads` / `loadAssetsDownload` |
| Inicialização | `launch.rs` (classpath, args JVM, args do jogo, split com aspas) | ~250 linhas de `LaunchArgs.kt` (+ `insertJSONValueList`) |
| Runtimes | `runtime.rs` (release, listar/ordenar, exato/mais próximo, tar.xz, unpack200, pós-instalação) | `RuntimesManager.kt` (Commons Compress, parse de `release`, `findNearestPositive`, `RankedValue`) |
| Arquivos | `hash.rs` (SHA-1) | `compareSHA1` |

## Continua em Kotlin (de propósito)
Transporte HTTP (mirrors BMCL, retry, progresso, coroutines), instaladores Forge/NeoForge/Fabric/OptiFine,
contas/Yggdrasil, UI, e a JVM/runtimes em si. Os modelos Gson (`GameManifest.java`) ficam como estão.

## Observações
- Não foi possível compilar nem rodar nada neste ambiente (sem Rust/Android SDK). Rode `cargo test` em `CatCore/rust`
  e gere o `Cargo.lock` (`cargo generate-lockfile`) antes do primeiro build.
- Ajustes de comportamento: `libfreetype`/xawt em JDK8 agora usam `jre/lib` (antes `"/jre"+"lib"` = `/jrelib`);
  entradas tar com `..` são rejeitadas; modo de arquivo do tar é preservado; versões ocultas duplicadas são ignoradas.

## Etapa 2: motor de downloads em Rust (STATUS: escrito, NÃO validado)

Novos: `rust/src/net.rs` (HTTP de um arquivo: candidatos/mirrors em ordem, 4xx = próximo candidato,
5 tentativas por fonte, redirecionamentos manuais, `Range`/`If-Range`, SHA-1 em streaming, `.part` + rename
atômico, bytes devolvidos em retentativa), `rust/src/batch.rs` (workers paralelos, rodadas de retentativa,
progresso a cada 100 ms, cancelamento, disjuntor de falhas sistêmicas), exports JNI `downloadBatch` & cia,
`game/version/download/NativeBatch.kt` e o desvio em `TaskBatch.kt`.

**Chave:** `CatCore.nativeDownloads` (padrão `false`). Com `false` vale o motor Kotlin legado, que NÃO foi removido.
Os testes de `net.rs`/`batch.rs` (servidor HTTP local: sucesso, SHA-1 errado, mirror após 404, retry em 5xx,
cancelamento, 200 arquivos em paralelo, disjuntor) rodam no CI (`cargo test`), mas nunca foram executados.

Só depois de `cargo test` verde + instalação real (vanilla antigo/recente, Forge, Fabric, NeoForge, Quilt, OptiFine)
com a chave ligada, é seguro apagar: `BatchDownloader`, `DownloadStats`, `FileDownloader`, `FileSink`,
parte de `Fetcher` (mover `HttpResultException` antes), `DownloadTask.toRequest`, o ramo legado de `TaskBatch`.

Ainda no motor legado: `NetWorkUtils` (`DownloadEngine.download` de arquivo único) e `YggdrasilApi`.
Mirrors BMCL: a ordenação/substituição de URLs (`mapBMCLMirrorUrls`, depende das configurações) continua em Kotlin;
o Rust executa a lista de candidatos. Diferença: `acceptFailure` é avaliado após o lote.
