# Relatório de desempenho — Cat Launcher, fase 2

## RESULTADOS: AINDA NÃO MEDIDOS

Nenhum teste foi executado. O ambiente de trabalho não tinha Android SDK, Gradle, aparelho nem emulador,
então **não existe nenhum número de "antes" ou "depois"** e nenhuma meta (tela inicial < 1 s, jogável ≈ 20 s) foi verificada.
Os campos abaixo ficam vazios de propósito e serão preenchidos por `tools/benchmark/compare_reports.py` com dados reais.

| Métrica | Original | Otimizada |
|---|---|---|
| Tela inicial pronta (processo → 1º quadro) | não medido | não medido |
| Abertura das telas (Configurações, Mods, …) | não medido | não medido |
| Preparo do ambiente Java | não medido | não medido |
| Bibliotecas (dlopen) | não medido | não medido |
| Criação da JVM → 1º log | não medido | não medido |
| Total Jogar → jogável, 1ª inicialização | não medido | não medido |
| Total Jogar → jogável, com cache | não medido | não medido |
| RAM (RSS/PSS) e CPU até jogável | não medido | não medido |
| Perfis JVM (auto / outros) | não medido | não medido |

## Como obter resultados válidos
1. Compile a **versão original** (o ZIP `Cat*.bin` que você enviou) e a **otimizada** (com estes arquivos), com a mesma configuração.
2. No mesmo aparelho, mesma instância/mundo, bateria > 50 %, temperatura estabilizada, mesmo perfil JVM:
   `tools/benchmark/run_benchmark.sh original 5` e depois `… otimizada 5` (use `--tap X,Y` para automatizar o toque em Jogar).
   A original **não tem** as sondas: instale nela só as 4 classes `startup/*` + os ganchos (ou meça-a só por `am start -W` e cronômetro externo e declare isso).
3. Repita por perfil JVM (Configurações → perfil de desempenho). A 1ª execução de cada rótulo é classificada como `primeira_inicializacao`; as seguintes, `inicializacao_seguinte` (sem root o cache de páginas do sistema não é limpo, então a "primeira" é de app, não de aparelho recém-ligado).
4. `python3 tools/benchmark/compare_reports.py bench_out/otimizada/benchmark/runs --baseline original --candidate otimizada`
   (precisa dos `runs` das duas versões na mesma pasta). Grupos com n < 3 são sinalizados como amostra pequena.

## Limitações conhecidas
- Código não compilado nem testado (ver `ALTERACOES_FASE2_BENCHMARK.md`). Erros de compilação são possíveis.
- Gatilho "jogável" por captura do cursor é uma hipótese sólida, mas não validada em Forge/Fabric/Quilt/versões antigas.
- RAM/CPU são do processo `:game` (onde roda a JVM), não do launcher; CPU em "% de um núcleo" (pode passar de 100 %).
- O medidor de log adiciona uma thread de leitura (150 ms) e uma de amostragem (1 s) até o jogável; custo esperado desprezível, mas não medido.
- Metas de 1 s / 20 s dependem de hardware, versão e mods; nenhuma foi confirmada.
