/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.

package com.movtery.zalithlauncher.startup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameLogMatcherTest {
    @Test
    fun recognizesStagesFromRealisticLines() {
        assertEquals(LaunchStage.JVM_RUNNING, GameLogMatcher.match("[12:00:01] [main/INFO]: Something"))
        assertEquals(LaunchStage.MODLOADER_BEGIN, GameLogMatcher.match("[12:00:01] [main/INFO]: Loading 42 mods:"))
        assertEquals(LaunchStage.MODLOADER_BEGIN, GameLogMatcher.match("[12:00:01] [main/INFO]: Loading Minecraft 1.20.1 with Fabric Loader 0.15.0"))
        assertEquals(LaunchStage.MC_INIT, GameLogMatcher.match("[12:00:05] [Render thread/INFO]: Setting user: Steve"))
        assertEquals(LaunchStage.RESOURCES_LOADING, GameLogMatcher.match("[12:00:06] [Render thread/INFO]: Reloading ResourceManager: vanilla"))
        assertEquals(LaunchStage.WORLD_LOADING, GameLogMatcher.match("[12:00:20] [Server thread/INFO]: Preparing spawn area: 0%"))
    }

    @Test
    fun ignoresUnrelatedLines() {
        assertNull(GameLogMatcher.match("▷ Java arguments:"))
        assertNull(GameLogMatcher.match(""))
    }
}

class ProcStatsTest {
    @Test
    fun parsesRssAndCpuTicks() {
        assertEquals(204800L, ProcStats.parseRssKb("Name:\tjava\nVmRSS:\t  204800 kB\nThreads:\t9"))
        assertEquals(-1L, ProcStats.parseRssKb("Name:\tjava"))
        // utime=100, stime=50 -> 150
        assertEquals(150L, ProcStats.parseCpuTicks("1234 (ja va) S 1 2 3 4 5 6 7 8 9 10 100 50 0 0"))
        assertEquals(-1L, ProcStats.parseCpuTicks("garbage"))
    }
}

class RunAnalyzerTest {
    private val lines = listOf(
        "#HEADER\trunId=abc12345\u0001label=teste\u0001performanceProfile=auto",
        "1000\tPLAY_CLICK\t",
        "3000\tFILES_READY\t",
        "3500\tGAME_PROCESS_STARTED\t",
        "4000\tJVM_ENV_READY\t",
        "4600\tJAVA_LIBS_LOADED\t",
        "4800\tENGINE_LIBS_LOADED\t",
        "4900\tJVM_CREATE_BEGIN\t",
        "5400\tJVM_RUNNING\t",
        "9000\tMC_INIT\t",
        "15000\tWORLD_LOADING\t",
        "19000\tPLAYABLE\t",
        "4500\tDETAIL\tdlopen_runtime_count\t42",
        "2000\tSAMPLE\t100000\t0",
        "3000\tSAMPLE\t200000\t100",
        "19000\tSAMPLE\t400000\t1100"
    )

    @Test
    fun parsesHeaderMarksAndSamples() {
        val run = LaunchTimeline.parse(lines)
        assertNotNull(run)
        assertEquals("abc12345", run!!.runId)
        assertEquals("teste", run.header["label"])
        assertEquals(3, run.samples.size)
        assertTrue(run.marks.any { it.stage == "DETAIL:dlopen_runtime_count" && it.detail == "42" })
    }

    @Test
    fun computesPhasesAndTotalFromMarks() {
        val m = RunAnalyzer.analyze(LaunchTimeline.parse(lines)!!, ticksPerSecond = 100)
        assertEquals(18000L, m.totalToPlayableMs)
        assertEquals(2000L, m.phases["1_clique_ate_arquivos_prontos"])
        assertEquals(800L, m.phases["4_bibliotecas_total"])
        assertEquals(4000L, m.phases["10_mundo_carregando_ate_jogavel"])
        // MODLOADER_BEGIN / RESOURCES_LOADING não observados: "não medido", nunca zero inventado
        assertNull(m.phases["7_carregador_de_mods_ate_recursos"])
        assertEquals(400000L, m.rssPeakKb)
        assertEquals(42L, m.details["dlopen_runtime_count"])
    }

    @Test
    fun cpuUsesTickDeltasOverElapsedTime() {
        val m = RunAnalyzer.analyze(LaunchTimeline.parse(lines)!!, ticksPerSecond = 100)
        // (1100 ticks / 100) s = 11 s de CPU em 17 s de relógio ≈ 64.7 % de um núcleo
        assertEquals(64.7, m.cpuAvgPercentOfOneCore!!, 0.1)
    }

    @Test
    fun missingPlayableMeansNoTotal() {
        val m = RunAnalyzer.analyze(LaunchTimeline.parse(lines.filterNot { it.contains("PLAYABLE") })!!)
        assertNull(m.totalToPlayableMs)
    }
}
