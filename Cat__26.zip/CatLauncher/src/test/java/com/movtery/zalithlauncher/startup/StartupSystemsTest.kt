/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.startup

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

class ParallelLoaderTest {
    @Test
    fun parallelism_leavesOneCoreFree_andIsClamped() {
        assertEquals(1, ParallelLoader.computeParallelism(1, 2_000_000_000, false))
        assertEquals(3, ParallelLoader.computeParallelism(4, 2_000_000_000, false))
        assertEquals(4, ParallelLoader.computeParallelism(16, 2_000_000_000, false))
    }

    @Test
    fun parallelism_isReducedOnLowMemory() {
        assertEquals(2, ParallelLoader.computeParallelism(8, 100L * 1024 * 1024, false))
        assertEquals(2, ParallelLoader.computeParallelism(8, 4_000_000_000, true))
        // memória desconhecida (-1) não deve penalizar
        assertEquals(4, ParallelLoader.computeParallelism(8, -1L, false))
    }

    @Test
    fun mapParallel_keepsOrder_andNeverExceedsLimit() = runBlocking {
        val loader = ParallelLoader(3)
        val running = AtomicInteger(0)
        val peak = AtomicInteger(0)
        val result = loader.mapParallel((1..20).toList()) { n ->
            val now = running.incrementAndGet()
            peak.updateAndGet { maxOf(it, now) }
            delay(15)
            running.decrementAndGet()
            n * 2
        }
        assertEquals((1..20).map { it * 2 }, result)
        assertTrue("peak=${peak.get()}", peak.get() <= 3)
        assertTrue("should actually run in parallel, peak=${peak.get()}", peak.get() >= 2)
    }

    @Test
    fun mapParallel_propagatesFailure() {
        val loader = ParallelLoader(2)
        try {
            runBlocking {
                loader.mapParallel(listOf(1, 2, 3)) { if (it == 2) error("boom") else it }
            }
            fail("expected exception")
        } catch (e: IllegalStateException) {
            assertEquals("boom", e.message)
        }
    }
}

class FastStartupLoaderTest {
    private fun scope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Test
    fun respectsDependencies() = runBlocking {
        val log = CopyOnWriteArrayList<String>()
        val loader = FastStartupLoader(ParallelLoader(3))
            .add(StartupTask("c", dependsOn = listOf("a", "b")) { log.add("c") })
            .add(StartupTask("a") { delay(30); log.add("a") })
            .add(StartupTask("b") { delay(10); log.add("b") })
        loader.run(scope()).awaitDeferred()
        assertEquals("c", log.last())
        assertEquals(setOf("a", "b", "c"), log.toSet())
    }

    @Test
    fun independentTasksRunConcurrently() = runBlocking {
        val loader = FastStartupLoader(ParallelLoader(3))
        repeat(3) { i -> loader.add(StartupTask("t$i") { delay(200) }) }
        val start = System.nanoTime()
        loader.run(scope()).awaitDeferred()
        val ms = (System.nanoTime() - start) / 1_000_000
        // sequencial levaria >= 600 ms
        assertTrue("took $ms ms", ms < 500)
    }

    @Test
    fun deferredStartsOnlyAfterEssentialFinished_andDoesNotBlockReturn() = runBlocking {
        val log = CopyOnWriteArrayList<String>()
        val loader = FastStartupLoader(ParallelLoader(3))
            .add(StartupTask("ess") { delay(50); log.add("ess") })
            .add(StartupTask("def", StartupPriority.DEFERRED) { delay(50); log.add("def") })
        val exec = loader.run(scope())
        // run() devolve quando as essenciais terminam; a adiada ainda não terminou
        assertEquals(listOf("ess"), log.toList())
        exec.awaitDeferred()
        assertEquals(listOf("ess", "def"), log.toList())
    }

    @Test
    fun deferredFailureIsReportedAndDoesNotFailStartup() = runBlocking {
        val errors = CopyOnWriteArrayList<String>()
        val loader = FastStartupLoader(ParallelLoader(2), onDeferredError = { n, _ -> errors.add(n) })
            .add(StartupTask("ess") { })
            .add(StartupTask("def", StartupPriority.DEFERRED) { error("nope") })
        loader.run(scope()).awaitDeferred()
        assertEquals(listOf("def"), errors.toList())
    }

    @Test
    fun essentialFailureIsPropagated() {
        val loader = FastStartupLoader(ParallelLoader(2))
            .add(StartupTask("ess") { error("critical") })
            .add(StartupTask("other") { delay(20) })
        try {
            runBlocking { loader.run(scope()) }
            fail("expected exception")
        } catch (e: IllegalStateException) {
            assertEquals("critical", e.message)
        }
    }

    @Test
    fun detectsCycleUnknownDependencyAndEssentialOnDeferred() {
        fun failsWith(block: () -> Unit) = try { block(); fail("expected IllegalArgumentException") } catch (_: IllegalArgumentException) {} catch (_: IllegalStateException) {}
        failsWith {
            FastStartupLoader(ParallelLoader(1))
                .add(StartupTask("a", dependsOn = listOf("b")) {})
                .add(StartupTask("b", dependsOn = listOf("a")) {})
                .validate()
        }
        failsWith {
            FastStartupLoader(ParallelLoader(1)).add(StartupTask("a", dependsOn = listOf("x")) {}).validate()
        }
        failsWith {
            FastStartupLoader(ParallelLoader(1))
                .add(StartupTask("d", StartupPriority.DEFERRED) {})
                .add(StartupTask("e", dependsOn = listOf("d")) {})
                .validate()
        }
    }
}

class LazyLoadingTest {
    @Test
    fun factoryRunsOnlyOnce_evenWithConcurrentCalls() {
        val calls = AtomicInteger(0)
        val m = LazyModule("m") { calls.incrementAndGet(); Thread.sleep(20); "v" }
        assertFalse(m.isLoaded)
        val threads = (1..8).map { Thread { m.get() }.also { it.start() } }
        threads.forEach { it.join() }
        assertEquals(1, calls.get())
        assertTrue(m.isLoaded)
    }

    @Test
    fun nothingLoadsUntilNeeded_thenWarmUpLoadsTheRest_andFailureIsIsolated() = runBlocking {
        val registry = LazyModules()
        val a = AtomicInteger(0)
        val b = AtomicInteger(0)
        registry.register("a") { a.incrementAndGet(); "A" }
        registry.register("bad") { error("fail") }
        registry.register("b") { b.incrementAndGet(); "B" }
        assertEquals(0, a.get()); assertEquals(0, b.get())

        assertEquals("B", registry.get<String>("b")) // sob demanda
        val errors = CopyOnWriteArrayList<String>()
        registry.warmUpInBackground(CoroutineScope(SupervisorJob() + Dispatchers.Default), null) { n, _ -> errors.add(n) }!!.join()

        assertEquals(1, a.get()); assertEquals(1, b.get()) // b não recarregado
        assertEquals(listOf("bad"), errors.toList())
        assertNull(registry.warmUpInBackground(CoroutineScope(SupervisorJob()), null)) // só uma vez
    }
}

class SmartCacheTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun expected(vararg f: Triple<String, Long, String>) = f.map { ExpectedFile(it.first, it.second, it.third) }

    @Test
    fun fingerprintStore_roundTrip_andAppUpdateInvalidates() {
        val file = tmp.newFile("fp.txt")
        val s1 = FingerprintStore(file, "v1")
        s1.put("k", "abc"); s1.flush()
        assertEquals("abc", FingerprintStore(file, "v1").get("k"))
        assertNull(FingerprintStore(file, "v2").get("k")) // APK atualizado -> cache descartado
    }

    @Test
    fun fingerprintStore_corruptFileBehavesAsEmpty() {
        val file = tmp.newFile("fp.txt")
        file.writeBytes(byteArrayOf(0, 1, 2, -1, -2))
        assertNull(FingerprintStore(file, "v1").get("k"))
    }

    @Test
    fun directoryFingerprint_changesWhenFileModifiedAddedOrRemoved() {
        val dir = tmp.newFolder("comp")
        val f = java.io.File(dir, "a.jar").apply { writeText("hello") }
        val exp = expected(Triple("a.jar", 5L, "x"))
        val base = DirectoryFingerprint.compute(dir, exp, emptySet())
        assertEquals(base, DirectoryFingerprint.compute(dir, exp, emptySet())) // estável

        f.writeText("hello!") // tamanho muda
        val modified = DirectoryFingerprint.compute(dir, exp, emptySet())
        assertNotEquals(base, modified)

        java.io.File(dir, "extra.bin").writeText("x") // arquivo extra
        assertNotEquals(modified, DirectoryFingerprint.compute(dir, exp, emptySet()))
        // ... a menos que esteja na lista de ignorados (manifest.json/version)
        assertEquals(modified, DirectoryFingerprint.compute(dir, exp, setOf("extra.bin")))

        // manifesto novo (sha1 esperado diferente) invalida mesmo com arquivos iguais
        assertNotEquals(modified, DirectoryFingerprint.compute(dir, expected(Triple("a.jar", 6L, "y")), setOf("extra.bin")))
    }

    @Test
    fun memoryCache_evictsLeastRecentlyUsed_andRespectsBudget() {
        val cache = BoundedMemoryCache<String>(10) { it.length.toLong() }
        cache.put("a", "12345"); cache.put("b", "12345")
        cache.get("a") // a fica "recente"
        cache.put("c", "12345") // estoura -> remove b
        assertEquals("12345", cache.get("a"))
        assertNull(cache.get("b"))
        assertTrue(cache.sizeBytes <= 10)
        cache.put("huge", "x".repeat(50)) // maior que o cache: ignorado
        assertNull(cache.get("huge"))
    }

    @Test
    fun memoryCache_trimsUnderPressure_andLoadsOnce() {
        val cache = BoundedMemoryCache<String>(100) { it.length.toLong() }
        val loads = AtomicInteger(0)
        repeat(3) { cache.getOrLoad("k") { loads.incrementAndGet(); "x".repeat(40) } }
        assertEquals(1, loads.get())
        cache.put("k2", "y".repeat(40))
        cache.trimForLevel(BoundedMemoryCache.TRIM_MODERATE)
        assertTrue(cache.sizeBytes <= 25)
        cache.trimForLevel(BoundedMemoryCache.TRIM_COMPLETE)
        assertEquals(0, cache.count)
    }

    @Test
    fun defaultBudget_isBounded() {
        assertEquals(2L * 1024 * 1024, BoundedMemoryCache.defaultBudget(16L * 1024 * 1024))
        assertEquals(16L * 1024 * 1024, BoundedMemoryCache.defaultBudget(4096L * 1024 * 1024))
    }
}

class StartupTraceTest {
    @Test
    fun measuresFromOrigin_andReadyIsRecordedOnce() {
        var now = 1_000L
        val trace = StartupTrace({ now }, originMs = 400L)
        now = 1_500L
        val v = trace.measure("work") { now = 1_800L; 42 }
        assertEquals(42, v)
        now = 2_100L
        assertEquals(1_700L, trace.markReady())
        now = 9_999L
        assertEquals(1_700L, trace.markReady()) // segunda chamada não altera
        assertTrue(trace.report().contains("OK"))
        val work = trace.snapshot().first { it.name == "work" }
        assertEquals(300L, work.durationMs)
    }

    @Test
    fun reportFlagsAboveTarget() {
        var now = 0L
        val trace = StartupTrace({ now }, originMs = 0L)
        now = 3_500L
        trace.markReady()
        assertTrue(trace.report().contains("ABOVE TARGET"))
    }
}


/**
 * Porta das animações de entrada: começa fechada (abertura sem animação), reabre depois do
 * primeiro quadro e fecha de novo a cada nova abertura.
 */
class StartupAnimationGateTest {
    @Test
    fun startsSuppressed_soTheVeryFirstFrameHasNoEntryAnimation() {
        StartupAnimationGate.suppress()
        assertTrue(StartupAnimationGate.isSuppressed)
    }

    @Test
    fun release_reopensInternalAnimations() {
        StartupAnimationGate.suppress()
        StartupAnimationGate.release()
        assertFalse(StartupAnimationGate.isSuppressed)
    }

    @Test
    fun suppress_closesAgainOnWarmStart() {
        StartupAnimationGate.release()
        StartupAnimationGate.suppress()
        assertTrue(StartupAnimationGate.isSuppressed)
    }

    @Test
    fun releaseAfterFrames_withoutLooper_releasesImmediately() {
        // Em teste JVM não há Looper principal: a porta não pode ficar presa fechada.
        StartupAnimationGate.suppress()
        StartupAnimationGate.releaseAfterFrames()
        assertFalse(StartupAnimationGate.isSuppressed)
    }
}
