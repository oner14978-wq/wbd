#!/usr/bin/env python3
"""Compara relatórios de benchmark do Cat Launcher (runs/*.json puxados do aparelho).

Uso:
  python3 compare_reports.py PASTA_RUNS [--baseline ROTULO --candidate ROTULO]
  python3 compare_reports.py --selftest

Regras (para nunca inventar resultado):
  * só usa o que está nos JSONs; campo ausente/null = "n/d", nunca zero;
  * agrupa por (rótulo, perfil JVM, tipo de inicialização) e mostra n, mediana, mín e máx;
  * grupos com n < 3 são marcados "amostra pequena";
  * a variação % só é calculada quando os dois lados têm medição.
"""
import json, statistics, sys, tempfile, os, glob
from collections import defaultdict

PHASES = [
    ("total", "Total Jogar → mundo jogável"),
    ("1_clique_ate_arquivos_prontos", "Clique → arquivos prontos"),
    ("2_arquivos_prontos_ate_processo_jogo", "Arquivos prontos → processo :game"),
    ("3_preparo_ambiente_java", "Preparo do ambiente Java"),
    ("4_bibliotecas_total", "Bibliotecas (dlopen)"),
    ("6_jvm_criada_ate_primeiro_log", "JVM criada → primeiro log"),
    ("8_primeiro_log_ate_minecraft_iniciando", "Primeiro log → Minecraft iniciando"),
    ("9_minecraft_iniciando_ate_mundo_carregando", "Minecraft → mundo carregando"),
    ("10_mundo_carregando_ate_jogavel", "Mundo carregando → jogável"),
]

def load(folder):
    runs = []
    for f in sorted(glob.glob(os.path.join(folder, "**", "run_*.json"), recursive=True)):
        try:
            runs.append(json.load(open(f, encoding="utf-8")))
        except Exception as e:  # arquivo corrompido não derruba o relatório
            print(f"aviso: ignorando {f}: {e}", file=sys.stderr)
    return runs

def metric(run, key):
    if key == "total":
        return run.get("totalToPlayableMs")
    if key in ("rssAtPlayableKb", "rssPeakKb", "pssAtPlayableKb", "cpuAvgPercentOfOneCore", "cpuPeakPercentOfOneCore"):
        return run.get(key)
    return (run.get("phasesMs") or {}).get(key)

def stats(values):
    v = [x for x in values if x is not None]
    if not v:
        return None
    return {"n": len(v), "median": statistics.median(v), "min": min(v), "max": max(v)}

def fmt_s(ms):
    return "n/d" if ms is None else f"{ms/1000:.2f} s"

def group(runs):
    g = defaultdict(list)
    for r in runs:
        g[(r.get("label", "sem-rotulo"), r.get("performanceProfile", "?"), r.get("kind", "?"))].append(r)
    return g

def table(runs):
    out = ["| Versão | Perfil JVM | Tipo | n | " + " | ".join(n for _, n in PHASES[:1]) + " (mediana / mín–máx) | RAM jogável (RSS) | CPU média |",
           "|---|---|---|---|---|---|---|"]
    for (label, prof, kind), rs in sorted(group(runs).items()):
        t = stats([metric(r, "total") for r in rs])
        ram = stats([metric(r, "rssAtPlayableKb") for r in rs])
        cpu = stats([metric(r, "cpuAvgPercentOfOneCore") for r in rs])
        small = " ⚠ amostra pequena" if len(rs) < 3 else ""
        tt = "n/d" if not t else f"{fmt_s(t['median'])} / {fmt_s(t['min'])}–{fmt_s(t['max'])}"
        rr = "n/d" if not ram else f"{ram['median']/1024:.0f} MB"
        cc = "n/d" if not cpu else f"{cpu['median']:.0f}% de 1 núcleo"
        out.append(f"| {label} | {prof} | {kind} | {len(rs)}{small} | {tt} | {rr} | {cc} |")
    return "\n".join(out)

def compare(runs, base, cand):
    sel = lambda lab: [r for r in runs if r.get("label") == lab]
    b, c = sel(base), sel(cand)
    if not b or not c:
        return f"Sem dados para comparar: '{base}' tem {len(b)} execuções, '{cand}' tem {len(c)}."
    out = [f"### {base} → {cand}", "", "| Etapa | Tipo | " + base + " | " + cand + " | Variação |", "|---|---|---|---|---|"]
    for kind in ("primeira_inicializacao", "inicializacao_seguinte"):
        for key, name in PHASES:
            sb = stats([metric(r, key) for r in b if r.get("kind") == kind])
            sc = stats([metric(r, key) for r in c if r.get("kind") == kind])
            if sb is None and sc is None:
                continue
            delta = "n/d"
            if sb and sc and sb["median"] > 0:
                d = (sc["median"] - sb["median"]) / sb["median"] * 100
                delta = f"{d:+.1f}%"
            out.append(f"| {name} | {kind} | {fmt_s(sb and sb['median'])} | {fmt_s(sc and sc['median'])} | {delta} |")
    out.append("")
    out.append("Medianas por grupo. Execuções em condições diferentes (aparelho, temperatura, versão do jogo, mods, perfil JVM) NÃO são comparáveis.")
    return "\n".join(out)

def selftest():
    # DADOS SINTÉTICOS só para verificar o cálculo. NÃO são medições do Cat Launcher.
    d = tempfile.mkdtemp()
    def mk(label, kind, total, ram):
        return {"label": label, "performanceProfile": "auto", "kind": kind, "totalToPlayableMs": total,
                "rssAtPlayableKb": ram, "cpuAvgPercentOfOneCore": None, "phasesMs": {"3_preparo_ambiente_java": None}}
    for i, r in enumerate([mk("A", "primeira_inicializacao", 30000, 1024*1024), mk("A", "inicializacao_seguinte", 20000, 1024*1024),
                           mk("B", "primeira_inicializacao", 27000, 1024*1024), mk("B", "inicializacao_seguinte", 18000, 1024*1024)]):
        json.dump(r, open(os.path.join(d, f"run_{i}_x.json"), "w"))
    runs = load(d)
    assert len(runs) == 4
    assert stats([1, None, 3])["median"] == 2
    assert stats([None]) is None
    assert "-10.0%" in compare(runs, "A", "B")
    assert "n/d" in table(runs)  # CPU ausente = n/d, nunca 0
    assert "Sem dados" in compare(runs, "A", "Z")
    print("autoteste OK (dados sintéticos; não são medições)")

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] in ("-h", "--help"):
        print(__doc__); sys.exit(0)
    if a[0] == "--selftest":
        selftest(); sys.exit(0)
    runs = load(a[0])
    if not runs:
        print("NÃO MEDIDO: nenhum run_*.json encontrado em", a[0]); sys.exit(1)
    print(table(runs))
    if "--baseline" in a and "--candidate" in a:
        print(); print(compare(runs, a[a.index("--baseline")+1], a[a.index("--candidate")+1]))
