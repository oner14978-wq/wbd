#!/usr/bin/env bash
# Coleta de benchmark do Cat Launcher via adb. NÃO inventa números: só puxa o que o app gravou.
#
# Uso: ./run_benchmark.sh <rotulo> <n_execucoes> [pacote] [--tap X,Y]
#   rotulo  nome da versão medida, ex.: original | otimizada (grava label.txt no aparelho)
#   --tap   coordenadas do botão Jogar para automatizar o toque (senão, toque você mesmo)
#
# Condições iguais entre versões: mesmo aparelho, mesma instância/mundo, mesma temperatura
# (espere esfriar), bateria >50%, modo avião igual, mesmo perfil JVM nas Configurações.
set -euo pipefail
LABEL="${1:?rotulo}"; N="${2:?n}"; PKG="${3:-}"; TAP=""
[[ "${*}" == *"--tap"* ]] && TAP="${@: -1}"
# o applicationId pode ter sufixo (.v2 / .debug): detecta se não foi informado
[[ "$PKG" == --* || -z "$PKG" ]] && PKG=$(adb shell pm list packages | tr -d '\r' | sed -n 's/^package://p' | grep -i zalithlauncher | head -1)
[[ -n "$PKG" ]] || { echo "pacote do Cat Launcher não encontrado; informe o 3º argumento"; exit 1; }
COMPONENT=$(adb shell cmd package resolve-activity --brief -c android.intent.category.LAUNCHER "$PKG" | tr -d '\r' | tail -1)
DIR="/sdcard/Android/data/$PKG/files/benchmark"
OUT="./bench_out/$LABEL"; mkdir -p "$OUT"

adb shell "mkdir -p $DIR && echo '$LABEL' > $DIR/label.txt"
echo "device: $(adb shell getprop ro.product.model) | android $(adb shell getprop ro.build.version.release)"
echo "tempo de abertura do launcher (am start -W; abertura a frio) e jogadas:"

for i in $(seq 1 "$N"); do
  adb shell am force-stop "$PKG"
  # cache de página do sistema só é limpo com root; sem root a 1ª medição de cada rodada é "morna"
  adb shell 'su -c "sync; echo 3 > /proc/sys/vm/drop_caches"' >/dev/null 2>&1 || echo "  (sem root: cache de página não limpo)"
  adb logcat -c
  adb shell am start -W -n "$COMPONENT" | tee "$OUT/am_start_$i.txt" | grep -E "TotalTime|WaitTime" || true
  before=$(adb shell "ls $DIR/runs 2>/dev/null | wc -l" | tr -d '\r')
  if [[ -n "$TAP" ]]; then sleep 4; adb shell input tap "${TAP%,*}" "${TAP#*,}"; else echo "  -> toque em JOGAR agora (execução $i/$N)"; fi
  for _ in $(seq 1 180); do
    sleep 2
    now=$(adb shell "ls $DIR/runs 2>/dev/null | wc -l" | tr -d '\r')
    [[ "$now" -gt "$before" ]] && break
  done
  [[ "${now:-0}" -gt "$before" ]] && echo "  execução $i: mundo jogável registrado" || echo "  execução $i: NÃO MEDIDA (tempo esgotado: o mundo não ficou jogável / cursor não foi capturado)"
  adb logcat -d | grep -E "Startup|Launcher ready" > "$OUT/logcat_startup_$i.txt" || true
  sleep 5
done
adb pull "$DIR" "$OUT/benchmark" >/dev/null
echo "pronto: $OUT/benchmark/runs  ->  python3 compare_reports.py $OUT/benchmark/runs"
