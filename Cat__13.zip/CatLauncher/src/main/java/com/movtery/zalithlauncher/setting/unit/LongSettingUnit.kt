/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.setting.unit

import com.movtery.zalithlauncher.setting.launcherMMKV

class LongSettingUnit(
    key: String,
    defaultValue: Long,
    val valueRange: LongRange
) : AbstractSettingUnit<Long>(key, defaultValue) {
    override fun getValue(): Long {
        return launcherMMKV().getLong(key, defaultValue)
            .also { state = it }
    }

    override fun saveValue(v: Long): Long {
        return v.coerceIn(valueRange).also { value ->
            launcherMMKV().putLong(key, value).apply()
        }
    }

    override fun updateState(value: Long) {
        this.state = value.coerceIn(valueRange)
    }
}