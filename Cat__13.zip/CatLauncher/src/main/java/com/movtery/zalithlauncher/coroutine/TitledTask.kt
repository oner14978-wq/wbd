/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.coroutine

import androidx.annotation.DrawableRes
import com.movtery.zalithlauncher.ui.AndroidStringText
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

data class TitledTask(
    val title: AndroidStringText,
    @field:DrawableRes
    val runningIcon: Int? = null,
    val task: Task,
    /** 该任务在整体进度中所占的权重（仅用于启动游戏的加载界面计算总进度） */
    val weight: Float = 1f
)

fun MutableList<TitledTask>.addTask(
    title: AndroidStringText,
    @DrawableRes
    icon: Int? = null,
    id: String? = null,
    dispatcher: CoroutineDispatcher = Dispatchers.Default,
    weight: Float = 1f,
    action: suspend CoroutineScope.(Task) -> Unit
) {
    add(
        TitledTask(
            title = title,
            runningIcon = icon,
            task = Task.runTask(id = id, dispatcher = dispatcher, task = action),
            weight = weight
        )
    )
}

fun MutableList<TitledTask>.addTask(
    title: AndroidStringText,
    @DrawableRes
    icon: Int? = null,
    weight: Float = 1f,
    task: Task
) {
    add(
        TitledTask(
            title = title,
            runningIcon = icon,
            task = task,
            weight = weight
        )
    )
}