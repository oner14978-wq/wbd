package com.movtery.zalithlauncher.game.version.download

import com.movtery.zalithlauncher.path.PathManager
import com.movtery.zalithlauncher.utils.logging.Logger
import java.io.File
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "VerifiedFileCache"
private const val CACHE_FILE_NAME = "verified-game-files.tsv"
private const val MAX_ENTRIES = 60_000

/**
 * Cache persistente de arquivos do jogo (jar, bibliotecas, assets) que já passaram no SHA-1.
 *
 * Antes, todo início do jogo recalculava o SHA-1 de milhares de arquivos. Agora um arquivo só é
 * recalculado se mudou: a entrada vale enquanto tamanho, data de modificação e SHA-1 esperado
 * forem os mesmos. Qualquer diferença cai de volta na verificação completa, então a segurança
 * não muda. Se o cache sumir (limpar cache do app) ou estiver corrompido, o efeito é só uma
 * verificação completa na próxima vez.
 */
object VerifiedFileCache {
    private class Entry(val sha1: String, val size: Long, val mtime: Long)

    private val entries = ConcurrentHashMap<String, Entry>()
    private val loadLock = Any()
    private val saveLock = Any()

    @Volatile
    private var loaded = false

    @Volatile
    private var dirty = false

    private fun cacheFile() = File(PathManager.DIR_CACHE, CACHE_FILE_NAME)

    private fun ensureLoaded() {
        if (loaded) return
        synchronized(loadLock) {
            if (loaded) return
            runCatching {
                val file = cacheFile()
                if (file.isFile) {
                    file.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            val parts = line.split('\t', limit = 4)
                            if (parts.size != 4) return@forEach
                            val size = parts[1].toLongOrNull() ?: return@forEach
                            val mtime = parts[2].toLongOrNull() ?: return@forEach
                            entries[parts[3]] = Entry(parts[0], size, mtime)
                        }
                    }
                }
            }.onFailure {
                Logger.warning(TAG, "Failed to load the verified files cache, starting empty", it)
                entries.clear()
            }
            loaded = true
        }
    }

    /** `true` se este arquivo já foi verificado com este SHA-1 e não mudou desde então. */
    fun isVerified(file: File, sha1: String): Boolean {
        ensureLoaded()
        val entry = entries[file.absolutePath] ?: return false
        return entry.size == file.length() &&
                entry.mtime == file.lastModified() &&
                entry.sha1.equals(sha1, ignoreCase = true)
    }

    /** Registra um arquivo que acabou de passar na verificação completa. */
    fun record(file: File, sha1: String) {
        ensureLoaded()
        val size = file.length()
        if (size <= 0L) return
        entries[file.absolutePath] = Entry(sha1.lowercase(), size, file.lastModified())
        dirty = true
    }

    fun forget(file: File) {
        ensureLoaded()
        if (entries.remove(file.absolutePath) != null) dirty = true
    }

    /** Grava o cache em disco (escrita atômica). Chamado uma vez ao fim de cada verificação em lote. */
    fun flush() {
        if (!dirty) return
        synchronized(saveLock) {
            if (!dirty) return
            runCatching {
                if (entries.size > MAX_ENTRIES) {
                    entries.keys.forEach { if (!File(it).exists()) entries.remove(it) }
                }
                val target = cacheFile()
                val tmp = File(target.parentFile, "$CACHE_FILE_NAME.tmp")
                tmp.bufferedWriter().use { out ->
                    entries.forEach { (path, e) ->
                        out.write("${e.sha1}\t${e.size}\t${e.mtime}\t$path")
                        out.newLine()
                    }
                }
                if (!tmp.renameTo(target)) {
                    target.delete()
                    tmp.renameTo(target)
                }
                dirty = false
            }.onFailure {
                Logger.warning(TAG, "Failed to save the verified files cache", it)
            }
        }
    }
}
