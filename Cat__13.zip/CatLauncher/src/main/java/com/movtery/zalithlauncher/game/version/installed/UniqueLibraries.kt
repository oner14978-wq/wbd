/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.version.installed

import com.movtery.zalithlauncher.core.CatCore
import com.movtery.zalithlauncher.game.versioninfo.models.GameManifest

/**
 * 去重启动依赖库
 * 同一坐标且规则相同时只保留最新版本；规则不同或坐标不同的声明全部保留。
 * 实现位于 Rust（CatCore）。
 */
fun uniqueLibraries(manifest: GameManifest): GameManifest {
    val libraries = manifest.libraries ?: return manifest
    val unique = CatCore.uniqueLibraries(libraries)
    if (unique.size != libraries.size) {
        manifest.libraries = unique
    }
    return manifest
}
