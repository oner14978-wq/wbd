/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.account.wardrobe

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import com.movtery.zalithlauncher.path.PathManager
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs

/** Categorias de itens da tela "Personalização do Personagem" */
enum class CosmeticCategory {
    SHIRT, PANTS, SHOES, HAT,
    GLASSES, MASK, HEADPHONES, NECKLACE, BACKPACK, SPECIAL,
    CAPE
}

/** Parte da skin que é mostrada na miniatura de cada item */
enum class ThumbRegion { HEAD, TORSO_FRONT, TORSO_ARMS, TORSO_BACK, LEGS, FEET, CAPE }

/** Pincel sobre a textura 64x64 da skin (camadas externas) */
class SkinPainter(private val bmp: Bitmap) {
    fun px(x: Int, y: Int, color: Int) {
        if (x in 0 until bmp.width && y in 0 until bmp.height) bmp.setPixel(x, y, color)
    }

    fun rect(x: Int, y: Int, w: Int, h: Int, color: Int) {
        for (yy in y until y + h) for (xx in x until x + w) px(xx, yy, color)
    }
}

/** Um item que pode ser vestido pelo personagem */
class CosmeticItem(
    val id: String,
    val category: CosmeticCategory,
    val region: ThumbRegion,
    val paint: SkinPainter.() -> Unit = {}
)

/**
 * Itens escolhidos pelo jogador: no máximo um item por categoria.
 * Categoria ausente significa "original / nenhum".
 */
data class CosmeticSelection(
    val items: Map<CosmeticCategory, String> = emptyMap()
) {
    fun get(category: CosmeticCategory): String? = items[category]

    fun with(category: CosmeticCategory, id: String?): CosmeticSelection =
        copy(items = if (id == null) items - category else items + (category to id))

    /** Apenas os itens que alteram a textura da skin (sem capa) */
    fun skinPart(): CosmeticSelection = copy(items = items.filterKeys { it != CosmeticCategory.CAPE })

    /** Apenas a capa */
    fun withoutSkinItems(): CosmeticSelection = copy(items = items.filterKeys { it == CosmeticCategory.CAPE })

    val cape: String? get() = items[CosmeticCategory.CAPE]
    val hasSkinItems: Boolean get() = items.keys.any { it != CosmeticCategory.CAPE }
    val isEmpty: Boolean get() = items.isEmpty()
}

/**
 * Persistência dos itens escolhidos e da skin original (sem itens) de cada conta.
 * A skin original é necessária para que os itens possam ser removidos depois.
 */
object CosmeticStore {
    private fun dir(): File = PathManager.DIR_ACCOUNT_SKIN

    fun baseFile(uuid: String) = File(dir(), "$uuid.base.png")
    private fun selectionFile(uuid: String) = File(dir(), "$uuid.cosmetics.json")

    fun load(uuid: String): CosmeticSelection {
        val file = selectionFile(uuid)
        if (!file.exists()) return CosmeticSelection()
        return runCatching {
            val json = JSONObject(file.readText())
            val map = mutableMapOf<CosmeticCategory, String>()
            for (category in CosmeticCategory.entries) {
                val id = json.optString(category.name.lowercase())
                // ids antigos ou removidos do catálogo são ignorados
                if (id.isNotEmpty() && CosmeticCatalog.find(id)?.category == category) {
                    map[category] = id
                }
            }
            CosmeticSelection(map)
        }.getOrDefault(CosmeticSelection())
    }

    fun save(uuid: String, selection: CosmeticSelection) {
        runCatching {
            val json = JSONObject()
            for ((category, id) in selection.items) json.put(category.name.lowercase(), id)
            dir().mkdirs()
            selectionFile(uuid).writeText(json.toString())
        }
    }

    fun saveBase(uuid: String, bytes: ByteArray) {
        runCatching {
            dir().mkdirs()
            baseFile(uuid).writeBytes(bytes)
        }
    }

    fun clear(uuid: String) {
        runCatching { selectionFile(uuid).delete() }
        runCatching { baseFile(uuid).delete() }
    }
}

// ------------------------------------------------------------------ cores

private fun c(hex: Long): Int = hex.toInt()

private val GOLD = c(0xFFFFC928)
private val GOLD_DARK = c(0xFFC98F0A)
private val GOLD_LIGHT = c(0xFFFFE680)
private val BLACK = c(0xFF0D0B14)
private val GRAY_DARK = c(0xFF3A3645)
private val GRAY = c(0xFF8A8697)
private val GRAY_LIGHT = c(0xFFC9C6D6)
private val WHITE = c(0xFFF4F1FF)
private val RED = c(0xFFD32F2F)
private val RED_DARK = c(0xFF8E1B1B)
private val PINK = c(0xFFFF8FD0)
private val PINK_DARK = c(0xFFD84FA0)
private val PURPLE = c(0xFF7B2FFF)
private val PURPLE_DARK = c(0xFF4A1BA8)
private val NEON = c(0xFFB57BFF)
private val MAGENTA = c(0xFFE879F9)
private val BLUE = c(0xFF3F51D8)
private val BLUE_DARK = c(0xFF27348F)
private val NAVY = c(0xFF1B2A55)
private val CYAN = c(0xFF22D3EE)
private val CYAN_DARK = c(0xFF0E8FA8)
private val GREEN = c(0xFF4CAF50)
private val GREEN_DARK = c(0xFF2E7D32)
private val YELLOW = c(0xFFFFD83D)
private val ORANGE = c(0xFFFF8A1F)
private val BROWN = c(0xFF8B5A2B)
private val BROWN_DARK = c(0xFF5A3A1A)
private val STRAW = c(0xFFE6B84C)
private const val TRANSPARENT = 0

private fun shade(color: Int, factor: Float): Int {
    val a = (color ushr 24) and 0xFF
    val r = (((color shr 16) and 0xFF) * factor).toInt().coerceIn(0, 255)
    val g = (((color shr 8) and 0xFF) * factor).toInt().coerceIn(0, 255)
    val b = ((color and 0xFF) * factor).toInt().coerceIn(0, 255)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
}

// ------------------------------------------------------- blocos de pintura
// Coordenadas da camada externa da skin 64x64:
//  cabeça: topo (40,0) | direita (32,8) | frente (40,8) | esquerda (48,8) | costas (56,8)  [8x8]
//  tronco: frente (20,36 8x12) | costas (32,36) | laterais (16,36) e (28,36) [4x12]
//  braço direito: x 40..55, y 32..47   |   braço esquerdo: x 48..63, y 48..63
//  perna direita: x 0..15, y 32..47    |   perna esquerda: x 0..15, y 48..63

private fun SkinPainter.torso(c: Int) { rect(16, 36, 24, 12, c); rect(20, 32, 16, 4, c) }
private fun SkinPainter.longArms(c: Int) { rect(40, 36, 16, 12, c); rect(44, 32, 8, 4, c); rect(48, 52, 16, 12, c); rect(52, 48, 8, 4, c) }
private fun SkinPainter.shortArms(c: Int) { rect(40, 36, 16, 4, c); rect(44, 32, 8, 4, c); rect(48, 52, 16, 4, c); rect(52, 48, 8, 4, c) }
private fun SkinPainter.cuffs(c: Int) { rect(40, 46, 16, 2, c); rect(48, 62, 16, 2, c) }
private fun SkinPainter.hem(c: Int) { rect(16, 46, 24, 2, c) }
private fun SkinPainter.collar(c: Int) { rect(16, 36, 24, 1, c) }

private fun SkinPainter.legs(c: Int) { rect(0, 36, 16, 12, c); rect(4, 32, 8, 4, c); rect(0, 52, 16, 12, c); rect(4, 48, 8, 4, c) }
private fun SkinPainter.shorts(c: Int) { rect(0, 36, 16, 5, c); rect(4, 32, 8, 4, c); rect(0, 52, 16, 5, c); rect(4, 48, 8, 4, c) }
private fun SkinPainter.waist(c: Int) { rect(0, 36, 16, 1, c); rect(0, 52, 16, 1, c) }

/** Executa o bloco para cada perna, informando a linha inicial (36 = direita, 52 = esquerda) */
private fun SkinPainter.eachLeg(block: (Int) -> Unit) { block(36); block(52) }

private fun SkinPainter.headCap(c: Int, rows: Int = 2) { rect(40, 0, 8, 8, c); rect(32, 8, 32, rows, c) }

// ---------------------------------------------------------------- camisas

private fun SkinPainter.tee(color: Int, trim: Int) {
    torso(color); shortArms(color); collar(trim)
    rect(40, 39, 16, 1, trim); rect(48, 55, 16, 1, trim)
}

private fun SkinPainter.creeperTee() {
    tee(GREEN, GREEN_DARK)
    for (y in 37..47) for (x in 16..39) if ((x * 7 + y * 13) % 5 == 0) px(x, y, GREEN_DARK)
    rect(21, 39, 2, 2, BLACK); rect(25, 39, 2, 2, BLACK)
    rect(23, 41, 2, 3, BLACK); rect(22, 43, 1, 2, BLACK); rect(25, 43, 1, 2, BLACK)
}

private fun SkinPainter.stripedTee() {
    tee(WHITE, NAVY)
    for (y in 37..47 step 2) rect(16, y, 24, 1, NAVY)
    for (y in 37..39 step 2) { rect(40, y, 16, 1, NAVY); rect(48, y + 16, 16, 1, NAVY) }
}

private fun SkinPainter.jacketRedBlack() {
    torso(RED); longArms(BLACK); collar(BLACK); rect(20, 36, 8, 2, BLACK)
    for (y in 38..47) px(23, y, GRAY_LIGHT)
    rect(21, 43, 2, 3, BLACK); rect(25, 43, 2, 3, BLACK)
    hem(BLACK); cuffs(RED_DARK)
}

private fun SkinPainter.jacketDenim() {
    val d = c(0xFF3566B8); val l = c(0xFF5C8AD6)
    torso(d); longArms(d); collar(l)
    for (y in 38..46 step 3) { px(23, y, GOLD); px(24, y, GOLD) }
    rect(21, 40, 2, 2, l); rect(25, 40, 2, 2, l)
    hem(l); cuffs(l)
}

private fun SkinPainter.jacketLeather() {
    val l = c(0xFF1C1823)
    torso(l); longArms(l); collar(GRAY_DARK); rect(20, 36, 3, 5, GRAY_DARK); rect(25, 36, 3, 5, GRAY_DARK)
    for (i in 0..9) px(23 + (if (i > 4) 1 else 0), 38 + i, GRAY_LIGHT)
    rect(40, 40, 16, 1, GRAY_DARK); rect(48, 56, 16, 1, GRAY_DARK)
    hem(GRAY_DARK); cuffs(GRAY_DARK)
}

private fun SkinPainter.jacketVarsity() {
    torso(NAVY); longArms(WHITE); collar(WHITE)
    rect(21, 39, 2, 5, GOLD); rect(25, 39, 2, 5, GOLD); rect(23, 43, 2, 1, GOLD)
    rect(40, 44, 16, 1, NAVY); rect(48, 60, 16, 1, NAVY)
    cuffs(NAVY); hem(NAVY)
}

private fun SkinPainter.hoodie(color: Int, dark: Int, string: Int) {
    torso(color); longArms(color)
    rect(16, 36, 24, 2, dark)
    for (y in 38..40) { px(22, y, string); px(25, y, string) }
    rect(20, 43, 8, 3, dark); px(23, 43, color); px(24, 43, color)
    hem(dark); cuffs(dark)
}

private fun SkinPainter.uniformPolice() {
    torso(NAVY); longArms(NAVY); collar(c(0xFF8FB4E8))
    rect(16, 44, 24, 1, BLACK); rect(23, 44, 2, 1, GOLD)
    rect(25, 38, 2, 2, GOLD)
    cuffs(c(0xFF121C3D))
}

private fun SkinPainter.uniformChef() {
    torso(WHITE); longArms(WHITE)
    rect(21, 36, 6, 1, RED)
    for (y in 38..44 step 3) { px(22, y, GRAY); px(25, y, GRAY) }
    cuffs(GRAY_LIGHT)
}

private fun SkinPainter.uniformSoccer() {
    tee(YELLOW, GREEN)
    rect(34, 39, 1, 6, GREEN); rect(36, 39, 3, 6, GREEN); rect(37, 40, 1, 4, YELLOW)
}

private fun SkinPainter.uniformAstronaut() {
    torso(WHITE); longArms(WHITE)
    rect(21, 38, 6, 4, GRAY_LIGHT); px(22, 39, RED); px(24, 39, BLUE); px(25, 40, GREEN)
    rect(16, 44, 24, 1, ORANGE); cuffs(ORANGE)
}

private fun SkinPainter.armor(base: Int, light: Int, dark: Int) {
    torso(base); longArms(base)
    rect(16, 36, 24, 1, light); rect(16, 47, 24, 1, dark)
    rect(21, 38, 6, 1, dark); rect(21, 41, 6, 1, dark)
    rect(40, 36, 16, 2, light); rect(48, 52, 16, 2, light)
    cuffs(dark)
}

private fun SkinPainter.tuxedo() {
    torso(BLACK); longArms(BLACK)
    for (y in 37..42) rect(if (y < 40) 22 else 23, y, if (y < 40) 4 else 2, 1, WHITE)
    px(22, 36, RED); rect(23, 36, 2, 1, RED_DARK); px(25, 36, RED)
    rect(40, 46, 16, 1, WHITE); rect(48, 62, 16, 1, WHITE)
}

private fun SkinPainter.neonSuit() {
    val base = c(0xFF14091F)
    torso(base); longArms(base)
    for (y in 36..47) { px(21, y, NEON); px(26, y, NEON) }
    rect(40, 40, 16, 1, NEON); rect(48, 56, 16, 1, NEON)
    collar(PURPLE); hem(PURPLE_DARK)
}

// ----------------------------------------------------------------- calças

private fun SkinPainter.plainPants(color: Int, belt: Int) {
    legs(color); waist(belt)
    eachLeg { y -> rect(0, y + 9, 16, 1, shade(color, 1.18f)) }
}

private fun SkinPainter.redBlackPants() {
    legs(RED); waist(BLACK)
    eachLeg { y -> for (x in intArrayOf(2, 5, 10, 13)) rect(x, y + 1, 1, 10, BLACK) }
}

private fun SkinPainter.camoPants() {
    legs(GREEN_DARK); waist(BROWN_DARK)
    for (y in 36..63) for (x in 0..15) {
        if (y in 48..51) continue
        if ((x * 5 + y * 3) % 7 < 2) px(x, y, GREEN)
        else if ((x * 3 + y * 7) % 11 < 2) px(x, y, BROWN)
    }
}

private fun SkinPainter.neonPants() {
    legs(BLACK)
    eachLeg { y -> rect(4, y, 1, 12, NEON); rect(7, y, 1, 12, NEON); rect(0, y + 11, 16, 1, PURPLE) }
}

// --------------------------------------------------------------- calçados

private fun SkinPainter.shoes(upper: Int, sole: Int, accent: Int, rows: Int = 3) {
    eachLeg { y ->
        rect(0, y + 12 - rows, 16, rows, upper)
        rect(0, y + 11, 16, 1, sole)
        rect(4, y + 12 - rows, 4, 1, accent)
    }
    rect(8, 32, 4, 4, sole); rect(8, 48, 4, 4, sole)
}

// --------------------------------------------------------------- chapéus

private fun SkinPainter.cap(color: Int, dark: Int) {
    headCap(color, 2)
    rect(40, 10, 8, 1, BLACK)
    rect(43, 3, 2, 2, dark); rect(43, 8, 2, 1, WHITE)
}

private fun SkinPainter.strawHat() {
    headCap(STRAW, 3)
    for (x in 32..63) for (y in 8..9) if ((x + y) % 2 == 0) px(x, y, shade(STRAW, 0.88f))
    for (x in 40..47) for (y in 0..7) if ((x + y) % 2 == 0) px(x, y, shade(STRAW, 0.88f))
    rect(32, 10, 32, 1, RED)
}

private fun SkinPainter.crown(gems: Boolean) {
    rect(32, 8, 32, 2, GOLD)
    rect(32, 9, 32, 1, GOLD_DARK)
    for (x in 32..63) if (x % 2 == 1) px(x, 8, TRANSPARENT)
    for (x in 32..63) if (x % 4 == 0) px(x, 8, GOLD_LIGHT)
    rect(40, 0, 8, 8, GOLD)
    rect(41, 1, 6, 6, TRANSPARENT)
    if (gems) {
        px(41, 9, PURPLE); px(44, 9, MAGENTA); px(46, 9, PURPLE)
        px(43, 8, GOLD_LIGHT)
    }
}

private fun SkinPainter.beanie(color: Int, accent: Int) {
    headCap(color, 3)
    for (x in 32..63 step 2) rect(x, 8, 1, 3, shade(color, 0.78f))
    rect(32, 10, 32, 1, accent)
    rect(43, 3, 2, 2, WHITE)
}

private fun SkinPainter.helmet(base: Int, light: Int, dark: Int) {
    rect(40, 0, 8, 8, base); rect(32, 8, 8, 8, base); rect(48, 8, 8, 8, base); rect(56, 8, 8, 8, base)
    rect(40, 8, 8, 3, base); rect(40, 11, 2, 5, base); rect(46, 11, 2, 5, base)
    rect(40, 0, 8, 1, light); rect(32, 8, 32, 1, light)
    rect(40, 10, 8, 1, dark); rect(32, 15, 32, 1, dark)
}

private fun SkinPainter.minerHelmet() {
    val h = c(0xFFF5C400)
    headCap(h, 3)
    rect(32, 10, 32, 1, ORANGE)
    rect(43, 8, 2, 2, WHITE)
}

private fun SkinPainter.santaHat() {
    rect(40, 0, 8, 8, RED)
    rect(32, 8, 32, 1, RED)
    rect(32, 9, 32, 1, WHITE)
    rect(32, 10, 8, 1, RED_DARK)
    rect(56, 10, 8, 1, RED_DARK)
    rect(43, 5, 2, 2, WHITE)
    rect(44, 4, 1, 1, WHITE)
}

private fun SkinPainter.topHat() {
    headCap(BLACK, 2)
    rect(32, 9, 32, 1, PURPLE)
}

private fun SkinPainter.wizardHat() {
    headCap(PURPLE_DARK, 3)
    rect(32, 10, 32, 1, GOLD)
    px(42, 2, GOLD); px(45, 5, GOLD_LIGHT); px(44, 1, GOLD_LIGHT)
    px(34, 8, GOLD_LIGHT); px(46, 8, GOLD); px(60, 9, GOLD_LIGHT)
}

private fun SkinPainter.pirateHat() {
    headCap(BLACK, 3)
    rect(32, 10, 32, 1, GOLD_DARK)
    rect(42, 8, 4, 2, WHITE); px(43, 9, BLACK); px(44, 9, BLACK)
}

private fun SkinPainter.cowboyHat() {
    headCap(BROWN, 2)
    rect(32, 10, 32, 1, BROWN_DARK)
    rect(40, 10, 8, 1, BROWN_DARK); px(43, 9, GOLD); px(44, 9, GOLD)
}

private fun SkinPainter.catEars() {
    rect(41, 1, 2, 2, PINK)
    rect(45, 1, 2, 2, PINK)
    px(41, 1, PINK_DARK); px(46, 1, PINK_DARK)
    px(41, 8, PINK); px(46, 8, PINK)
    rect(43, 0, 2, 1, PINK_DARK)
}

// ----------------------------------------------------------------- óculos
// os olhos do Steve ficam na linha y = 12 da frente da cabeça

private fun SkinPainter.sunglasses() {
    rect(41, 12, 3, 2, BLACK); rect(45, 12, 3, 2, BLACK); px(44, 12, BLACK)
    rect(32, 12, 8, 1, BLACK); rect(48, 12, 8, 1, BLACK)
}

private fun SkinPainter.roundGlasses() {
    rect(41, 11, 3, 1, WHITE); rect(41, 14, 3, 1, WHITE); px(40, 12, WHITE); px(40, 13, WHITE); px(43, 12, TRANSPARENT)
    rect(45, 11, 3, 1, WHITE); rect(45, 14, 3, 1, WHITE); px(48, 12, WHITE); px(48, 13, WHITE)
    px(44, 12, WHITE); px(44, 13, WHITE); px(44, 11, WHITE)
    rect(32, 12, 8, 1, WHITE); rect(49, 12, 7, 1, WHITE)
}

private fun SkinPainter.pixelGlasses() {
    rect(40, 12, 8, 1, BLACK); rect(41, 13, 3, 1, BLACK); rect(45, 13, 3, 1, BLACK)
    px(41, 12, WHITE); px(45, 12, WHITE)
    rect(32, 12, 8, 1, BLACK); rect(48, 12, 8, 1, BLACK)
}

private fun SkinPainter.neonGlasses() {
    for (x in 41..43) px(x, 12, NEON)
    for (x in 45..47) px(x, 12, NEON)
    px(41, 13, NEON); px(43, 13, NEON); px(45, 13, NEON); px(47, 13, NEON)
    px(42, 13, PURPLE_DARK); px(46, 13, PURPLE_DARK); px(44, 12, NEON)
    rect(32, 12, 8, 1, NEON); rect(48, 12, 8, 1, NEON)
}

// --------------------------------------------------------------- máscaras

private fun SkinPainter.surgicalMask() {
    rect(40, 13, 8, 3, c(0xFFDCEBFF)); rect(40, 14, 8, 1, c(0xFFB8D4F5))
    rect(35, 13, 5, 1, WHITE); rect(48, 13, 5, 1, WHITE)
}

private fun SkinPainter.ninjaMask() {
    rect(40, 0, 8, 8, BLACK); rect(32, 8, 32, 8, BLACK)
    rect(41, 12, 6, 2, TRANSPARENT)
    rect(32, 10, 32, 1, RED_DARK)
}

private fun SkinPainter.bandanaMask() {
    rect(40, 13, 8, 3, RED); rect(35, 13, 5, 1, RED_DARK); rect(48, 13, 5, 1, RED_DARK)
    px(41, 14, WHITE); px(44, 15, WHITE); px(46, 13, WHITE)
}

private fun SkinPainter.gasMask() {
    rect(40, 13, 8, 3, GRAY_DARK); rect(42, 14, 4, 2, GRAY)
    rect(43, 15, 2, 1, BLACK)
    rect(35, 13, 5, 1, BLACK); rect(48, 13, 5, 1, BLACK)
}

// -------------------------------------------------------- fones de ouvido

private fun SkinPainter.headphones(band: Int, cup: Int, accent: Int) {
    rect(43, 0, 2, 8, band)
    rect(35, 8, 2, 4, band); rect(51, 8, 2, 4, band)
    rect(34, 12, 4, 4, cup); rect(50, 12, 4, 4, cup)
    rect(35, 13, 2, 2, accent); rect(51, 13, 2, 2, accent)
}

// ----------------------------------------------------------------- colares

private fun SkinPainter.chain(link: Int, pendant: Int) {
    rect(16, 36, 24, 1, link)
    px(21, 37, link); px(22, 38, link); px(23, 39, link)
    px(26, 37, link); px(25, 38, link); px(24, 39, link)
    rect(23, 40, 2, 2, pendant)
}

private fun SkinPainter.redBandana() {
    rect(16, 36, 24, 1, RED)
    rect(20, 37, 8, 1, RED); rect(21, 38, 6, 1, RED); rect(22, 39, 4, 1, RED); rect(23, 40, 2, 1, RED)
    px(22, 37, WHITE); px(25, 38, WHITE); px(23, 39, WHITE)
}

// ---------------------------------------------------------------- mochilas

private fun SkinPainter.backpack(body: Int, flap: Int, pocket: Int, strap: Int) {
    rect(33, 37, 6, 9, body); rect(33, 37, 6, 3, flap); rect(34, 42, 4, 3, pocket)
    px(35, 40, GOLD); px(36, 40, GOLD)
    rect(21, 36, 1, 6, strap); rect(26, 36, 1, 6, strap)
    rect(21, 32, 1, 4, strap); rect(26, 32, 1, 4, strap)
}

// --------------------------------------------------------------- especiais

private fun SkinPainter.eyePatch() {
    rect(32, 9, 32, 1, BLACK); rect(45, 12, 3, 3, BLACK)
}

private fun SkinPainter.whiskers() {
    rect(40, 13, 2, 1, GRAY_DARK); rect(40, 15, 2, 1, GRAY_DARK)
    rect(46, 13, 2, 1, GRAY_DARK); rect(46, 15, 2, 1, GRAY_DARK)
    px(43, 14, PINK_DARK); px(44, 14, PINK_DARK)
}

private fun SkinPainter.warPaint() {
    rect(41, 14, 2, 1, NEON); rect(45, 14, 2, 1, NEON)
    px(41, 15, MAGENTA); px(46, 15, MAGENTA); px(43, 10, MAGENTA); px(44, 10, NEON)
}

private fun SkinPainter.cyberVisor() {
    rect(40, 12, 8, 2, c(0xFF22D3EE)); px(41, 12, WHITE); px(45, 12, WHITE)
    rect(32, 12, 8, 1, GRAY_DARK); rect(48, 12, 8, 1, GRAY_DARK)
}

private fun SkinPainter.mustache() {
    rect(41, 14, 6, 1, BROWN_DARK); px(40, 15, BROWN_DARK); px(47, 15, BROWN_DARK)
}

private fun SkinPainter.scarf() {
    rect(16, 36, 24, 3, RED); rect(16, 38, 24, 1, RED_DARK)
    rect(20, 32, 8, 4, RED)
    rect(24, 39, 3, 6, RED); rect(24, 44, 3, 1, RED_DARK)
}

/**
 * Catálogo e "pintor" dos itens. Cada item é desenhado pixel a pixel nas camadas
 * externas da skin (64x64) ou, no caso das capas, em uma textura 64x32.
 */
object CosmeticCatalog {
    private fun shirt(id: String, paint: SkinPainter.() -> Unit) =
        CosmeticItem(id, CosmeticCategory.SHIRT, ThumbRegion.TORSO_ARMS, paint)

    private fun pants(id: String, paint: SkinPainter.() -> Unit) =
        CosmeticItem(id, CosmeticCategory.PANTS, ThumbRegion.LEGS, paint)

    private fun shoe(id: String, paint: SkinPainter.() -> Unit) =
        CosmeticItem(id, CosmeticCategory.SHOES, ThumbRegion.FEET, paint)

    private fun hat(id: String, paint: SkinPainter.() -> Unit) =
        CosmeticItem(id, CosmeticCategory.HAT, ThumbRegion.HEAD, paint)

    private fun head(id: String, category: CosmeticCategory, paint: SkinPainter.() -> Unit) =
        CosmeticItem(id, category, ThumbRegion.HEAD, paint)

    val shirts: List<CosmeticItem> = listOf(
        // camisetas
        shirt("shirt_tee_red") { tee(RED, RED_DARK) },
        shirt("shirt_tee_blue") { tee(BLUE, BLUE_DARK) },
        shirt("shirt_tee_yellow") { tee(YELLOW, GOLD_DARK) },
        shirt("shirt_tee_black") { tee(c(0xFF1E1B26), GRAY_DARK) },
        shirt("shirt_tee_white") { tee(WHITE, GRAY_LIGHT) },
        shirt("shirt_tee_pink") { tee(PINK, PINK_DARK) },
        shirt("shirt_tee_orange") { tee(ORANGE, c(0xFFB85A00)) },
        shirt("shirt_tee_creeper") { creeperTee() },
        shirt("shirt_tee_striped") { stripedTee() },
        // jaquetas
        shirt("shirt_jacket_red_black") { jacketRedBlack() },
        shirt("shirt_jacket_denim") { jacketDenim() },
        shirt("shirt_jacket_leather") { jacketLeather() },
        shirt("shirt_jacket_varsity") { jacketVarsity() },
        // moletons
        shirt("shirt_hoodie_black") { hoodie(c(0xFF1E1B26), GRAY_DARK, WHITE) },
        shirt("shirt_hoodie_white") { hoodie(WHITE, GRAY_LIGHT, BLACK) },
        shirt("shirt_hoodie_purple") { hoodie(PURPLE, PURPLE_DARK, WHITE) },
        shirt("shirt_hoodie_red") { hoodie(RED, RED_DARK, WHITE) },
        // uniformes
        shirt("shirt_uniform_police") { uniformPolice() },
        shirt("shirt_uniform_chef") { uniformChef() },
        shirt("shirt_uniform_soccer") { uniformSoccer() },
        shirt("shirt_uniform_astronaut") { uniformAstronaut() },
        // roupas especiais
        shirt("shirt_special_gold_armor") { armor(GOLD, GOLD_LIGHT, GOLD_DARK) },
        shirt("shirt_special_iron_armor") { armor(GRAY, GRAY_LIGHT, GRAY_DARK) },
        shirt("shirt_special_diamond_armor") { armor(CYAN, c(0xFFB3F5FF), CYAN_DARK) },
        shirt("shirt_special_tuxedo") { tuxedo() },
        shirt("shirt_special_neon_suit") { neonSuit() }
    )

    val pantsList: List<CosmeticItem> = listOf(
        pants("pants_jeans") { plainPants(BLUE, BLUE_DARK) },
        pants("pants_black") { plainPants(c(0xFF1E1B26), GRAY_DARK) },
        pants("pants_gray") { plainPants(GRAY, GRAY_DARK) },
        pants("pants_red_black") { redBlackPants() },
        pants("pants_shorts_blue") { shorts(BLUE); waist(BLUE_DARK) },
        pants("pants_shorts_khaki") { shorts(c(0xFFC2A878)); waist(BROWN) },
        pants("pants_camo") { camoPants() },
        pants("pants_white") { plainPants(WHITE, GRAY_LIGHT) },
        pants("pants_neon") { neonPants() }
    )

    val shoesList: List<CosmeticItem> = listOf(
        shoe("shoes_sneakers_white") { shoes(WHITE, GRAY, RED) },
        shoe("shoes_sneakers_red") { shoes(RED, WHITE, WHITE) },
        shoe("shoes_boots_brown") { shoes(BROWN, BROWN_DARK, GOLD, 4) },
        shoe("shoes_boots_black") { shoes(BLACK, GRAY_DARK, GRAY, 4) },
        shoe("shoes_neon") { shoes(BLACK, NEON, MAGENTA) },
        shoe("shoes_gold") { shoes(GOLD, GOLD_DARK, GOLD_LIGHT) }
    )

    val hats: List<CosmeticItem> = listOf(
        hat("hat_cap_red") { cap(RED, RED_DARK) },
        hat("hat_cap_blue") { cap(BLUE, BLUE_DARK) },
        hat("hat_straw") { strawHat() },
        hat("hat_crown") { crown(false) },
        hat("hat_beanie_blue") { beanie(BLUE, BLUE_DARK) },
        hat("hat_beanie_neon") { beanie(PURPLE_DARK, NEON) },
        hat("hat_helmet_iron") { helmet(GRAY, GRAY_LIGHT, GRAY_DARK) },
        hat("hat_helmet_gold") { helmet(GOLD, GOLD_LIGHT, GOLD_DARK) },
        hat("hat_helmet_miner") { minerHelmet() },
        hat("hat_santa") { santaHat() },
        hat("hat_top_hat") { topHat() },
        hat("hat_wizard") { wizardHat() },
        hat("hat_pirate") { pirateHat() },
        hat("hat_cowboy") { cowboyHat() },
        hat("hat_cat_ears") { catEars() },
        hat("hat_crown_jeweled") { crown(true) }
    )

    val glasses: List<CosmeticItem> = listOf(
        head("glasses_sunglasses", CosmeticCategory.GLASSES) { sunglasses() },
        head("glasses_round", CosmeticCategory.GLASSES) { roundGlasses() },
        head("glasses_pixel", CosmeticCategory.GLASSES) { pixelGlasses() },
        head("glasses_neon", CosmeticCategory.GLASSES) { neonGlasses() }
    )

    val masks: List<CosmeticItem> = listOf(
        head("mask_surgical", CosmeticCategory.MASK) { surgicalMask() },
        head("mask_ninja", CosmeticCategory.MASK) { ninjaMask() },
        head("mask_bandana", CosmeticCategory.MASK) { bandanaMask() },
        head("mask_gas", CosmeticCategory.MASK) { gasMask() }
    )

    val headphonesList: List<CosmeticItem> = listOf(
        head("phones_black", CosmeticCategory.HEADPHONES) { headphones(GRAY_DARK, BLACK, PURPLE) },
        head("phones_gaming_red", CosmeticCategory.HEADPHONES) { headphones(BLACK, RED_DARK, RED) },
        head("phones_white", CosmeticCategory.HEADPHONES) { headphones(WHITE, GRAY_LIGHT, BLUE) },
        head("phones_pink", CosmeticCategory.HEADPHONES) { headphones(PINK_DARK, PINK, WHITE) }
    )

    val necklaces: List<CosmeticItem> = listOf(
        CosmeticItem("necklace_gold", CosmeticCategory.NECKLACE, ThumbRegion.TORSO_FRONT) { chain(GOLD, GOLD_LIGHT) },
        CosmeticItem("necklace_silver", CosmeticCategory.NECKLACE, ThumbRegion.TORSO_FRONT) { chain(GRAY_LIGHT, CYAN) },
        CosmeticItem("necklace_amulet", CosmeticCategory.NECKLACE, ThumbRegion.TORSO_FRONT) { chain(BROWN_DARK, c(0xFF2ECC71)) },
        CosmeticItem("necklace_bandana", CosmeticCategory.NECKLACE, ThumbRegion.TORSO_FRONT) { redBandana() }
    )

    val backpacks: List<CosmeticItem> = listOf(
        CosmeticItem("backpack_black", CosmeticCategory.BACKPACK, ThumbRegion.TORSO_BACK) { backpack(c(0xFF1E1B26), GRAY_DARK, GRAY, BLACK) },
        CosmeticItem("backpack_red", CosmeticCategory.BACKPACK, ThumbRegion.TORSO_BACK) { backpack(RED, RED_DARK, ORANGE, RED_DARK) },
        CosmeticItem("backpack_purple", CosmeticCategory.BACKPACK, ThumbRegion.TORSO_BACK) { backpack(PURPLE, PURPLE_DARK, NEON, PURPLE_DARK) },
        CosmeticItem("backpack_school", CosmeticCategory.BACKPACK, ThumbRegion.TORSO_BACK) { backpack(BLUE, BLUE_DARK, YELLOW, NAVY) }
    )

    val specials: List<CosmeticItem> = listOf(
        head("special_eyepatch", CosmeticCategory.SPECIAL) { eyePatch() },
        head("special_whiskers", CosmeticCategory.SPECIAL) { whiskers() },
        head("special_war_paint", CosmeticCategory.SPECIAL) { warPaint() },
        head("special_visor", CosmeticCategory.SPECIAL) { cyberVisor() },
        head("special_mustache", CosmeticCategory.SPECIAL) { mustache() },
        CosmeticItem("special_scarf", CosmeticCategory.SPECIAL, ThumbRegion.TORSO_FRONT) { scarf() }
    )

    val capes: List<CosmeticItem> = listOf(
        CosmeticItem("cape_creeper", CosmeticCategory.CAPE, ThumbRegion.CAPE),
        CosmeticItem("cape_redstone", CosmeticCategory.CAPE, ThumbRegion.CAPE),
        CosmeticItem("cape_ghost", CosmeticCategory.CAPE, ThumbRegion.CAPE),
        CosmeticItem("cape_ice", CosmeticCategory.CAPE, ThumbRegion.CAPE),
        CosmeticItem("cape_neon", CosmeticCategory.CAPE, ThumbRegion.CAPE)
    )

    private val all: List<CosmeticItem> by lazy {
        shirts + pantsList + shoesList + hats + glasses + masks + headphonesList +
                necklaces + backpacks + specials + capes
    }

    fun items(category: CosmeticCategory): List<CosmeticItem> = when (category) {
        CosmeticCategory.SHIRT -> shirts
        CosmeticCategory.PANTS -> pantsList
        CosmeticCategory.SHOES -> shoesList
        CosmeticCategory.HAT -> hats
        CosmeticCategory.GLASSES -> glasses
        CosmeticCategory.MASK -> masks
        CosmeticCategory.HEADPHONES -> headphonesList
        CosmeticCategory.NECKLACE -> necklaces
        CosmeticCategory.BACKPACK -> backpacks
        CosmeticCategory.SPECIAL -> specials
        CosmeticCategory.CAPE -> capes
    }

    fun find(id: String): CosmeticItem? = all.firstOrNull { it.id == id }

    // ------------------------------------------------------- composição

    /** Converte skins antigas (64x32) para o formato 64x64 com camadas extras */
    private fun toModern(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply { isFilterBitmap = false }
        val srcCrop = if (src.width == 64 && src.height >= 32) src else Bitmap.createScaledBitmap(src, 64, 32, false)
        canvas.drawBitmap(srcCrop, Rect(0, 0, 64, minOf(srcCrop.height, 64)), Rect(0, 0, 64, minOf(srcCrop.height, 64)), paint)
        if (srcCrop.height == 32) {
            fun mirror(sx: Int, sy: Int, dx: Int, dy: Int) {
                val part = Bitmap.createBitmap(srcCrop, sx, sy, 16, 16)
                val m = Matrix().apply { preScale(-1f, 1f) }
                val flipped = Bitmap.createBitmap(part, 0, 0, 16, 16, m, false)
                canvas.drawBitmap(flipped, dx.toFloat(), dy.toFloat(), paint)
            }
            mirror(0, 16, 16, 48)   // perna esquerda
            mirror(40, 16, 32, 48)  // braço esquerdo
        }
        return out
    }

    /**
     * Aplica os itens sobre a skin base e devolve uma nova skin 64x64.
     * A skin base nunca é modificada. Ordem das camadas: calças, calçados, camisa,
     * colar, mochila, máscara, óculos, fones, especiais e, por último, o chapéu.
     */
    fun composeSkin(base: Bitmap, selection: CosmeticSelection): Bitmap {
        val out = toModern(base).let { if (it.isMutable) it else it.copy(Bitmap.Config.ARGB_8888, true) }
        val painter = SkinPainter(out)
        val order = listOf(
            CosmeticCategory.PANTS, CosmeticCategory.SHOES, CosmeticCategory.SHIRT,
            CosmeticCategory.NECKLACE, CosmeticCategory.BACKPACK, CosmeticCategory.MASK,
            CosmeticCategory.GLASSES, CosmeticCategory.HEADPHONES, CosmeticCategory.SPECIAL,
            CosmeticCategory.HAT
        )
        for (category in order) {
            val id = selection.get(category) ?: continue
            find(id)?.paint?.invoke(painter)
        }
        return out
    }

    // -------------------------------------------------------- miniaturas

    private fun layer(canvas: Canvas, paint: Paint, skin: Bitmap, sx: Int, sy: Int, w: Int, h: Int, dx: Int, dy: Int) {
        canvas.drawBitmap(skin, Rect(sx, sy, sx + w, sy + h), Rect(dx, dy, dx + w, dy + h), paint)
    }

    /**
     * Miniatura do item (ou da aparência original, quando [item] é nulo) sobre a skin do jogador.
     * A região recortada depende do tipo do item: cabeça, tronco, costas, pernas ou pés.
     */
    fun thumbnail(base: Bitmap, item: CosmeticItem?, region: ThumbRegion = item?.region ?: ThumbRegion.TORSO_ARMS): Bitmap {
        if (region == ThumbRegion.CAPE) {
            return item?.let { capeThumbnail(it.id) } ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }
        val selection = if (item == null) CosmeticSelection() else CosmeticSelection().with(item.category, item.id)
        val skin = composeSkin(base, selection)
        val paint = Paint().apply { isFilterBitmap = false }
        return when (region) {
            ThumbRegion.HEAD -> {
                val out = Bitmap.createBitmap(8, 12, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 8, 4, 8, 4, 0, 0)     // topo (base)
                layer(cv, paint, skin, 40, 4, 8, 4, 0, 0)    // topo (camada externa)
                layer(cv, paint, skin, 8, 8, 8, 8, 0, 4)     // rosto (base)
                layer(cv, paint, skin, 40, 8, 8, 8, 0, 4)    // rosto (camada externa)
                out
            }
            ThumbRegion.TORSO_FRONT -> {
                val out = Bitmap.createBitmap(8, 12, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 20, 20, 8, 12, 0, 0)
                layer(cv, paint, skin, 20, 36, 8, 12, 0, 0)
                out
            }
            ThumbRegion.TORSO_BACK -> {
                val out = Bitmap.createBitmap(8, 12, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 32, 20, 8, 12, 0, 0)
                layer(cv, paint, skin, 32, 36, 8, 12, 0, 0)
                out
            }
            ThumbRegion.TORSO_ARMS -> {
                val out = Bitmap.createBitmap(16, 12, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 44, 20, 4, 12, 0, 0)    // braço direito
                layer(cv, paint, skin, 44, 36, 4, 12, 0, 0)
                layer(cv, paint, skin, 20, 20, 8, 12, 4, 0)    // tronco
                layer(cv, paint, skin, 20, 36, 8, 12, 4, 0)
                layer(cv, paint, skin, 36, 52, 4, 12, 12, 0)   // braço esquerdo
                layer(cv, paint, skin, 52, 52, 4, 12, 12, 0)
                out
            }
            ThumbRegion.LEGS -> {
                val out = Bitmap.createBitmap(8, 12, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 4, 20, 4, 12, 0, 0)     // perna direita
                layer(cv, paint, skin, 4, 36, 4, 12, 0, 0)
                layer(cv, paint, skin, 20, 52, 4, 12, 4, 0)    // perna esquerda
                layer(cv, paint, skin, 4, 52, 4, 12, 4, 0)
                out
            }
            ThumbRegion.FEET -> {
                val out = Bitmap.createBitmap(8, 6, Bitmap.Config.ARGB_8888)
                val cv = Canvas(out)
                layer(cv, paint, skin, 4, 26, 4, 6, 0, 0)
                layer(cv, paint, skin, 4, 42, 4, 6, 0, 0)
                layer(cv, paint, skin, 20, 58, 4, 6, 4, 0)
                layer(cv, paint, skin, 4, 58, 4, 6, 4, 0)
                out
            }
            ThumbRegion.CAPE -> out1()
        }
    }

    private fun out1(): Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    // ------------------------------------------------------------- capas

    /** Gera a textura 64x32 da capa local. Retorna null para id desconhecido. */
    fun capeBitmap(id: String): Bitmap? {
        if (capes.none { it.id == id }) return null
        val bmp = Bitmap.createBitmap(64, 32, Bitmap.Config.ARGB_8888)
        val p = SkinPainter(bmp)

        // pinta a "frente" (1,1) e as "costas" (12,1) com o mesmo desenho
        fun panel(ox: Int, body: (lx: Int, ly: Int) -> Int) {
            for (ly in 0 until 16) for (lx in 0 until 10) p.px(ox + lx, 1 + ly, body(lx, ly))
        }

        fun design(x: Int, y: Int): Int = when (id) {
            "cape_creeper" -> {
                val g = c(0xFF4CAF50)
                var col = if ((x * 7 + y * 13) % 5 == 0) shade(g, 0.82f) else g
                val eye = (x in 2..3 || x in 6..7) && y in 3..5
                val mouth = (x in 4..5 && y in 6..9) || (x in 3..6 && y in 8..11 && !(x in 4..5 && y in 10..11))
                if (eye || mouth) col = BLACK
                col
            }
            "cape_redstone" -> {
                var col = if ((x + y) % 4 == 0) shade(RED, 0.8f) else RED
                if (x == 0 || x == 9 || y == 0 || y == 15) col = RED_DARK
                if (abs(x - 4) + abs(y - 7) <= 3) col = WHITE
                if (abs(x - 4) + abs(y - 7) <= 1) col = BLACK
                col
            }
            "cape_ghost" -> {
                var col = if (y % 5 == 4) c(0xFFD9D6E6) else c(0xFFF2F0FA)
                if ((x in 2..3 || x in 6..7) && y in 4..6) col = BLACK
                if (x in 4..5 && y in 8..10) col = c(0xFF2A2538)
                if (y >= 14 && x % 2 == 0) col = TRANSPARENT
                col
            }
            "cape_ice" -> {
                var col = c(0xFF29B6F6)
                if ((x + y) % 6 == 0) col = c(0xFFB3E5FC)
                if (x == 0 || x == 9 || y == 0 || y == 15) col = c(0xFF0277BD)
                if (abs(x - y) % 6 == 0 && y in 3..12) col = c(0xFFE1F5FE)
                col
            }
            else -> { // cape_neon
                var col = c(0xFF14091F)
                if ((x + y) % 5 == 0) col = c(0xFF1E0F33)
                if (x == 0 || x == 9 || y == 0 || y == 15) col = NEON
                if (x == 1 || x == 8 || y == 1 || y == 14) col = PURPLE_DARK
                if (abs(x - 4) + abs(y - 7) <= 3 || abs(x - 5) + abs(y - 7) <= 3) col = MAGENTA
                if (abs(x - 4) + abs(y - 7) <= 1) col = WHITE
                col
            }
        }

        // laterais, topo e base com a cor predominante do desenho
        val edge = design(0, 8).let { if (it == TRANSPARENT) design(1, 8) else it }
        p.rect(1, 0, 10, 1, edge)
        p.rect(11, 0, 10, 1, edge)
        p.rect(0, 1, 1, 16, edge)
        p.rect(11, 1, 1, 16, edge)
        p.rect(21, 1, 1, 16, edge)
        panel(1, ::design)
        panel(12, ::design)
        return bmp
    }

    fun toPng(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        return stream.toByteArray()
    }

    fun capePng(id: String): ByteArray? = capeBitmap(id)?.let { toPng(it) }

    /** Miniatura 10x16 da capa (parte visível, as costas) */
    fun capeThumbnail(id: String): Bitmap? {
        val cape = capeBitmap(id) ?: return null
        return Bitmap.createBitmap(cape, 12, 1, 10, 16)
    }
}
