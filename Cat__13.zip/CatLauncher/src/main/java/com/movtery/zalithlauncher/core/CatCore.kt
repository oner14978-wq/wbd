/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.core

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken
import com.movtery.zalithlauncher.game.multirt.Runtime
import com.movtery.zalithlauncher.game.versioninfo.models.AssetIndexJson
import com.movtery.zalithlauncher.game.versioninfo.models.GameManifest
import com.movtery.zalithlauncher.game.versioninfo.models.VersionManifest
import java.io.File

/**
 * Fachada Kotlin do núcleo Rust (CatCore).
 *
 * Concentra a (de)serialização JSON entre os modelos Gson do app e o núcleo.
 * Toda a lógica de versões, bibliotecas, argumentos de lançamento e runtimes
 * vive em Rust; aqui só há adaptação de tipos.
 */
object CatCore {
    /**
     * `enableComplexMapKeySerialization` faz as chaves de `natives`
     * (`OperatingSystem`) saírem como "linux" (via @SerializedName), e não
     * como o nome da constante do enum.
     */
    private val gson: Gson = GsonBuilder().enableComplexMapKeySerialization().create()

    private val libraryListType = object : TypeToken<List<GameManifest.Library>>() {}.type
    private val stringListType = object : TypeToken<List<String>>() {}.type

    // ------------------------------------------------------------ versões

    /** Valida e normaliza o JSON do manifesto de versões. */
    fun parseVersionManifest(rawJson: String): VersionManifest =
        gson.fromJson(CatCoreNative.parseVersionManifest(rawJson), VersionManifest::class.java)

    /** Junta versões ocultas e ordena por `releaseTime` decrescente. */
    fun mergeUnlistedVersions(manifest: VersionManifest, unlistedJson: String): VersionManifest =
        gson.fromJson(
            CatCoreNative.mergeUnlistedVersions(gson.toJson(manifest), unlistedJson),
            VersionManifest::class.java
        )

    /** Tipo de lançamento: release, snapshot, old_beta, old_alpha, april_fools, unknown. */
    fun classifyVersion(type: String?, aprilFools: Boolean): String =
        CatCoreNative.classifyVersion(type ?: "", aprilFools)

    fun compareVersions(a: String, b: String): Int = CatCoreNative.compareVersions(a, b)

    // -------------------------------------------------------- bibliotecas

    /** Aplica substituições de bibliotecas incompatíveis (jna, oshi, asm-all). */
    fun processLibraries(libraries: List<GameManifest.Library>): List<GameManifest.Library> =
        gson.fromJson(CatCoreNative.processLibraries(gson.toJson(libraries)), libraryListType)

    /** Mantém só a versão mais nova de cada coordenada com as mesmas regras. */
    fun uniqueLibraries(libraries: List<GameManifest.Library>): List<GameManifest.Library> =
        gson.fromJson(CatCoreNative.uniqueLibraries(gson.toJson(libraries)), libraryListType)

    /** Caminho relativo do artefato, ou `null` se o nome for inválido. */
    fun libraryPath(library: GameManifest.Library): String? =
        CatCoreNative.libraryPath(gson.toJson(library)).takeIf { it.isNotEmpty() }

    fun detectLwjglVersion(libraries: List<GameManifest.Library>): Int =
        CatCoreNative.detectLwjglVersion(gson.toJson(libraries))

    class PlannedDownload(
        val url: String,
        val sha1: String?,
        val target: File,
        val size: Long,
        val downloadable: Boolean
    )

    private class RawPlannedDownload(
        @SerializedName("url") val url: String,
        @SerializedName("sha1") val sha1: String?,
        @SerializedName("target") val target: String,
        @SerializedName("size") val size: Long,
        @SerializedName("downloadable") val downloadable: Boolean
    ) {
        fun toPlanned() = PlannedDownload(url, sha1, File(target), size, downloadable)
    }

    private class RawLibraryPlan(
        @SerializedName("libraries") val libraries: List<GameManifest.Library>,
        @SerializedName("items") val items: List<RawPlannedDownload>
    )

    class LibraryPlan(
        /** Bibliotecas já com as substituições aplicadas. */
        val libraries: List<GameManifest.Library>,
        val items: List<PlannedDownload>
    )

    fun planLibraries(libraries: List<GameManifest.Library>, targetDir: File): LibraryPlan {
        val raw = gson.fromJson(
            CatCoreNative.planLibraries(gson.toJson(libraries), targetDir.absolutePath),
            RawLibraryPlan::class.java
        )
        return LibraryPlan(raw.libraries, raw.items.map { it.toPlanned() })
    }

    fun planAssets(index: AssetIndexJson, resourcesDir: File, assetsDir: File): List<PlannedDownload> {
        val type = object : TypeToken<List<RawPlannedDownload>>() {}.type
        val raw: List<RawPlannedDownload> = gson.fromJson(
            CatCoreNative.planAssets(gson.toJson(index), resourcesDir.absolutePath, assetsDir.absolutePath),
            type
        )
        return raw.map { it.toPlanned() }
    }

    // ---------------------------------------------------------- lançamento

    /** Entrada de [launchClasspath] / [jvmArgs] / [clientArgs]. Nomes = campos Rust. */
    class LaunchParams(
        @SerializedName("manifest") val manifest: GameManifest,
        @SerializedName("libraries_home") val librariesHome: String,
        @SerializedName("components_dir") val componentsDir: String,
        @SerializedName("lwjgl_version") val lwjglVersion: Int,
        @SerializedName("mio_launch_wrapper") val mioLaunchWrapper: String,
        @SerializedName("client_jar") val clientJar: String,
        @SerializedName("runtime_library_path") val runtimeLibraryPath: String,
        @SerializedName("cache_dir") val cacheDir: String,
        @SerializedName("version_name") val versionName: String,
        @SerializedName("version_type") val versionType: String,
        @SerializedName("launcher_name") val launcherName: String,
        @SerializedName("launcher_version") val launcherVersion: String,
        @SerializedName("assets_home") val assetsHome: String,
        @SerializedName("game_dir") val gameDir: String,
        @SerializedName("access_token") val accessToken: String,
        @SerializedName("username") val username: String,
        @SerializedName("profile_id") val profileId: String,
        @SerializedName("xuid") val xuid: String
    )

    fun launchClasspath(params: LaunchParams): String =
        CatCoreNative.launchClasspath(gson.toJson(params))

    fun jvmArgs(params: LaunchParams): List<String> =
        gson.fromJson(CatCoreNative.jvmArgs(gson.toJson(params)), stringListType)

    /**
     * Flags de JVM/GC do perfil de desempenho que ainda faltam em [existing].
     * [profile]: off, auto, low, balanced ou quality.
     */
    fun perfJvmArgs(
        profile: String,
        javaMajor: Int,
        cores: Int,
        ramMb: Int,
        existing: List<String>
    ): List<String> {
        if (profile == "off" || profile.isBlank()) return emptyList()
        val json = gson.toJson(
            mapOf(
                "profile" to profile,
                "java_major" to javaMajor,
                "cores" to cores,
                "ram_mb" to ramMb,
                "existing" to existing
            )
        )
        return gson.fromJson(CatCoreNative.perfJvmArgs(json), stringListType)
    }

    fun clientArgs(params: LaunchParams): List<String> =
        gson.fromJson(CatCoreNative.clientArgs(gson.toJson(params)), stringListType)

    // ------------------------------------------------------------ runtimes

    private class RawRuntime(
        @SerializedName("name") val name: String,
        @SerializedName("version_string") val versionString: String?,
        @SerializedName("arch") val arch: String?,
        @SerializedName("java_version") val javaVersion: Int,
        @SerializedName("is_jdk8") val isJdk8: Boolean
    ) {
        fun toRuntime(isProvidedByLauncher: (String) -> Boolean) = Runtime(
            name = name,
            versionString = versionString,
            arch = arch,
            javaVersion = javaVersion,
            isProvidedByLauncher = isProvidedByLauncher(name),
            isJDK8 = isJdk8
        )
    }

    fun loadRuntime(root: File, name: String, isProvidedByLauncher: (String) -> Boolean): Runtime =
        gson.fromJson(CatCoreNative.loadRuntime(root.absolutePath, name), RawRuntime::class.java)
            .toRuntime(isProvidedByLauncher)

    fun listRuntimes(root: File, isProvidedByLauncher: (String) -> Boolean): List<Runtime> {
        val type = object : TypeToken<List<RawRuntime>>() {}.type
        val raw: List<RawRuntime> = gson.fromJson(CatCoreNative.listRuntimes(root.absolutePath), type)
        return raw.map { it.toRuntime(isProvidedByLauncher) }
    }

    /** Nome do runtime (exato ou o mais próximo e compatível) ou `null`. */
    fun pickRuntime(root: File, major: Int, exact: Boolean): String? =
        CatCoreNative.pickRuntime(root.absolutePath, major, exact).takeIf { it.isNotEmpty() }

    fun postPrepareRuntime(root: File, name: String, nativeLibDir: File) {
        CatCoreNative.postPrepareRuntime(root.absolutePath, name, nativeLibDir.absolutePath)
    }

    fun installRuntime(
        src: File,
        root: File,
        name: String,
        nativeLibDir: File,
        onEntry: (String) -> Boolean
    ) {
        CatCoreNative.installRuntime(
            src.absolutePath, root.absolutePath, name, nativeLibDir.absolutePath, onEntry
        )
    }

    fun installRuntimeBinPack(
        universal: File,
        platformBins: File,
        root: File,
        name: String,
        binPackVersion: String,
        nativeLibDir: File,
        onEntry: (String) -> Boolean
    ) {
        CatCoreNative.installRuntimeBinPack(
            universal.absolutePath, platformBins.absolutePath, root.absolutePath,
            name, binPackVersion, nativeLibDir.absolutePath, onEntry
        )
    }

    // ------------------------------------------------------------ arquivos

    private val booleanListType = object : TypeToken<List<Boolean>>() {}.type

    /**
     * Verifica vários arquivos de uma vez, em paralelo, no Rust. `resultado[i]` vale para `items[i]`
     * (par arquivo + SHA-1 esperado). Arquivos já verificados e inalterados (tamanho + data) vêm do
     * cache em [cacheFile] sem ler o conteúdo. Lança exceção se a biblioteca nativa falhar.
     */
    fun verifyFiles(items: List<Pair<File, String>>, cacheFile: File, threads: Int): List<Boolean> {
        if (items.isEmpty()) return emptyList()
        val json = gson.toJson(
            mapOf(
                "cache_path" to cacheFile.absolutePath,
                "threads" to threads,
                "items" to items.map { (file, sha1) -> mapOf("path" to file.absolutePath, "sha1" to sha1) }
            )
        )
        val result: List<Boolean> = gson.fromJson(CatCoreNative.verifyFiles(json), booleanListType)
        check(result.size == items.size) { "verifyFiles: resposta com tamanho inesperado" }
        return result
    }

    fun compareSha1(file: File, expected: String?, default: Boolean): Boolean =
        CatCoreNative.compareSha1(file.absolutePath, expected, default)

    // ----------------------------------------------------------- downloads

    /**
     * Chave do motor de downloads em Rust. Desligada por padrão até o motor ser
     * validado em dispositivo; com ela desligada vale o motor Kotlin legado.
     */
    @Volatile
    var nativeDownloads: Boolean = false

    class NativeRequest(
        @SerializedName("urls") val urls: List<String>,
        @SerializedName("target") val target: String,
        @SerializedName("sha1") val sha1: String?,
        @SerializedName("expected_size") val expectedSize: Long
    )

    class NativeOptions(
        @SerializedName("max_connections") val maxConnections: Int,
        @SerializedName("retry_rounds") val retryRounds: Int,
        @SerializedName("per_source_retries") val perSourceRetries: Int,
        @SerializedName("preloaded_files") val preloadedFiles: Int,
        @SerializedName("preloaded_bytes") val preloadedBytes: Long,
        @SerializedName("user_agent") val userAgent: String,
        @SerializedName("systemic_abort") val systemicAbort: Boolean
    )

    class NativeFailure(
        @SerializedName("index") val index: Int,
        @SerializedName("path") val path: String,
        @SerializedName("error") val error: String,
        @SerializedName("http_code") val httpCode: Int?
    )

    class NativeBatchResult(
        @SerializedName("failures") val failures: List<NativeFailure>,
        @SerializedName("cancelled") val cancelled: Boolean,
        @SerializedName("systemic_abort") val systemicAbort: Boolean,
        @SerializedName("completed_files") val completedFiles: Long
    )

    fun newBatchHandle(): Long = CatCoreNative.newBatchHandle()
    fun cancelBatch(handle: Long) = CatCoreNative.cancelBatch(handle)
    fun releaseBatchHandle(handle: Long) = CatCoreNative.releaseBatchHandle(handle)

    fun downloadBatch(
        handle: Long,
        requests: List<NativeRequest>,
        options: NativeOptions,
        onProgress: (LongArray) -> Boolean,
        onFile: (Int) -> Unit
    ): NativeBatchResult = gson.fromJson(
        CatCoreNative.downloadBatch(handle, gson.toJson(requests), gson.toJson(options), onProgress, onFile),
        NativeBatchResult::class.java
    )
}
