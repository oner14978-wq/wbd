/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.version.download

import com.movtery.zalithlauncher.core.CatCore
import com.movtery.zalithlauncher.coroutine.Task
import com.movtery.zalithlauncher.game.download.engine.BatchProgress
import com.movtery.zalithlauncher.game.download.engine.HttpResultException
import com.movtery.zalithlauncher.path.URL_USER_AGENT
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicReference

/**
 * Executa o lote com o motor de downloads em Rust (CatCore).
 *
 * - O Rust faz HTTP, paralelismo, SHA-1 em streaming, retentativas, troca de
 *   mirrors (a lista de URLs já vem ordenada por [DownloadTask.urls]), arquivo
 *   temporário + rename atômico e cancelamento.
 * - O progresso chega por callback JNI e é repassado a cada 100 ms.
 * - `fileDownloadedTask` roda numa corrotina consumidora, fora da thread nativa.
 * - O cancelamento da corrotina é percebido pelo callback de progresso (≤100 ms).
 *
 * Diferença deliberada em relação ao motor legado: [acceptFailure] é avaliado
 * depois do lote; por isso o disjuntor de falhas sistêmicas fica desligado
 * quando o chamador tolera falhas.
 */
internal suspend fun Task.runNativeBatch(
    reusable: List<DownloadTask>,
    pending: List<DownloadTask>,
    maxConnections: Int,
    retryRounds: Int,
    sizesFullyKnown: Boolean,
    onSnapshot: suspend (BatchProgress) -> Unit,
    acceptFailure: ((task: DownloadTask, error: Throwable) -> Boolean)?
) {
    reusable.forEach { it.runFileDownloadedTask() }
    if (pending.isEmpty()) {
        updateProgress(1f)
        return
    }

    val requests = pending.map {
        CatCore.NativeRequest(it.urls, it.targetFile.absolutePath, it.sha1, it.size)
    }
    val options = CatCore.NativeOptions(
        maxConnections = maxConnections,
        retryRounds = retryRounds,
        perSourceRetries = 5,
        preloadedFiles = reusable.size,
        preloadedBytes = reusable.sumOf { maxOf(it.size, 0L) },
        userAgent = URL_USER_AGENT,
        systemicAbort = acceptFailure == null
    )

    val latest = AtomicReference<BatchProgress?>(null)
    val done = Channel<Int>(Channel.UNLIMITED)
    val handle = CatCore.newBatchHandle()
    try {
        val result = coroutineScope {
            val scope = this
            val consumer = launch { for (i in done) pending[i].runFileDownloadedTask() }
            val reporter = launch(Dispatchers.Default) {
                while (isActive) {
                    delay(100)
                    latest.get()?.let { snapshot ->
                        updateProgress(progressFor(snapshot, sizesFullyKnown, snapshot.totalFiles > 0))
                        onSnapshot(snapshot)
                    }
                }
            }
            try {
                withContext(Dispatchers.IO) {
                    CatCore.downloadBatch(
                        handle = handle,
                        requests = requests,
                        options = options,
                        onProgress = { v ->
                            latest.set(
                                BatchProgress(
                                    downloadedBytes = v[0],
                                    totalBytes = v[1],
                                    downloadedFiles = v[2].toInt(),
                                    totalFiles = v[3].toInt(),
                                    speedBytesPerSec = v[4]
                                )
                            )
                            scope.isActive //false => cancela o lote nativo
                        },
                        onFile = { i -> done.trySend(i) }
                    )
                }
            } finally {
                done.close()
                reporter.cancelAndJoin()
                consumer.join()
            }
        }

        // cancelamento da corrotina: o lote nativo parou; propaga como cancelamento
        currentCoroutineContext().ensureActive()

        if (result.systemicAbort) {
            val detail = result.failures.take(20).joinToString("\n") { it.path }
            throw DownloadFailedException(
                "Batch aborted after repeated permanent failures with no successful download:\n$detail"
            )
        }

        val unaccepted = result.failures.filter { f ->
            val cause: Throwable = f.httpCode
                ?.let { HttpResultException(it, f.error) }
                ?: java.io.IOException(f.error)
            acceptFailure?.invoke(pending[f.index], cause) != true
        }
        if (unaccepted.isNotEmpty()) {
            throw DownloadFailedException(
                "Failed downloads:\n" + unaccepted.joinToString("\n") { it.path },
                java.io.IOException(unaccepted.first().error)
            )
        }
        updateProgress(1f)
    } catch (e: CancellationException) {
        CatCore.cancelBatch(handle)
        throw e
    } finally {
        CatCore.releaseBatchHandle(handle)
        clearSpeed()
    }
}
