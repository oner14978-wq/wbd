/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.game.multirt

import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.components.jre.Jre
import com.movtery.zalithlauncher.core.CatCore
import com.movtery.zalithlauncher.path.PathManager
import com.movtery.zalithlauncher.utils.file.child
import com.movtery.zalithlauncher.utils.logging.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.apache.commons.io.FileUtils
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "RuntimesManager"

/**
 * Gerenciador de runtimes Java.
 *
 * A leitura do arquivo `release`, a ordenação/seleção de runtimes, a extração
 * de `.tar.xz`, o unpack200 e os ajustes pós-instalação são feitos em Rust
 * (`CatCore`). Aqui ficam apenas o cache, a remoção e a integração com o app.
 *
 * [Modified from PojavLauncher](https://github.com/PojavLauncherTeam/PojavLauncher/blob/v3_openjdk/app_pojavlauncher/src/main/java/net/kdt/pojavlaunch/multirt/MultiRTUtils.java)
 */
object RuntimesManager {
    private val cache = ConcurrentHashMap<String, Runtime>()

    private val RUNTIME_FOLDER = PathManager.DIR_MULTIRT

    private fun isProvidedByLauncher(name: String) = Jre.entries.any { it.jreName == name }

    fun getRuntimes(forceLoad: Boolean = false): List<Runtime> {
        if (!RUNTIME_FOLDER.exists()) {
            Logger.warning(TAG, "Runtime directory not found: ${RUNTIME_FOLDER.absolutePath}")
            return emptyList()
        }

        return CatCore.listRuntimes(RUNTIME_FOLDER) { isProvidedByLauncher(it) }
            .also { list -> list.forEach { cache[it.name] = it } }
    }

    fun getExactJreName(majorVersion: Int): String? =
        CatCore.pickRuntime(RUNTIME_FOLDER, majorVersion, exact = true)

    fun getNearestJreName(majorVersion: Int): String? =
        CatCore.pickRuntime(RUNTIME_FOLDER, majorVersion, exact = false)

    fun forceReload(name: String): Runtime {
        cache.remove(name)
        return loadRuntime(name)
    }

    fun loadRuntime(name: String, forceLoad: Boolean = false): Runtime {
        return cache[name]?.takeIf { !forceLoad } ?: runCatching {
            CatCore.loadRuntime(RUNTIME_FOLDER, name) { isProvidedByLauncher(it) }
        }.onFailure { e ->
            Logger.error(TAG, "Failed to load runtime $name", e)
        }.getOrElse {
            Runtime(name)
        }.also { cache[name] = it }
    }

    /**
     * O núcleo Rust trabalha com arquivos; o [InputStream] (ex.: asset do APK)
     * é gravado antes em um arquivo temporário no cache.
     */
    private fun InputStream.spoolToCache(prefix: String): File {
        val tmp = File.createTempFile(prefix, ".tar.xz", PathManager.DIR_CACHE.apply { mkdirs() })
        use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
        return tmp
    }

    @Throws(IOException::class)
    suspend fun installRuntime(
        nativeLibDir: String,
        inputStream: InputStream,
        name: String,
        updateProgress: (Int, Array<Any>) -> Unit = { _, _ -> }
    ) = withContext(Dispatchers.IO) {
        val source = inputStream.spoolToCache("runtime-")
        try {
            val ctx = currentCoroutineContext()
            CatCore.installRuntime(
                src = source,
                root = RUNTIME_FOLDER,
                name = name,
                nativeLibDir = File(nativeLibDir)
            ) { entry ->
                updateProgress(R.string.generic_unpacking, arrayOf(entry))
                ctx.isActive
            }
            ctx.ensureActive()
            cache.remove(name)
            loadRuntime(name)
        } catch (e: Exception) {
            cache.remove(name)
            currentCoroutineContext().ensureActive()
            throw e
        } finally {
            source.delete()
        }
    }

    @Throws(IOException::class)
    suspend fun postPrepare(name: String) = withContext(Dispatchers.IO) {
        if (!RUNTIME_FOLDER.child(name).exists()) return@withContext
        CatCore.postPrepareRuntime(RUNTIME_FOLDER, name, File(PathManager.DIR_NATIVE_LIB))
        cache.remove(name)
    }

    @Throws(IOException::class)
    suspend fun installRuntimeBinPack(
        universalFileInputStream: InputStream,
        platformBinsInputStream: InputStream,
        name: String,
        binPackVersion: String,
        updateProgress: (Int, Array<Any>) -> Unit = { _, _ -> }
    ) = withContext(Dispatchers.IO) {
        val universal = universalFileInputStream.spoolToCache("runtime-universal-")
        val bins = platformBinsInputStream.spoolToCache("runtime-bins-")
        try {
            val ctx = currentCoroutineContext()
            CatCore.installRuntimeBinPack(
                universal = universal,
                platformBins = bins,
                root = RUNTIME_FOLDER,
                name = name,
                binPackVersion = binPackVersion,
                nativeLibDir = File(PathManager.DIR_NATIVE_LIB)
            ) { entry ->
                updateProgress(R.string.generic_unpacking, arrayOf(entry))
                ctx.isActive
            }
            ctx.ensureActive()
            forceReload(name)
        } catch (e: Exception) {
            cache.remove(name)
            currentCoroutineContext().ensureActive()
            throw e
        } finally {
            universal.delete()
            bins.delete()
        }
    }

    fun loadInternalRuntimeVersion(name: String): String? {
        val versionFile = RUNTIME_FOLDER.child(name, "version")
        try {
            return if (versionFile.exists()) {
                versionFile.readText()
            } else {
                null
            }
        } catch (_: IOException) {
            return null
        }
    }

    @Throws(IOException::class)
    fun removeRuntime(name: String) {
        val dest: File = RUNTIME_FOLDER.child(name).takeIf { it.exists() } ?: return
        FileUtils.deleteDirectory(dest)
        cache.remove(name)
    }

    fun getRuntimeHome(name: String): File {
        val dest = RUNTIME_FOLDER.child(name)
        if (!dest.exists() || forceReload(name).versionString == null) {
            throw RuntimeException("Selected runtime is broken!")
        }

        return dest
    }

    fun isJDK8(runtimeDir: String): Boolean {
        return File(runtimeDir, "jre").exists() && File(runtimeDir, "bin/javac").exists()
    }
}
