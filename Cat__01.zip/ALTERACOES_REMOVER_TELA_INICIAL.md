# Remover a tela de inicialização (logotipo + barra roxa)

Copie por cima do projeto, mantendo os caminhos:
- CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/splash/SplashScreen.kt
- CatLauncher/src/main/res/drawable/splash_launcher.xml

## O que mudou
- `SplashScreen.kt`: apaguei a função `LoadingScreen` (logotipo, barra ondulada, animação de entrada). O estado interno `Loading` continua existindo só para a verificação dos arquivos, mas agora não desenha nada.
- `splash_launcher.xml`: era o ícone do splash do sistema (Android 12+); virou um vetor totalmente transparente.

## Preservado de propósito
- Welcome / acordo de licença e Unpacking (extração dos componentes e Java na primeira execução ou após atualização): são telas funcionais, não de carregamento. Sem elas o app não conseguiria instalar os componentes.
- Importação de modpack/controles, MainActivity e carregadores de inicialização: intactos.

## Limitação
O Android 12+ sempre mostra uma janela de splash do sistema; não dá para desligá-la, apenas deixá-la sem ícone (feito). Enquanto os arquivos são verificados, aparece só o fundo do tema, sem elementos.

NÃO TESTADO: não compilei (sem Android SDK). Rode `./gradlew :CatLauncher:assembleDebug`.
