# Alterações — Personalizar Personagem (tema roxo neon)

## Arquivos novos
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/game/account/wardrobe/CharacterCosmetics.kt`
  Catálogo (7 chapéus, 5 roupas, 5 acessórios, 5 capas locais), pintor de pixels sobre a skin 64x64,
  miniaturas e armazenamento (itens escolhidos + skin original, para permitir remover itens).
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/elements/CharacterCustomizer.kt`
  Nova tela `CharacterCustomizerDialog` (visual roxo/preto neon, modelo 3D com rotação e animações).

## Arquivos alterados (mudanças pequenas)
- `ui/screens/content/AccountManageScreen.kt`: usa a nova tela no lugar de `ChangeSkinDialog`
  (a função antiga continua no código, sem uso).
- `viewmodel/AccountManageViewModel.kt`: novo intent `ApplyLocalCape` + `applyLocalCape`.
- `game/account/offline/OfflineYggdrasilServer.kt`: o servidor offline agora entrega a capa local ao jogo.
- `ui/screens/content/elements/AccountElements.kt`: item do menu da conta passa a se chamar "Personalizar Personagem".
- `res/values/strings.xml`, `res/values-pt-rBR/strings.xml`, `res/values-pt/strings.xml`: textos novos (`cosmetic_*`).

## Como funciona
- Chapéus, roupas e acessórios são desenhados nas camadas externas da skin; ao aplicar, a skin composta é
  salva (conta offline) ou enviada (conta Microsoft) pelo mesmo caminho que já existia.
- A skin original fica guardada, então "Nenhum", tocar de novo no item ou "Remover tudo" volta ao original.
- Capas locais funcionam em contas offline. Contas Microsoft usam as capas reais do perfil (Selecionar Capa).
- Importar Skin, estilo de braço (grosso/fino) e Redefinir mantêm o comportamento anterior.
- Setas ‹ › giram o personagem; também dá para arrastar. Chips: Parado / Andando / Girar.

## NÃO TESTADO
Este código foi escrito sem Android SDK/Gradle disponíveis, então não foi compilado nem executado.
Rode `./gradlew :ZalithLauncher:assembleDebug` e me envie qualquer erro para corrigir.

## Binários omitidos deste ZIP (limite de tamanho)
Arquivos maiores que 1 MB (bibliotecas nativas, JREs, .aar) não estão aqui. Veja `ARQUIVOS_OMITIDOS.txt`.
Copie este conteúdo por cima do seu projeto original (ele já tem esses arquivos).
