# Remover a interface antiga (hub de busca: Todos/Realidade/Fantasia/Vanilla + filtros)

Origem encontrada: `DownloadScreen` (abas + barra "instalados") -> `SearchAddonScreen` (trilho de categorias + painel "Nome da Pesquisa / Versão do jogo / Plataforma Alvo"). Era aberta pelo ícone de lupa da Home e pelos atalhos "baixar" das telas de mods/texturas/shaders/mundos.

## Alterado
- `home/HomeDashboard.kt`: removido o ícone de pesquisa e a ação `onDownload`.
- `LauncherScreen.kt`: removida a ligação `onDownload`.
- `DownloadScreen.kt`: removidas as funções `TabMenu` e `InstalledBar` (e as chamadas); `navigateToDownload` agora só abre o download do JOGO. Qualquer pedido para as telas de busca antigas (mods, texturas, addons, mundos, shaders) volta para a Home.

## Resultado
- Ao abrir o CatLauncher aparece só a Home nova (a pilha inicial já era `LauncherMain`; nada antigo é empilhado).
- Nenhum caminho do app chega mais ao trilho, à busca, ao campo de versão nem ao seletor de plataforma.
- Não recriei busca nem filtros.

## Código morto que ainda existe (inalcançável)
`SearchAddonScreen.kt`, `Search*Screen.kt`, `NeonContentUi.kt` (rail/abas/barra), `_Search.Filter.kt`. Ainda são referenciados por Favoritos/Por ID/detalhe de projeto, por isso não apaguei às cegas; podem ser removidos num próximo passo com o build rodando.

## NÃO TESTADO
Sem Android SDK/Gradle aqui: não compilei. Rode `./gradlew :CatLauncher:assembleDebug` e me mande erros.
