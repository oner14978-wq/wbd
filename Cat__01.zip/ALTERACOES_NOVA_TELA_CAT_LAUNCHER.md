# Nova tela principal — Cat Launcher (reprodução da 2ª imagem)

Arquivos alterados:
- CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/home/HomeDashboard.kt (reescrito por completo)
- CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/LauncherScreen.kt (ações da Home)

Tudo é desenhado em código (Canvas), sem nenhuma imagem/recurso pronto: céu roxo, estrelas, nuvens e árvores de blocos, lua em bloco, água com reflexos, figura escura à esquerda, gato preto à direita, logotipo (gato + painel + "Cat Launcher") e fonte pixelada própria 5x7.

Botões (todos reais):
- Adicionar a versão -> abre o download de uma nova versão do jogo. A seta (v) à direita abre a lista de versões instaladas para escolher a versão atual.
- Jogar -> inicia o Minecraft com a versão selecionada (sem versão válida, abre o download de versão).
- Criar Conta -> abre direto o diálogo de criação de conta offline.

Removido da Home: barra inferior (Início/Personagem/Mods/...), ícones de notificação/coroa, logo "If Cauê Launcher", castelo, dragão.

NÃO TESTADO (sem Android SDK): rode ./gradlew :CatLauncher:assembleDebug.
