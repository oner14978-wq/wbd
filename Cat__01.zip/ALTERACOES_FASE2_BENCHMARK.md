# Fase 2 — Otimização e benchmark (Cat Launcher)

## Estado honesto desta entrega
- **NADA foi compilado, executado ou medido.** Não havia Android SDK, Gradle, Kotlin, Rust/NDK nem aparelho no ambiente de trabalho.
  Todo o código novo foi escrito por leitura do projeto e só passou por conferência de chaves/parênteses.
  **Rode `./gradlew :CatLauncher:testDebugUnitTest :CatLauncher:assembleDebug` e envie os erros.**
- **Não existem resultados de desempenho (antes/depois) nesta entrega.** Veja `RELATORIO_DESEMPENHO.md`.
- Rust/CatCore e JNI **não foram alterados** (sem `cargo`/NDK para compilar e testar; mexer às cegas arriscaria ARM64/ARMv7).

## Arquivos NOVOS (caminhos relativos à raiz do projeto)
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/startup/LaunchTimeline.kt` — linha do tempo Jogar → jogável, em arquivo, compartilhada entre o processo principal e o `:game` (relógio `SystemClock.elapsedRealtime()`, igual em todos os processos).
- `.../startup/LaunchProbes.kt` — sondas no processo `:game`: leitor do log do jogo (etapas intermediárias), amostrador de RAM/CPU via `/proc` (1 amostra/s) e o gatilho final "jogável".
- `.../startup/BenchmarkReport.kt` — cálculo das métricas, JSON por execução (`runs/run_*.json`), `last_report.md` e `launcher_metrics.json`.
- `.../startup/UiTimings.kt` — tempo de abertura de telas (navegação → 2º quadro desenhado).
- `CatLauncher/src/test/.../startup/LaunchBenchmarkTest.kt` — testes JVM do reconhecimento de log, parsers de `/proc`, linha do tempo e cálculo.
- `tools/benchmark/run_benchmark.sh` — coleta via adb (abertura a frio com `am start -W`, N jogadas, puxa os JSONs).
- `tools/benchmark/compare_reports.py` — tabelas e comparação antes/depois; `--selftest` valida o cálculo (dados sintéticos, declarados como tais).

## Arquivos MODIFICADOS
| Arquivo | Mudança |
|---|---|
| `game/launch/GameLaunchFlow.kt` | marca o clique em Jogar e "arquivos prontos"; mede `account_check` e `mods_scan`; **otimização**: `runGame` antes do `delay` da animação final |
| `game/launch/Launcher.kt` | marcos de ambiente/bibliotecas/criação da JVM; mede `lwjgl_verify`; **otimização**: dlopen sem repetição |
| `game/launch/handler/AbstractHandler.kt` | liga as sondas no processo do jogo |
| `ui/activities/VMActivity.kt` | marco "processo do jogo iniciado" |
| `org/lwjgl/glfw/CallbackBridge.java` | primeira captura do cursor ⇒ "jogável" |
| `startup/StartupCoordinator.kt` | grava a abertura do launcher para o relatório |
| `ui/screens/BackStackNavKey.kt` | mede a abertura de cada tela navegada |

## O que significa "mundo jogável"
O Minecraft só captura o cursor (`glfwSetInputMode … CURSOR_DISABLED`) quando o jogador está no mundo sem nenhuma tela aberta. A primeira captura recebida em `CallbackBridge.onGrabStateChanged(true)` encerra a medição. Não depende de texto de log nem de tela de carregamento. **Não validado em aparelho**: se alguma versão/mod capturar o cursor antes (ex.: durante a carga), o tempo sairá menor que o real; se nunca capturar, a execução fica "não medida".

## Etapas medidas (ordem real do código)
Clique → arquivos prontos → processo `:game` → ambiente Java → dlopen runtime → dlopen motor → criação da JVM → 1º log do Java → carregador de mods → Minecraft iniciando → recarga de recursos → mundo carregando → **jogável**.
As etapas intermediárias após a JVM vêm de padrões do log (log4j, Fabric/Quilt/Forge/NeoForge); em versões antigas alguma pode faltar e aparece como `n/d` (nunca como 0). Sub-etapas: `lwjgl_verify`, `runtime_so_scan`, `dlopen_runtime_count`, `dlopen_runtime_duplicates_skipped`, `dlopen_slow:<lib>` (≥50 ms), `account_check`, `mods_scan`.

## Otimizações realizadas (todas sem medição de ganho)
1. **Animação final sobreposta à subida do `:game`** (`GameLaunchFlow`): antes `delay(300 ms) → runGame → exitActivity`; agora `runGame → delay(300 ms) → exitActivity`. Mesma animação e mesmo limite; os 300 ms deixam de somar antes do início do processo do jogo. Risco: se o escopo do fluxo for cancelado ao parar a MainActivity, `exitActivity()` não roda (a Activity só ficaria aberta atrás do jogo). Verificar em aparelho.
2. **dlopen sem repetição** (`Launcher.dlopenJavaRuntime`): 10 bibliotecas eram carregadas explicitamente e de novo na varredura recursiva de `runtimeHome`. Cada caminho normalizado agora é carregado uma vez; a ordem original é mantida. Ganho provavelmente pequeno (dlopen repetido é só contagem de referência), mas agora é medido (`dlopen_runtime_duplicates_skipped`).

Já existiam da fase 1 e foram reaproveitados, sem duplicar: cache de impressão digital da verificação de componentes (LWJGL, etc.), carregamento paralelo e módulos preguiçosos. Nenhuma verificação de segurança foi desativada.

## Candidatos identificados e NÃO implementados (precisam de medição primeiro)
- Reabrir/validar o `Runtime` com `RuntimesManager.forceReload` a cada jogada (`JvmLauncher`/`GameLauncher`): custo desconhecido, não instrumentado.
- `GameLauncher.launch` faz parse do JSON da versão e, em seguida, do `launchManifest` já pronto.
- `AllModReader.readAllLocals()` a cada jogada: com muitos mods, um cache em disco por (caminho, tamanho, data) pode ajudar; `mods_scan` agora mede isso.
- Extração do JRE na primeira execução usa `lzma-rs` (Rust puro); só afeta a 1ª inicialização. Comparar com um descompressor nativo exige NDK.
- Interface/configurações: não encontrei no código, por leitura, consultas repetidas ao armazenamento que justificassem mudança às cegas; `UiTimings` identifica quais telas realmente demoram. Sem esses números, não alterei composables.
- JNI Kotlin↔Rust: a ponte troca JSON em `String`; sem perfil não há evidência de que seja gargalo.
