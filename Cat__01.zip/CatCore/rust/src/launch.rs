//! Montagem do classpath e dos argumentos JVM / jogo.

use serde::Deserialize;
use serde_json::{Map, Value};
use std::path::Path;

use crate::manifest::{library_classpath, lwjgl_version_dir, Library};

#[derive(Debug, Default, Deserialize)]
pub struct Arguments {
    #[serde(default)]
    pub game: Vec<Value>,
    #[serde(default)]
    pub jvm: Vec<Value>,
}

#[derive(Debug, Default, Deserialize)]
pub struct AssetIndexRef {
    #[serde(default)]
    pub id: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct LaunchManifest {
    #[serde(default)]
    pub id: String,
    #[serde(default, rename = "type")]
    pub kind: Option<String>,
    #[serde(default, rename = "mainClass")]
    pub main_class: String,
    #[serde(default)]
    pub libraries: Vec<Library>,
    #[serde(default)]
    pub arguments: Option<Arguments>,
    #[serde(default, rename = "minecraftArguments")]
    pub minecraft_arguments: Option<String>,
    #[serde(default, rename = "assetIndex")]
    pub asset_index: Option<AssetIndexRef>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Default, Deserialize)]
pub struct LaunchParams {
    pub manifest: LaunchManifest,
    pub libraries_home: String,
    pub components_dir: String,
    pub lwjgl_version: i32,
    pub mio_launch_wrapper: String,
    pub client_jar: String,
    pub runtime_library_path: String,
    pub cache_dir: String,
    /// Nome da pasta da versão instalada (pode diferir de `manifest.id`).
    pub version_name: String,
    /// Valor de `${version_type}` (info customizada ou `manifest.type`).
    pub version_type: String,
    pub launcher_name: String,
    pub launcher_version: String,
    #[serde(default)]
    pub assets_home: String,
    #[serde(default)]
    pub game_dir: String,
    #[serde(default)]
    pub access_token: String,
    #[serde(default)]
    pub username: String,
    #[serde(default)]
    pub profile_id: String,
    #[serde(default)]
    pub xuid: String,
}

const SEP: &str = ":";

/// Ordem dos jars do LWJGL: núcleo, merged-modules, demais, ponte lwjglx.
fn lwjgl_jar_order(name: &str, version_dir: &str) -> i32 {
    if name == "lwjgl.jar" {
        0
    } else if name == format!("lwjgl-{}-merged-modules.jar", version_dir) {
        1
    } else if name == "lwjgl-lwjglx.jar" {
        3
    } else {
        2
    }
}

pub fn lwjgl_classpath(components_dir: &str, lwjgl_version: i32) -> String {
    let version_dir = lwjgl_version_dir(lwjgl_version);
    let dir = Path::new(components_dir).join("lwjgl").join(version_dir);
    let is_lwjgl2 = (1..=299).contains(&lwjgl_version);

    let Ok(read) = std::fs::read_dir(&dir) else {
        return String::new();
    };
    let mut files: Vec<(i32, String, String)> = read
        .filter_map(|e| e.ok())
        .filter_map(|e| {
            let name = e.file_name().to_string_lossy().into_owned();
            if !name.ends_with(".jar") {
                return None;
            }
            if !is_lwjgl2 && name == "lwjgl-lwjglx.jar" {
                return None;
            }
            let abs = e.path().to_string_lossy().into_owned();
            Some((lwjgl_jar_order(&name, version_dir), name, abs))
        })
        .collect();
    files.sort();
    files.into_iter().map(|(_, _, p)| p).collect::<Vec<_>>().join(SEP)
}

/// Classpath completo de execução: LWJGL + wrapper + bibliotecas + client.jar.
pub fn launch_classpath(p: &LaunchParams) -> String {
    let mut parts: Vec<String> = vec![
        lwjgl_classpath(&p.components_dir, p.lwjgl_version),
        p.mio_launch_wrapper.clone(),
    ];
    for jar in library_classpath(&p.manifest.libraries, &p.libraries_home) {
        if Path::new(&jar).exists() {
            parts.push(jar);
        }
    }
    if Path::new(&p.client_jar).exists() {
        parts.push(p.client_jar.clone());
    }
    parts.join(SEP)
}

fn insert_values(args: Vec<String>, vars: &[(&str, String)]) -> Vec<String> {
    args.into_iter()
        .map(|a| {
            vars.iter()
                .fold(a, |acc, (k, v)| acc.replace(&format!("${{{}}}", k), v))
        })
        .collect()
}

/// Argumentos JVM definidos pelo manifesto (somente entradas string).
pub fn jvm_args(p: &LaunchParams) -> Vec<String> {
    let cp = launch_classpath(p);
    let vars: Vec<(&str, String)> = vec![
        ("classpath_separator", SEP.to_string()),
        ("library_directory", p.libraries_home.clone()),
        ("version_name", p.manifest.id.clone()),
        ("natives_directory", p.runtime_library_path.clone()),
        ("launcher_name", p.launcher_name.clone()),
        ("launcher_version", p.launcher_version.clone()),
        ("version_type", p.version_type.clone()),
    ];

    let mut has_classpath = false;
    let mut out: Vec<String> = Vec::new();
    let raw = p.manifest.arguments.as_ref().map(|a| a.jvm.as_slice()).unwrap_or(&[]);

    for item in raw {
        let Some(arg) = item.as_str() else { continue };
        let processed = if arg.starts_with("-Djava.library.path=") {
            // 26.2+: a Mojang passou a usar caminho concreto; redireciona
            "-Djava.library.path=${natives_directory}".to_string()
        } else if arg.starts_with("-DignoreList=") {
            format!("{},{}.jar", arg, p.version_name)
        } else if arg.contains("-Dio.netty.native.workdir")
            || arg.contains("-Djna.tmpdir")
            || arg.contains("-Dorg.lwjgl.system.SharedLibraryExtractPath")
        {
            arg.replace("${natives_directory}", &p.cache_dir)
        } else if arg == "${classpath}" {
            has_classpath = true;
            cp.clone()
        } else {
            arg.to_string()
        };
        out.push(processed);
    }

    let mut replaced = insert_values(out, &vars);
    if !has_classpath {
        replaced.push("-cp".to_string());
        replaced.push(cp);
    }
    replaced
}

/// Argumentos do jogo (`minecraftArguments` legado ou `arguments.game`).
pub fn client_args(p: &LaunchParams) -> Vec<String> {
    let vars: Vec<(&str, String)> = vec![
        ("auth_session", p.access_token.clone()),
        ("auth_access_token", p.access_token.clone()),
        ("auth_player_name", p.username.clone()),
        ("auth_uuid", p.profile_id.replace('-', "")),
        ("auth_xuid", p.xuid.clone()),
        ("assets_root", p.assets_home.clone()),
        (
            "assets_index_name",
            p.manifest
                .asset_index
                .as_ref()
                .map(|a| a.id.clone())
                .unwrap_or_default(),
        ),
        ("game_assets", p.assets_home.clone()),
        ("game_directory", p.game_dir.clone()),
        ("user_properties", "{}".to_string()),
        ("user_type", "msa".to_string()),
        ("version_name", p.manifest.id.clone()),
        ("launcher_name", p.launcher_name.clone()),
        ("launcher_version", p.launcher_version.clone()),
        ("version_type", p.version_type.clone()),
    ];

    let source = match &p.manifest.minecraft_arguments {
        Some(s) => s.clone(),
        None => p
            .manifest
            .arguments
            .as_ref()
            .map(|a| {
                a.game
                    .iter()
                    .filter_map(|v| v.as_str())
                    .collect::<Vec<_>>()
                    .join(" ")
            })
            .unwrap_or_default(),
    };
    let split: Vec<String> = source
        .split(' ')
        .filter(|s| !s.is_empty())
        .map(String::from)
        .collect();
    insert_values(split, &vars)
}

/// Divide por espaços respeitando aspas (`"a b" c` -> `a b`, `c`).
pub fn split_preserving_quotes(s: &str) -> Vec<String> {
    let mut result = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    let mut prev: Option<char> = None;
    for c in s.chars() {
        if c == '"' && prev != Some('\\') {
            in_quotes = !in_quotes;
        } else if c.is_whitespace() && !in_quotes {
            if !cur.is_empty() {
                result.push(std::mem::take(&mut cur));
            }
        } else {
            cur.push(c);
        }
        prev = Some(c);
    }
    if !cur.is_empty() {
        result.push(cur);
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    fn params(json: &str) -> LaunchParams {
        serde_json::from_str(json).unwrap()
    }

    const BASE: &str = r#"{
        "manifest": {"id":"1.20.1","type":"release","mainClass":"net.minecraft.client.main.Main",
          "assetIndex":{"id":"5"},
          "arguments":{"game":["--username","${auth_player_name}",{"rules":[]}],
                       "jvm":["-Djava.library.path=${natives_directory}","-cp","${classpath}","-DignoreList=a"]},
          "libraries":[]},
        "libraries_home":"/L","components_dir":"/C","lwjgl_version":333,
        "mio_launch_wrapper":"/w.jar","client_jar":"/nonexistent.jar",
        "runtime_library_path":"/nat","cache_dir":"/cache","version_name":"v",
        "version_type":"release","launcher_name":"Cat","launcher_version":"1",
        "username":"Steve","profile_id":"a-b-c"}"#;

    #[test]
    fn jvm_has_classpath_once() {
        let p = params(BASE);
        let a = jvm_args(&p);
        assert_eq!(a[0], "-Djava.library.path=/nat");
        assert_eq!(a[1], "-cp");
        assert_eq!(a[2], ":/w.jar");
        assert_eq!(a[3], "-DignoreList=a,v.jar");
        assert_eq!(a.len(), 4);
    }

    #[test]
    fn client_args_fill() {
        let p = params(BASE);
        assert_eq!(client_args(&p), vec!["--username", "Steve"]);
    }

    #[test]
    fn quotes() {
        assert_eq!(split_preserving_quotes(r#"-a "b c" d"#), vec!["-a", "b c", "d"]);
    }
}
