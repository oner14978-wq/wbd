//! Planejamento de downloads: bibliotecas e assets.
//! O transporte (mirrors, retry, progresso) continua no app; o Rust decide
//! O QUE baixar, para ONDE, com qual hash e tamanho.

use serde::{Deserialize, Serialize};
use std::path::Path;

use crate::manifest::{library_path, process_libraries, Library};

pub const MINECRAFT_RES: &str = "https://resources.download.minecraft.net/";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadItem {
    pub url: String,
    pub sha1: Option<String>,
    pub target: String,
    pub size: i64,
    pub downloadable: bool,
}

#[derive(Debug, Serialize)]
pub struct LibraryPlan {
    /// Bibliotecas após `process_libraries` (substituições aplicadas).
    pub libraries: Vec<Library>,
    pub items: Vec<DownloadItem>,
}

fn non_blank(s: &Option<String>) -> Option<&str> {
    s.as_deref().filter(|v| !v.trim().is_empty())
}

pub fn plan_libraries(mut libs: Vec<Library>, target_dir: &str) -> LibraryPlan {
    process_libraries(&mut libs);
    let mut items = Vec::new();

    for lib in &libs {
        if lib.name_str().starts_with("org.lwjgl") {
            continue;
        }
        let Some(artifact_path) = library_path(lib) else {
            continue;
        };
        // `downloads` presente sem `artifact`: só natives/classifiers -> ignora
        let artifact = match &lib.downloads {
            Some(d) => match &d.artifact {
                Some(a) => Some(a),
                None => continue,
            },
            None => None,
        };
        let sha1 = artifact
            .and_then(|a| a.sha1.clone())
            .or_else(|| lib.sha1.clone());
        let size = artifact
            .map(|a| a.size.unwrap_or(0))
            .unwrap_or_else(|| lib.size.unwrap_or(0));

        let mut downloadable = true;
        let url = if let Some(u) = artifact.and_then(|a| non_blank(&a.url)) {
            u.to_string()
        } else if let Some(base) = non_blank(&lib.url) {
            format!("{}{}", base.replace("http://", "https://"), artifact_path)
        } else {
            downloadable = false;
            format!("https://libraries.minecraft.net/{}", artifact_path)
        };

        items.push(DownloadItem {
            url,
            sha1,
            target: Path::new(target_dir)
                .join(&artifact_path)
                .to_string_lossy()
                .into_owned(),
            size,
            downloadable,
        });
    }
    LibraryPlan { libraries: libs, items }
}

#[derive(Deserialize)]
struct AssetObject {
    hash: String,
    #[serde(default)]
    size: i64,
}

#[derive(Deserialize)]
struct AssetIndex {
    #[serde(default)]
    objects: std::collections::BTreeMap<String, AssetObject>,
    #[serde(default, rename = "virtual")]
    is_virtual: bool,
    #[serde(default, rename = "map_to_resources")]
    map_to_resources: bool,
}

pub fn plan_assets(
    index_json: &str,
    resources_dir: &str,
    assets_dir: &str,
) -> Result<Vec<DownloadItem>, String> {
    let index: AssetIndex = serde_json::from_str(index_json).map_err(|e| e.to_string())?;
    let mut items = Vec::with_capacity(index.objects.len());
    for (path, obj) in &index.objects {
        if obj.hash.len() < 2 {
            continue;
        }
        let hashed = format!("{}/{}", &obj.hash[..2], obj.hash);
        let base = if index.map_to_resources { resources_dir } else { assets_dir };
        let target = if index.is_virtual || index.map_to_resources {
            Path::new(base).join(path)
        } else {
            Path::new(base).join("objects").join(&hashed)
        };
        items.push(DownloadItem {
            url: format!("{}{}", MINECRAFT_RES, hashed),
            sha1: Some(obj.hash.clone()),
            target: target.to_string_lossy().into_owned(),
            size: obj.size,
            downloadable: true,
        });
    }
    Ok(items)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plans_library_with_artifact() {
        let libs: Vec<Library> = serde_json::from_str(
            r#"[{"name":"a:b:1","downloads":{"artifact":{"path":"a/b/1/b-1.jar","sha1":"x","size":3,"url":"https://h/b.jar"}}},
                {"name":"org.lwjgl:lwjgl:3.3.1"},
                {"name":"n:m:1","downloads":{}}]"#,
        )
        .unwrap();
        let plan = plan_libraries(libs, "/L");
        assert_eq!(plan.items.len(), 1);
        assert_eq!(plan.items[0].target, "/L/a/b/1/b-1.jar");
        assert!(plan.items[0].downloadable);
    }

    #[test]
    fn plans_assets() {
        let items = plan_assets(
            r#"{"objects":{"icons/a.png":{"hash":"abcdef","size":5}}}"#,
            "/R",
            "/A",
        )
        .unwrap();
        assert_eq!(items[0].target, "/A/objects/ab/abcdef");
        assert_eq!(items[0].url, "https://resources.download.minecraft.net/ab/abcdef");
    }
}
