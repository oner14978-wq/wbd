//! Ponte JNI: `com.movtery.zalithlauncher.core.CatCoreNative`.
//!
//! Convenção: dados estruturados trafegam como JSON (String). Em caso de erro
//! (ou panic) a ponte lança `IllegalStateException` no lado Java/Kotlin.

#![allow(non_snake_case)]

use std::panic::{catch_unwind, AssertUnwindSafe};
use std::path::Path;
use std::ptr;

use jni::objects::{JClass, JObject, JString, JValue};
use jni::sys::{jboolean, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

use crate::{batch, hash, launch, manifest, plan, runtime, version, versions};

type Res<T> = Result<T, String>;

fn arg(env: &mut JNIEnv, s: &JString) -> Res<String> {
    env.get_string(s).map(String::from).map_err(|e| e.to_string())
}

fn opt_arg(env: &mut JNIEnv, s: &JString) -> Res<Option<String>> {
    if s.as_raw().is_null() {
        Ok(None)
    } else {
        arg(env, s).map(Some)
    }
}

fn throw(env: &mut JNIEnv, msg: &str) {
    let _ = env.throw_new("java/lang/IllegalStateException", msg);
}

fn json<T: serde::Serialize>(v: &T) -> Res<String> {
    serde_json::to_string(v).map_err(|e| e.to_string())
}

/// Executa `f` protegido contra panics e converte o resultado em `jstring`.
fn guard_str<F>(env: &mut JNIEnv, f: F) -> jstring
where
    F: FnOnce(&mut JNIEnv) -> Res<String>,
{
    match catch_unwind(AssertUnwindSafe(|| f(env))) {
        Ok(Ok(s)) => env.new_string(s).map(|j| j.into_raw()).unwrap_or(ptr::null_mut()),
        Ok(Err(e)) => {
            throw(env, &e);
            ptr::null_mut()
        }
        Err(_) => {
            throw(env, "CatCore: panic interno");
            ptr::null_mut()
        }
    }
}

fn guard_int<F>(env: &mut JNIEnv, default: jint, f: F) -> jint
where
    F: FnOnce(&mut JNIEnv) -> Res<jint>,
{
    match catch_unwind(AssertUnwindSafe(|| f(env))) {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => {
            throw(env, &e);
            default
        }
        Err(_) => {
            throw(env, "CatCore: panic interno");
            default
        }
    }
}

macro_rules! export_str {
    ($name:ident, |$env:ident $(, $a:ident)*| $body:block) => {
        #[no_mangle]
        pub extern "system" fn $name(
            mut env: JNIEnv,
            _class: JClass,
            $($a: JString,)*
        ) -> jstring {
            guard_str(&mut env, |$env| {
                $(let $a = arg($env, &$a)?;)*
                $body
            })
        }
    };
}

// ---------------------------------------------------------------- versões

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_parseVersionManifest, |_env, j| {
    json(&versions::parse(&j)?)
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_mergeUnlistedVersions, |_env, m, u| {
    json(&versions::merge_unlisted(&m, &u)?)
});

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_classifyVersion(
    mut env: JNIEnv,
    _class: JClass,
    kind: JString,
    april_fools: jboolean,
) -> jstring {
    guard_str(&mut env, |env| {
        let k = arg(env, &kind)?;
        Ok(versions::classify(&k, april_fools != JNI_FALSE).to_string())
    })
}

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_compareVersions(
    mut env: JNIEnv,
    _class: JClass,
    a: JString,
    b: JString,
) -> jint {
    guard_int(&mut env, 0, |env| {
        let (a, b) = (arg(env, &a)?, arg(env, &b)?);
        Ok(version::compare(&a, &b) as jint)
    })
}

// ------------------------------------------------------------- bibliotecas

fn libs(j: &str) -> Res<Vec<manifest::Library>> {
    serde_json::from_str(j).map_err(|e| format!("bibliotecas inválidas: {e}"))
}

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_processLibraries, |_env, j| {
    let mut l = libs(&j)?;
    manifest::process_libraries(&mut l);
    json(&l)
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_uniqueLibraries, |_env, j| {
    json(&manifest::unique_libraries(libs(&j)?))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_libraryPath, |_env, j| {
    let lib: manifest::Library = serde_json::from_str(&j).map_err(|e| e.to_string())?;
    Ok(manifest::library_path(&lib).unwrap_or_default())
});

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_detectLwjglVersion(
    mut env: JNIEnv,
    _class: JClass,
    j: JString,
) -> jint {
    guard_int(&mut env, 0, |env| {
        let s = arg(env, &j)?;
        Ok(manifest::detect_lwjgl_version(&libs(&s)?))
    })
}

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_planLibraries, |_env, j, dir| {
    json(&plan::plan_libraries(libs(&j)?, &dir))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_planAssets, |_env, idx, res, assets| {
    json(&plan::plan_assets(&idx, &res, &assets)?)
});

// --------------------------------------------------------------- lançamento

fn params(j: &str) -> Res<launch::LaunchParams> {
    serde_json::from_str(j).map_err(|e| format!("parâmetros de lançamento inválidos: {e}"))
}

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_launchClasspath, |_env, j| {
    Ok(launch::launch_classpath(&params(&j)?))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_jvmArgs, |_env, j| {
    json(&launch::jvm_args(&params(&j)?))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_clientArgs, |_env, j| {
    json(&launch::client_args(&params(&j)?))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_verifyFiles, |_env, j| {
    let req: verify::VerifyRequest = serde_json::from_str(&j)
        .map_err(|e| format!("pedido de verificação inválido: {e}"))?;
    json(&verify::verify_files(&req))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_perfJvmArgs, |_env, j| {
    let p: perf::PerfParams = serde_json::from_str(&j)
        .map_err(|e| format!("parâmetros de desempenho inválidos: {e}"))?;
    json(&perf::profile_args(&p))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_splitPreservingQuotes, |_env, s| {
    json(&launch::split_preserving_quotes(&s))
});

// ----------------------------------------------------------------- runtimes

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_loadRuntime, |_env, root, name| {
    json(&runtime::load_runtime(Path::new(&root), &name))
});

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_listRuntimes, |_env, root| {
    json(&runtime::list_runtimes(Path::new(&root))?)
});

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_pickRuntime(
    mut env: JNIEnv,
    _class: JClass,
    root: JString,
    major: jint,
    exact: jboolean,
) -> jstring {
    guard_str(&mut env, |env| {
        let root = arg(env, &root)?;
        let list = runtime::list_runtimes(Path::new(&root))?;
        let found = if exact != JNI_FALSE {
            runtime::exact_runtime(&list, major)
        } else {
            runtime::nearest_runtime(&list, major)
        };
        // string vazia = nenhum runtime compatível
        Ok(found.map(|r| r.name.clone()).unwrap_or_default())
    })
}

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_postPrepareRuntime, |_env, root, name, native_dir| {
    runtime::post_prepare(Path::new(&root), &name, Path::new(&native_dir))?;
    Ok(String::new())
});

/// Cria o callback de progresso: `Function1<String, Boolean>` (true = continuar).
fn progress<'a, 'l, 'o>(
    env: &'a mut JNIEnv<'l>,
    cb: &'a JObject<'o>,
) -> impl FnMut(&str) -> bool + 'a {
    move |name: &str| {
        if cb.as_raw().is_null() {
            return true;
        }
        let Ok(js) = env.new_string(name) else { return true };
        let ret = env.call_method(
            cb,
            "invoke",
            "(Ljava/lang/Object;)Ljava/lang/Object;",
            &[JValue::Object(&js)],
        );
        if env.exception_check().unwrap_or(false) {
            let _ = env.exception_clear();
            return false;
        }
        ret.ok()
            .and_then(|v| v.l().ok())
            .and_then(|o| env.call_method(&o, "booleanValue", "()Z", &[]).ok())
            .and_then(|v| v.z().ok())
            .unwrap_or(true)
    }
}

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_installRuntime(
    mut env: JNIEnv,
    _class: JClass,
    src: JString,
    root: JString,
    name: JString,
    native_dir: JString,
    cb: JObject,
) -> jstring {
    guard_str(&mut env, |env| {
        let (src, root, name, nat) = (
            arg(env, &src)?,
            arg(env, &root)?,
            arg(env, &name)?,
            arg(env, &native_dir)?,
        );
        let mut on_entry = progress(env, &cb);
        let info = runtime::install_runtime(
            Path::new(&src),
            Path::new(&root),
            &name,
            Path::new(&nat),
            &mut on_entry,
        )?;
        json(&info)
    })
}

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_installRuntimeBinPack(
    mut env: JNIEnv,
    _class: JClass,
    universal: JString,
    bins: JString,
    root: JString,
    name: JString,
    pack_version: JString,
    native_dir: JString,
    cb: JObject,
) -> jstring {
    guard_str(&mut env, |env| {
        let (u, b, root, name, ver, nat) = (
            arg(env, &universal)?,
            arg(env, &bins)?,
            arg(env, &root)?,
            arg(env, &name)?,
            arg(env, &pack_version)?,
            arg(env, &native_dir)?,
        );
        let mut on_entry = progress(env, &cb);
        let info = runtime::install_runtime_bin_pack(
            Path::new(&u),
            Path::new(&b),
            Path::new(&root),
            &name,
            &ver,
            Path::new(&nat),
            &mut on_entry,
        )?;
        json(&info)
    })
}

// -------------------------------------------------------------------- hash

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_compareSha1(
    mut env: JNIEnv,
    _class: JClass,
    path: JString,
    expected: JString,
    default: jboolean,
) -> jboolean {
    let r = catch_unwind(AssertUnwindSafe(|| -> Res<bool> {
        let p = arg(&mut env, &path)?;
        let e = opt_arg(&mut env, &expected)?;
        Ok(hash::compare_sha1(Path::new(&p), e.as_deref(), default != JNI_FALSE))
    }));
    match r {
        Ok(Ok(true)) => JNI_TRUE,
        Ok(Ok(false)) => JNI_FALSE,
        Ok(Err(e)) => {
            throw(&mut env, &e);
            JNI_FALSE
        }
        Err(_) => {
            throw(&mut env, "CatCore: panic interno");
            JNI_FALSE
        }
    }
}

export_str!(Java_com_movtery_zalithlauncher_core_CatCoreNative_sha1File, |_env, path| {
    hash::sha1_file(Path::new(&path)).map_err(|e| e.to_string())
});

// ---------------------------------------------------------------- downloads

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_newBatchHandle(
    _env: JNIEnv,
    _class: JClass,
) -> jlong {
    batch::new_handle().0 as jlong
}

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_cancelBatch(
    _env: JNIEnv,
    _class: JClass,
    handle: jlong,
) {
    batch::cancel_handle(handle as u64);
}

#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_releaseBatchHandle(
    _env: JNIEnv,
    _class: JClass,
    handle: jlong,
) {
    batch::release_handle(handle as u64);
}

/// Executa um lote (bloqueante). Callbacks, sempre na thread chamadora:
/// - `on_progress`: `Function1<long[], Boolean>` com
///   `[bytes, totalBytes, arquivos, totalArquivos, velocidade]`; `false` cancela;
/// - `on_file`: `Function1<Integer, Unit>` com o índice do arquivo concluído.
#[no_mangle]
pub extern "system" fn Java_com_movtery_zalithlauncher_core_CatCoreNative_downloadBatch(
    mut env: JNIEnv,
    _class: JClass,
    handle: jlong,
    requests_json: JString,
    options_json: JString,
    on_progress: JObject,
    on_file: JObject,
) -> jstring {
    guard_str(&mut env, |env| {
        let reqs: Vec<batch::Request> =
            serde_json::from_str(&arg(env, &requests_json)?).map_err(|e| format!("requisições inválidas: {e}"))?;
        let opts: batch::Options =
            serde_json::from_str(&arg(env, &options_json)?).map_err(|e| format!("opções inválidas: {e}"))?;
        let cancel = batch::handle_flag(handle as u64)
            .ok_or_else(|| "handle de lote inválido".to_string())?;

        // `Env` é compartilhado pelos dois callbacks, que nunca rodam ao mesmo tempo.
        let env_cell = std::cell::RefCell::new(&mut *env);

        let mut tick = |s: &batch::Snapshot| -> bool {
            let mut env = env_cell.borrow_mut();
            if on_progress.as_raw().is_null() {
                return true;
            }
            let Ok(arr) = env.new_long_array(5) else { return true };
            let vals = [s.downloaded_bytes, s.total_bytes, s.downloaded_files, s.total_files, s.speed];
            if env.set_long_array_region(&arr, 0, &vals).is_err() {
                return true;
            }
            let arr_obj = JObject::from(arr);
            let ret = env.call_method(
                &on_progress,
                "invoke",
                "(Ljava/lang/Object;)Ljava/lang/Object;",
                &[JValue::Object(&arr_obj)],
            );
            if env.exception_check().unwrap_or(false) {
                let _ = env.exception_clear();
                return false;
            }
            ret.ok()
                .and_then(|v| v.l().ok())
                .and_then(|o| env.call_method(&o, "booleanValue", "()Z", &[]).ok())
                .and_then(|v| v.z().ok())
                .unwrap_or(true)
        };

        let mut file_done = |i: usize| {
            let mut env = env_cell.borrow_mut();
            if on_file.as_raw().is_null() {
                return;
            }
            let Ok(boxed) = env.new_object("java/lang/Integer", "(I)V", &[JValue::Int(i as jint)]) else {
                return;
            };
            let _ = env.call_method(
                &on_file,
                "invoke",
                "(Ljava/lang/Object;)Ljava/lang/Object;",
                &[JValue::Object(&boxed)],
            );
            if env.exception_check().unwrap_or(false) {
                let _ = env.exception_clear();
                cancel_on_error(handle);
            }
        };

        let result = batch::run_batch(&reqs, &opts, cancel, &mut tick, &mut file_done);
        json(&result)
    })
}

fn cancel_on_error(handle: jlong) {
    batch::cancel_handle(handle as u64);
}
