//! Manifesto de versões do Minecraft.

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Latest {
    pub release: String,
    pub snapshot: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VersionEntry {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub url: String,
    #[serde(default)]
    pub time: String,
    #[serde(default, rename = "releaseTime")]
    pub release_time: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, rename = "complianceLevel", skip_serializing_if = "Option::is_none")]
    pub compliance_level: Option<i32>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VersionManifest {
    pub latest: Latest,
    pub versions: Vec<VersionEntry>,
}

/// Valida o manifesto e devolve-o normalizado (falha se o JSON for inválido).
pub fn parse(json: &str) -> Result<VersionManifest, String> {
    serde_json::from_str(json).map_err(|e| e.to_string())
}

/// Junta versões ocultas (unlisted) e ordena por `releaseTime` decrescente,
/// descartando ids duplicados (a versão oficial vence).
pub fn merge_unlisted(manifest_json: &str, unlisted_json: &str) -> Result<VersionManifest, String> {
    let mut manifest = parse(manifest_json)?;
    let extra: Vec<VersionEntry> = serde_json::from_str(unlisted_json).map_err(|e| e.to_string())?;
    for v in extra {
        if !manifest.versions.iter().any(|m| m.id == v.id) {
            manifest.versions.push(v);
        }
    }
    manifest
        .versions
        .sort_by(|a, b| b.release_time.cmp(&a.release_time));
    Ok(manifest)
}

/// Classifica o tipo de lançamento. `april_fools` = a versão é uma das
/// versões de 1º de abril conhecidas pelo app.
pub fn classify(kind: &str, april_fools: bool) -> &'static str {
    if april_fools {
        return "april_fools";
    }
    match kind {
        "release" => "release",
        "snapshot" | "pending" | "unobfuscated" => "snapshot",
        "old_beta" => "old_beta",
        "old_alpha" => "old_alpha",
        _ => "unknown",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const M: &str = r#"{"latest":{"release":"1.21","snapshot":"1.21"},"versions":[
        {"id":"1.21","type":"release","url":"u","time":"t","releaseTime":"2024-06-13T00:00:00+00:00","sha1":"s"}]}"#;

    #[test]
    fn merge_sorts_and_dedups() {
        let un = r#"[{"id":"old","type":"old_alpha","url":"u","time":"t","releaseTime":"2010-01-01T00:00:00+00:00"},
                     {"id":"1.21","type":"release","url":"u2","time":"t","releaseTime":"1999"}]"#;
        let m = merge_unlisted(M, un).unwrap();
        assert_eq!(m.versions.len(), 2);
        assert_eq!(m.versions[0].id, "1.21");
        assert_eq!(m.versions[0].url, "u");
    }

    #[test]
    fn classify_types() {
        assert_eq!(classify("pending", false), "snapshot");
        assert_eq!(classify("release", true), "april_fools");
        assert_eq!(classify("x", false), "unknown");
    }
}
