//! Comparação de versões no estilo Maven/HMCL (`VersionNumber`).

use std::cmp::Ordering;

#[derive(Debug, Clone, PartialEq, Eq)]
enum Tok {
    Num(u64),
    Str(String),
}

fn tokenize(s: &str) -> Vec<Tok> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut cur_is_digit = false;

    fn flush(out: &mut Vec<Tok>, cur: &mut String, is_digit: bool) {
        if cur.is_empty() {
            return;
        }
        if is_digit {
            out.push(Tok::Num(cur.parse::<u64>().unwrap_or(u64::MAX)));
        } else {
            out.push(Tok::Str(cur.to_lowercase()));
        }
        cur.clear();
    }

    for c in s.chars() {
        if c == '.' || c == '-' || c == '_' || c == '+' {
            flush(&mut out, &mut cur, cur_is_digit);
            continue;
        }
        let d = c.is_ascii_digit();
        if !cur.is_empty() && d != cur_is_digit {
            flush(&mut out, &mut cur, cur_is_digit);
        }
        cur_is_digit = d;
        cur.push(c);
    }
    flush(&mut out, &mut cur, cur_is_digit);
    out
}

fn qualifier_rank(q: &str) -> (i32, &str) {
    match q {
        "alpha" | "a" => (-6, ""),
        "beta" | "b" => (-5, ""),
        "milestone" | "m" => (-4, ""),
        "rc" | "cr" => (-3, ""),
        "snapshot" => (-2, ""),
        "" | "ga" | "final" | "release" => (0, ""),
        "sp" => (1, ""),
        other => (2, other),
    }
}

fn cmp_tok(a: Option<&Tok>, b: Option<&Tok>) -> Ordering {
    let zero = Tok::Num(0);
    let empty = Tok::Str(String::new());
    let (a, b) = match (a, b) {
        (Some(a), Some(b)) => (a, b),
        (Some(a), None) => (a, if matches!(a, Tok::Num(_)) { &zero } else { &empty }),
        (None, Some(b)) => (if matches!(b, Tok::Num(_)) { &zero } else { &empty }, b),
        (None, None) => return Ordering::Equal,
    };
    match (a, b) {
        (Tok::Num(x), Tok::Num(y)) => x.cmp(y),
        (Tok::Num(_), Tok::Str(_)) => Ordering::Greater, // 1.1 > 1-sp
        (Tok::Str(_), Tok::Num(_)) => Ordering::Less,
        (Tok::Str(x), Tok::Str(y)) => qualifier_rank(x).cmp(&qualifier_rank(y)),
    }
}

/// Compara duas versões; `1.0 == 1`, `1.0-rc1 < 1.0`, `1.1 > 1-sp`.
pub fn compare(a: &str, b: &str) -> Ordering {
    let (ta, tb) = (tokenize(a), tokenize(b));
    for i in 0..ta.len().max(tb.len()) {
        let o = cmp_tok(ta.get(i), tb.get(i));
        if o != Ordering::Equal {
            return o;
        }
    }
    Ordering::Equal
}

/// Versão major do Java a partir de `JAVA_VERSION` (`1.8.0_392` -> 8, `21.0.2` -> 21).
pub fn java_major(version: &str) -> i32 {
    let parts: Vec<&str> = version.split('.').collect();
    if parts.first() == Some(&"1") {
        parts.get(1).and_then(|p| p.parse().ok()).unwrap_or(0)
    } else {
        parts.first().and_then(|p| p.parse().ok()).unwrap_or(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ordering() {
        assert_eq!(compare("1.0", "1"), Ordering::Equal);
        assert_eq!(compare("5.13.0", "5.12.1"), Ordering::Greater);
        assert_eq!(compare("1.12", "1.9"), Ordering::Greater);
        assert_eq!(compare("1.0-rc1", "1.0"), Ordering::Less);
        assert_eq!(compare("1.0-snapshot", "1.0-beta"), Ordering::Greater);
    }

    #[test]
    fn java() {
        assert_eq!(java_major("1.8.0_392"), 8);
        assert_eq!(java_major("21.0.2"), 21);
        assert_eq!(java_major("x"), 0);
    }
}
