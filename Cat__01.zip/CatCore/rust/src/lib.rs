//! CatCore: núcleo do Cat Launcher em Rust.
//!
//! Substitui a lógica interna antes escrita em Kotlin/Java:
//! - `version`   : comparação de versões
//! - `manifest`  : modelo do JSON de versão, regras, bibliotecas, classpath
//! - `plan`      : planejamento de downloads (bibliotecas, assets)
//! - `launch`    : montagem de argumentos JVM/jogo e classpath
//! - `runtime`   : gerenciamento de runtimes Java (JRE)
//! - `versions`  : manifesto de versões do Minecraft
//! - `hash`      : verificação SHA-1 de arquivos
//! - `net`       : download HTTP de um arquivo (retry, mirrors, resume, SHA-1)
//! - `batch`     : downloads paralelos, progresso e cancelamento
//! - `verify`    : verificação SHA-1 em lote (threads + cache persistente)
//! - `perf`      : perfil de desempenho (flags de JVM/GC aplicadas na entrada do jogo)

pub mod batch;
pub mod hash;
pub mod launch;
pub mod manifest;
pub mod net;
pub mod perf;
pub mod plan;
pub mod runtime;
pub mod version;
pub mod verify;
pub mod versions;

#[cfg(target_os = "android")]
mod jni_bridge;
