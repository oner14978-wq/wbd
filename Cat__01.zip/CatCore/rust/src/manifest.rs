//! Modelo do JSON de versão do Minecraft e lógica de bibliotecas.
//!
//! Todos os structs preservam campos desconhecidos (`extra`) para que o
//! ciclo Kotlin(Gson) -> Rust -> Kotlin(Gson) não perca informação.

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::collections::{BTreeMap, HashMap};

use crate::version;

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Os {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub arch: Option<String>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Rule {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub action: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub os: Option<Os>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub features: Option<Map<String, Value>>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Artifact {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub size: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct LibDownloads {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub artifact: Option<Artifact>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Library {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub downloads: Option<LibDownloads>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub natives: Option<BTreeMap<String, String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub rules: Option<Vec<Rule>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub sha1: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub size: Option<i64>,
    #[serde(flatten)]
    pub extra: Map<String, Value>,
}

impl Library {
    pub fn name_str(&self) -> &str {
        self.name.as_deref().unwrap_or("")
    }

    /// Equivalente a `GameManifest.Library.isNative`.
    pub fn is_native(&self) -> bool {
        self.natives.is_some() && check_rules(&self.rules)
    }
}

/// Regras de biblioteca. Comportamento herdado do PojavLauncher:
/// somente regras `allow` restritas a `osx` bloqueiam a biblioteca.
pub fn check_rules(rules: &Option<Vec<Rule>>) -> bool {
    match rules {
        None => true,
        Some(r) if r.is_empty() => true,
        Some(r) => !r.iter().any(|rule| {
            rule.action.as_deref() == Some("allow")
                && rule.os.as_ref().and_then(|o| o.name.as_deref()) == Some("osx")
        }),
    }
}

/// Caminho relativo do artefato da biblioteca (`artifactToPath`).
pub fn library_path(lib: &Library) -> Option<String> {
    if let Some(p) = lib
        .downloads
        .as_ref()
        .and_then(|d| d.artifact.as_ref())
        .and_then(|a| a.path.clone())
    {
        return Some(p);
    }
    let name = lib.name.as_deref()?;
    let parts: Vec<&str> = name.split(':').collect();
    if parts.len() < 3 {
        return None;
    }
    let group = parts[0].replace('.', "/");
    let artifact = parts[1];
    let ver = parts[2];
    let mut classifier = if parts.len() > 3 {
        format!("-{}", parts[3])
    } else {
        String::new()
    };
    if lib.is_native() {
        // Android: usa a variante Linux
        // a chave pode chegar como "linux" ou "Linux" conforme o serializador
        let native = lib.natives.as_ref().and_then(|m| {
            m.iter()
                .find(|(k, _)| k.eq_ignore_ascii_case("linux"))
                .map(|(_, v)| v)
        });
        if let Some(n) = native {
            classifier = format!("-{}", n);
        }
    }
    Some(format!("{group}/{artifact}/{ver}/{artifact}-{ver}{classifier}.jar"))
}

/// Bibliotecas que o launcher fornece por conta própria.
pub fn filter_library(lib: &Library) -> bool {
    let n = lib.name_str();
    n.contains("org.lwjgl") || n.contains("jinput-platform") || n.contains("twitch-platform")
}

#[derive(Debug, Clone)]
pub struct Replacement {
    pub name: &'static str,
    pub path: &'static str,
    pub sha1: &'static str,
    pub url: &'static str,
    pub size: i64,
}

/// Substituições de bibliotecas incompatíveis (jna, oshi, asm-all).
pub fn library_replacement(name: &str) -> Option<Replacement> {
    let ver = name.split(':').nth(2)?;
    let parts: Vec<&str> = ver.split('.').collect();
    let major: i64 = parts.first().and_then(|p| p.parse().ok()).unwrap_or(0);
    let minor: i64 = parts.get(1).and_then(|p| p.parse().ok()).unwrap_or(0);

    if name.starts_with("net.java.dev.jna:jna:") {
        if major >= 5 && minor >= 13 {
            return None;
        }
        return Some(Replacement {
            name: "net.java.dev.jna:jna:5.13.0",
            path: "net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar",
            sha1: "1200e7ebeedbe0d10062093f32925a912020e747",
            url: "https://repo1.maven.org/maven2/net/java/dev/jna/jna/5.13.0/jna-5.13.0.jar",
            size: 1879325,
        });
    }
    if name.starts_with("com.github.oshi:oshi-core:") {
        if major != 6 || minor != 2 {
            return None;
        }
        return Some(Replacement {
            name: "com.github.oshi:oshi-core:6.3.0",
            path: "com/github/oshi/oshi-core/6.3.0/oshi-core-6.3.0.jar",
            sha1: "9e98cf55be371cafdb9c70c35d04ec2a8c2b42ac",
            url: "https://repo1.maven.org/maven2/com/github/oshi/oshi-core/6.3.0/oshi-core-6.3.0.jar",
            size: 957945,
        });
    }
    if name.starts_with("org.ow2.asm:asm-all:") {
        if major >= 5 {
            return None;
        }
        return Some(Replacement {
            name: "org.ow2.asm:asm-all:5.0.4",
            path: "org/ow2/asm/asm-all/5.0.4/asm-all-5.0.4.jar",
            sha1: "e6244859997b3d4237a552669279780876228909",
            url: "https://repo1.maven.org/maven2/org/ow2/asm/asm-all/5.0.4/asm-all-5.0.4.jar",
            size: 241810,
        });
    }
    None
}

/// Aplica as substituições in-place (`processLibraries`).
pub fn process_libraries(libs: &mut [Library]) {
    for lib in libs.iter_mut() {
        if filter_library(lib) {
            continue;
        }
        let Some(rep) = library_replacement(lib.name_str()) else {
            continue;
        };
        lib.name = Some(rep.name.to_string());
        let dl = lib.downloads.get_or_insert_with(Default::default);
        let art = dl.artifact.get_or_insert_with(Default::default);
        art.path = Some(rep.path.to_string());
        art.sha1 = Some(rep.sha1.to_string());
        art.url = Some(rep.url.to_string());
        // o tamanho antigo truncaria o download do novo artefato
        if rep.size > 0 {
            art.size = Some(rep.size);
        }
    }
}

struct Components {
    group: String,
    artifact: String,
    version: String,
}

fn parse_components(name: &str) -> Option<Components> {
    let p: Vec<&str> = name.split(':').collect();
    if p.len() < 3 {
        return None;
    }
    Some(Components {
        group: p[0].to_string(),
        artifact: p[1].to_string(),
        version: p[2].to_string(),
    })
}

fn rules_key(lib: &Library) -> String {
    match &lib.rules {
        None => String::new(),
        Some(rules) => {
            let v: Vec<Value> = rules
                .iter()
                .map(|r| {
                    serde_json::json!({
                        "a": r.action,
                        "n": r.os.as_ref().and_then(|o| o.name.clone()),
                        "r": r.os.as_ref().and_then(|o| o.arch.clone()),
                        "f": r.features,
                    })
                })
                .collect();
            Value::Array(v).to_string()
        }
    }
}

fn json_len(lib: &Library) -> usize {
    serde_json::to_string(lib).map(|s| s.len()).unwrap_or(0)
}

/// Deduplica por coordenada (`group:artifact`) mantendo a versão mais nova
/// quando as regras são idênticas (`uniqueLibraries`).
pub fn unique_libraries(libs: Vec<Library>) -> Vec<Library> {
    let mut unique: Vec<Library> = Vec::with_capacity(libs.len());
    let mut indexes: HashMap<String, Vec<usize>> = HashMap::new();

    for lib in libs {
        let Some(comp) = parse_components(lib.name_str()) else {
            unique.push(lib);
            continue;
        };
        let id = format!("{}:{}", comp.group, comp.artifact);

        let Some(existing) = indexes.get(&id).cloned() else {
            indexes.insert(id, vec![unique.len()]);
            unique.push(lib);
            continue;
        };

        let mut duplicate = false;
        for idx in existing {
            if rules_key(&lib) != rules_key(&unique[idx]) {
                continue;
            }
            let other_ver = parse_components(unique[idx].name_str())
                .map(|c| c.version)
                .unwrap_or_default();
            match version::compare(&comp.version, &other_ver) {
                std::cmp::Ordering::Greater => {
                    unique[idx] = lib.clone();
                }
                std::cmp::Ordering::Equal => {
                    if lib.name == unique[idx].name && lib.is_native() == unique[idx].is_native() {
                        if json_len(&lib) > json_len(&unique[idx]) {
                            unique[idx] = lib.clone();
                        }
                    } else {
                        // mesma versão, coordenadas diferentes (jar vs natives)
                        continue;
                    }
                }
                std::cmp::Ordering::Less => {}
            }
            duplicate = true;
            break;
        }

        if !duplicate {
            indexes.entry(id).or_default().push(unique.len());
            unique.push(lib);
        }
    }
    unique
}

/// Versão do LWJGL exigida (`3.3.3` -> 333); 0 se indeterminada.
pub fn detect_lwjgl_version(libs: &[Library]) -> i32 {
    for lib in libs {
        let name = lib.name_str();
        let prefix = if name.starts_with("org.lwjgl.lwjgl:lwjgl:") {
            "org.lwjgl.lwjgl:lwjgl:"
        } else if name.starts_with("org.lwjgl:lwjgl:") {
            "org.lwjgl:lwjgl:"
        } else {
            continue;
        };
        let digits: String = name[prefix.len()..]
            .chars()
            .take_while(|c| c.is_ascii_digit() || *c == '.')
            .filter(|c| *c != '.')
            .collect();
        if let Ok(v) = digits.parse::<i32>() {
            if (200..=999).contains(&v) {
                return v;
            }
        }
    }
    0
}

/// Diretório do componente LWJGL: >= 3.4.1 usa 3.4.1, senão 3.3.3.
pub fn lwjgl_version_dir(v: i32) -> &'static str {
    if v >= 341 {
        "3.4.1"
    } else {
        "3.3.3"
    }
}

/// Classpath de bibliotecas (`generateLibClasspath` + `LibSortFix`).
/// Retorna caminhos absolutos na ordem do manifesto.
pub fn library_classpath(libs: &[Library], libraries_home: &str) -> Vec<String> {
    let mut entries: Vec<(String, String)> = Vec::new();
    for lib in libs {
        if !(check_rules(&lib.rules) && !lib.is_native()) {
            continue;
        }
        let Some(path) = resolved_path(lib) else {
            continue;
        };
        // LibSortFix: asm moderno substitui asm-all
        if lib.name_str().starts_with("org.ow2.asm:asm:") {
            entries.retain(|(n, _)| !n.starts_with("org.ow2.asm:asm-all:"));
        }
        entries.push((lib.name_str().to_string(), format!("{}/{}", libraries_home, path)));
    }
    entries.into_iter().map(|(_, p)| p).collect()
}

fn resolved_path(lib: &Library) -> Option<String> {
    if filter_library(lib) {
        return None;
    }
    let mut path = library_path(lib)?;
    if let Some(rep) = library_replacement(lib.name_str()) {
        path = rep.path.to_string();
    }
    Some(path)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lib(json: &str) -> Library {
        serde_json::from_str(json).unwrap()
    }

    #[test]
    fn osx_rule_blocks() {
        let l = lib(r#"{"name":"a:b:1","rules":[{"action":"allow","os":{"name":"osx"}}]}"#);
        assert!(!check_rules(&l.rules));
        let l = lib(r#"{"name":"a:b:1","rules":[{"action":"allow","os":{"name":"linux"}}]}"#);
        assert!(check_rules(&l.rules));
    }

    #[test]
    fn path_from_name() {
        let l = lib(r#"{"name":"com.google.guava:guava:31.1-jre"}"#);
        assert_eq!(
            library_path(&l).unwrap(),
            "com/google/guava/guava/31.1-jre/guava-31.1-jre.jar"
        );
        let n = lib(r#"{"name":"x.y:z:1.0","natives":{"linux":"natives-linux"}}"#);
        assert!(library_path(&n).unwrap().ends_with("z-1.0-natives-linux.jar"));
    }

    #[test]
    fn replacement_and_filter() {
        assert!(library_replacement("net.java.dev.jna:jna:5.12.1").is_some());
        assert!(library_replacement("net.java.dev.jna:jna:5.13.0").is_none());
        assert!(library_replacement("com.github.oshi:oshi-core:6.2.0").is_some());
        assert!(library_replacement("org.ow2.asm:asm-all:4.1").is_some());
        assert!(filter_library(&lib(r#"{"name":"org.lwjgl:lwjgl:3.3.3"}"#)));
    }

    #[test]
    fn unique_keeps_newest() {
        let libs = vec![
            lib(r#"{"name":"a:b:1.0"}"#),
            lib(r#"{"name":"a:b:2.0"}"#),
            lib(r#"{"name":"c:d:1.0"}"#),
        ];
        let u = unique_libraries(libs);
        assert_eq!(u.len(), 2);
        assert_eq!(u[0].name_str(), "a:b:2.0");
    }

    #[test]
    fn lwjgl_detect() {
        let libs = vec![lib(r#"{"name":"org.lwjgl:lwjgl:3.3.1"}"#)];
        assert_eq!(detect_lwjgl_version(&libs), 331);
        assert_eq!(lwjgl_version_dir(341), "3.4.1");
        assert_eq!(lwjgl_version_dir(299), "3.3.3");
    }

    #[test]
    fn asm_all_removed() {
        let libs = vec![
            lib(r#"{"name":"org.ow2.asm:asm-all:5.0.4"}"#),
            lib(r#"{"name":"org.ow2.asm:asm:9.0"}"#),
        ];
        let cp = library_classpath(&libs, "/L");
        assert_eq!(cp.len(), 1);
        assert!(cp[0].contains("asm-9.0"));
    }
}
