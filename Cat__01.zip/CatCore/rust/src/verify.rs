//! Verificação em lote de arquivos do jogo (SHA-1), em paralelo e com cache persistente.
//!
//! Uma única chamada JNI verifica milhares de arquivos (jar, bibliotecas, assets) com um
//! pool de threads. Um arquivo só é lido e hasheado se mudou desde a última verificação
//! bem-sucedida: a entrada do cache vale enquanto tamanho, data de modificação e SHA-1
//! esperado forem os mesmos. Todas as threads só LEEM arquivos, então não há risco de
//! corrupção; apagar ou baixar de novo o que falhou continua com o chamador.

use serde::Deserialize;
use std::collections::HashMap;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::UNIX_EPOCH;

use crate::hash::sha1_file;

/// Acima disso, entradas de arquivos que não existem mais são removidas ao salvar.
const MAX_ENTRIES: usize = 60_000;
const MAX_THREADS: usize = 8;

#[derive(Debug, Deserialize)]
pub struct VerifyItem {
    pub path: String,
    pub sha1: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct VerifyRequest {
    #[serde(default)]
    pub items: Vec<VerifyItem>,
    /// Arquivo do cache; vazio = sem cache (verifica tudo, não grava nada).
    #[serde(default)]
    pub cache_path: String,
    #[serde(default)]
    pub threads: usize,
}

#[derive(Clone, Debug)]
struct Entry {
    sha1: String,
    size: u64,
    mtime_ms: u64,
}

/// (tamanho, data de modificação em ms) de um arquivo comum; `None` se não existe/não é arquivo.
fn stamp(path: &Path) -> Option<(u64, u64)> {
    let meta = fs::metadata(path).ok()?;
    if !meta.is_file() {
        return None;
    }
    let mtime = meta.modified().ok()?.duration_since(UNIX_EPOCH).ok()?.as_millis() as u64;
    Some((meta.len(), mtime))
}

fn load_cache(path: &Path) -> HashMap<String, Entry> {
    let mut map = HashMap::new();
    let Ok(text) = fs::read_to_string(path) else {
        return map;
    };
    for line in text.lines() {
        let mut parts = line.splitn(4, '\t');
        let (Some(sha1), Some(size), Some(mtime), Some(p)) =
            (parts.next(), parts.next(), parts.next(), parts.next())
        else {
            continue;
        };
        let (Ok(size), Ok(mtime_ms)) = (size.parse::<u64>(), mtime.parse::<u64>()) else {
            continue;
        };
        map.insert(p.to_string(), Entry { sha1: sha1.to_string(), size, mtime_ms });
    }
    map
}

/// Escrita atômica: arquivo temporário + rename.
fn save_cache(path: &Path, map: &mut HashMap<String, Entry>) -> std::io::Result<()> {
    if map.len() > MAX_ENTRIES {
        map.retain(|p, _| Path::new(p).exists());
    }
    let mut tmp: PathBuf = path.to_path_buf();
    let mut name = tmp.file_name().map(|n| n.to_os_string()).unwrap_or_default();
    name.push(".tmp");
    tmp.set_file_name(name);

    let mut out = std::io::BufWriter::new(fs::File::create(&tmp)?);
    for (p, e) in map.iter() {
        writeln!(out, "{}\t{}\t{}\t{}", e.sha1, e.size, e.mtime_ms, p)?;
    }
    out.flush()?;
    drop(out);
    if fs::rename(&tmp, path).is_err() {
        let _ = fs::remove_file(path);
        fs::rename(&tmp, path)?;
    }
    Ok(())
}

/// Verifica todos os itens; `resultado[i]` corresponde a `items[i]`.
pub fn verify_files(req: &VerifyRequest) -> Vec<bool> {
    let n = req.items.len();
    if n == 0 {
        return Vec::new();
    }
    let cache_path: Option<PathBuf> = (!req.cache_path.is_empty()).then(|| PathBuf::from(&req.cache_path));
    let mut cache: HashMap<String, Entry> = cache_path.as_deref().map(load_cache).unwrap_or_default();

    let results: Vec<AtomicBool> = (0..n).map(|_| AtomicBool::new(false)).collect();
    let fresh: Mutex<Vec<(String, Entry)>> = Mutex::new(Vec::new());
    let next = AtomicUsize::new(0);
    let threads = req.threads.clamp(1, MAX_THREADS).min(n);

    {
        let cache_ref = &cache;
        let results = &results;
        let fresh = &fresh;
        let next = &next;
        std::thread::scope(|scope| {
            for _ in 0..threads {
                scope.spawn(move || loop {
                    let i = next.fetch_add(1, Ordering::Relaxed);
                    if i >= n {
                        break;
                    }
                    let item = &req.items[i];
                    let path = Path::new(&item.path);
                    // O carimbo é lido ANTES do hash: se o arquivo mudar no meio, o carimbo
                    // gravado fica velho e a próxima verificação refaz o hash.
                    let Some((size, mtime_ms)) = stamp(path) else {
                        continue;
                    };
                    if let Some(e) = cache_ref.get(&item.path) {
                        if e.size == size && e.mtime_ms == mtime_ms && e.sha1.eq_ignore_ascii_case(&item.sha1) {
                            results[i].store(true, Ordering::Relaxed);
                            continue;
                        }
                    }
                    if let Ok(actual) = sha1_file(path) {
                        if actual.eq_ignore_ascii_case(&item.sha1) {
                            results[i].store(true, Ordering::Relaxed);
                            if size > 0 {
                                let entry = Entry { sha1: actual, size, mtime_ms };
                                if let Ok(mut f) = fresh.lock() {
                                    f.push((item.path.clone(), entry));
                                }
                            }
                        }
                    }
                });
            }
        });
    }

    let out: Vec<bool> = results.iter().map(|r| r.load(Ordering::Relaxed)).collect();

    if let Some(cp) = cache_path {
        let mut changed = false;
        for (p, e) in fresh.into_inner().unwrap_or_default() {
            cache.insert(p, e);
            changed = true;
        }
        for (item, ok) in req.items.iter().zip(out.iter()) {
            if !ok && cache.remove(&item.path).is_some() {
                changed = true;
            }
        }
        if changed {
            let _ = save_cache(&cp, &mut cache);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;
    use std::io::Write as _;

    fn write(dir: &Path, name: &str, content: &[u8]) -> PathBuf {
        let p = dir.join(name);
        File::create(&p).unwrap().write_all(content).unwrap();
        p
    }

    fn item(p: &Path) -> VerifyItem {
        VerifyItem { path: p.to_string_lossy().into_owned(), sha1: sha1_file(p).unwrap() }
    }

    fn req(items: Vec<VerifyItem>, cache: &Path, threads: usize) -> VerifyRequest {
        VerifyRequest { items, cache_path: cache.to_string_lossy().into_owned(), threads }
    }

    #[test]
    fn valid_wrong_and_missing_keep_input_order() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let b = write(d.path(), "b.bin", b"world");
        let missing = d.path().join("nao-existe.bin");
        let items = vec![
            item(&a),
            VerifyItem { path: b.to_string_lossy().into_owned(), sha1: "0".repeat(40) },
            VerifyItem { path: missing.to_string_lossy().into_owned(), sha1: "0".repeat(40) },
        ];
        let r = verify_files(&req(items, &d.path().join("c.tsv"), 3));
        assert_eq!(r, vec![true, false, false]);
    }

    #[test]
    fn many_files_in_parallel() {
        let d = tempfile::tempdir().unwrap();
        let items: Vec<VerifyItem> = (0..200)
            .map(|i| item(&write(d.path(), &format!("f{i}.bin"), format!("conteudo {i}").as_bytes())))
            .collect();
        let r = verify_files(&req(items, &d.path().join("c.tsv"), 8));
        assert_eq!(r.len(), 200);
        assert!(r.iter().all(|x| *x));
    }

    #[test]
    fn cache_is_written_and_reused() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let cache = d.path().join("c.tsv");
        assert_eq!(verify_files(&req(vec![item(&a)], &cache, 2)), vec![true]);
        let saved = fs::read_to_string(&cache).unwrap();
        assert!(saved.contains("a.bin"));
        // Segunda vez: o resultado vem do cache e continua verdadeiro.
        assert_eq!(verify_files(&req(vec![item(&a)], &cache, 2)), vec![true]);
    }

    #[test]
    fn cache_hit_skips_hashing_but_changed_size_forces_it() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let cache = d.path().join("c.tsv");
        let it = item(&a);
        let sha = it.sha1.clone();
        assert_eq!(verify_files(&req(vec![it], &cache, 1)), vec![true]);

        // Conteúdo diferente com o MESMO SHA-1 esperado: o tamanho mudou, então o cache é
        // ignorado e o arquivo é hasheado de novo -> falha.
        write(d.path(), "a.bin", b"hello world, bem maior");
        let again = VerifyItem { path: a.to_string_lossy().into_owned(), sha1: sha };
        assert_eq!(verify_files(&req(vec![again], &cache, 1)), vec![false]);
    }

    #[test]
    fn failed_file_is_dropped_from_cache() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let cache = d.path().join("c.tsv");
        let good = item(&a);
        assert_eq!(verify_files(&req(vec![item(&a)], &cache, 1)), vec![true]);
        write(d.path(), "a.bin", b"alterado!!");
        assert_eq!(verify_files(&req(vec![good], &cache, 1)), vec![false]);
        assert!(!fs::read_to_string(&cache).unwrap().contains("a.bin"));
    }

    #[test]
    fn works_without_cache_and_with_empty_input() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let r = VerifyRequest { items: vec![item(&a)], cache_path: String::new(), threads: 0 };
        assert_eq!(verify_files(&r), vec![true]);
        assert!(verify_files(&VerifyRequest::default()).is_empty());
    }

    #[test]
    fn corrupted_cache_file_is_ignored() {
        let d = tempfile::tempdir().unwrap();
        let a = write(d.path(), "a.bin", b"hello");
        let cache = write(d.path(), "c.tsv", b"lixo sem tabs\n\x00\x01\n");
        assert_eq!(verify_files(&req(vec![item(&a)], &cache, 2)), vec![true]);
    }
}
