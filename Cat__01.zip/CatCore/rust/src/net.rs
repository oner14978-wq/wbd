//! Download HTTP de um único arquivo.
//!
//! Porta do `Fetcher.kt` (derivado do FetchTask do HMCL):
//! - candidatos (mirrors) tentados em ordem; 4xx = "sem o arquivo" (não repete,
//!   passa ao próximo candidato);
//! - até `retry` tentativas por candidato, 200 ms de intervalo;
//! - redirecionamentos manuais (máx. 20);
//! - escrita em arquivo temporário ao lado do alvo, SHA-1 calculado durante o
//!   download e `rename` atômico só após a verificação;
//! - retomada por `Range` + `If-Range` com validação estrita do 206;
//! - bytes descartados em retentativas são devolvidos (delta negativo).

use sha1::{Digest, Sha1};
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

pub const DEFAULT_RETRY: usize = 5;
const MAX_REDIRECTS: usize = 20;
const BACKOFF: Duration = Duration::from_millis(200);
const BUFFER_SIZE: usize = 32 * 1024;

#[derive(Debug, Clone)]
pub struct FetchError {
    pub message: String,
    pub http_code: Option<u16>,
    pub cancelled: bool,
}

impl FetchError {
    fn msg(m: impl Into<String>) -> Self {
        Self { message: m.into(), http_code: None, cancelled: false }
    }
    fn http(code: u16, url: &str) -> Self {
        Self { message: format!("HTTP {code}: {url}"), http_code: Some(code), cancelled: false }
    }
    fn cancelled() -> Self {
        Self { message: "cancelled".into(), http_code: None, cancelled: true }
    }
}

impl From<std::io::Error> for FetchError {
    fn from(e: std::io::Error) -> Self {
        Self::msg(e.to_string())
    }
}

pub struct HttpConfig {
    pub user_agent: String,
    pub connect_timeout: Duration,
    pub read_timeout: Duration,
}

impl Default for HttpConfig {
    fn default() -> Self {
        Self {
            user_agent: "CatLauncher".into(),
            connect_timeout: Duration::from_secs(10),
            read_timeout: Duration::from_secs(10),
        }
    }
}

pub fn build_agent(cfg: &HttpConfig) -> ureq::Agent {
    ureq::AgentBuilder::new()
        .redirects(0)
        .timeout_connect(cfg.connect_timeout)
        .timeout_read(cfg.read_timeout)
        .user_agent(&cfg.user_agent)
        .build()
}

// ------------------------------------------------------------------ sink

static TEMP_COUNTER: AtomicU64 = AtomicU64::new(0);

/// Arquivo temporário + SHA-1 incremental.
struct Sink {
    target: PathBuf,
    temp: PathBuf,
    file: Option<File>,
    hasher: Option<Sha1>,
    expected: Option<String>,
    broken: bool,
}

impl Sink {
    fn new(target: &Path, expected: Option<&str>) -> std::io::Result<Self> {
        let parent = target.parent().map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("."));
        fs::create_dir_all(&parent)?;
        let n = TEMP_COUNTER.fetch_add(1, Ordering::Relaxed);
        let name = target.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
        let temp = parent.join(format!(".{name}.{}.{n}.part", std::process::id()));
        let file = File::create(&temp)?;
        Ok(Self {
            target: target.to_path_buf(),
            temp,
            file: Some(file),
            hasher: expected.filter(|e| !e.trim().is_empty()).map(|_| Sha1::new()),
            expected: expected.filter(|e| !e.trim().is_empty()).map(str::to_string),
            broken: false,
        })
    }

    fn write(&mut self, buf: &[u8]) -> std::io::Result<()> {
        if let Some(h) = self.hasher.as_mut() {
            h.update(buf);
        }
        let res = match self.file.as_mut() {
            Some(f) => f.write_all(buf),
            None => Err(std::io::Error::new(std::io::ErrorKind::Other, "sink fechado")),
        };
        if res.is_err() {
            self.broken = true;
        }
        res
    }

    /// Verifica SHA-1 e substitui o alvo de forma atômica.
    fn finish(&mut self) -> Result<(), FetchError> {
        let result = (|| -> Result<(), FetchError> {
            if let Some(mut f) = self.file.take() {
                f.flush()?;
            }
            if let (Some(h), Some(exp)) = (self.hasher.take(), self.expected.as_ref()) {
                let actual: String = h.finalize().iter().map(|b| format!("{:02x}", b)).collect();
                if !exp.eq_ignore_ascii_case(&actual) {
                    return Err(FetchError::msg(format!(
                        "Checksum mismatch (SHA-1): expected={exp}, actual={actual}"
                    )));
                }
            }
            fs::rename(&self.temp, &self.target)?;
            Ok(())
        })();
        if result.is_err() {
            let _ = fs::remove_file(&self.temp);
        }
        result
    }

    fn discard(&mut self) {
        self.file = None;
        let _ = fs::remove_file(&self.temp);
    }
}

// ---------------------------------------------------------------- resume

struct Resume {
    url: String,
    content_length: i64,
    strong_etag: Option<String>,
    last_modified: String,
    received: i64,
}

impl Resume {
    fn of(r: &Response) -> Option<Self> {
        if r.code != 200 {
            return None;
        }
        if !r.header("accept-ranges").unwrap_or("").eq_ignore_ascii_case("bytes") {
            return None;
        }
        let len = r.header_i64("content-length");
        if len < 0 {
            return None;
        }
        let strong = r
            .header("etag")
            .filter(|e| !e.trim().is_empty() && !e.to_ascii_lowercase().starts_with("w/"))
            .map(str::to_string);
        let lm = r.header("last-modified").unwrap_or("").to_string();
        if strong.is_none() && lm.trim().is_empty() {
            return None;
        }
        Some(Self { url: r.url.clone(), content_length: len, strong_etag: strong, last_modified: lm, received: 0 })
    }

    fn if_range(&self) -> String {
        self.strong_etag.clone().unwrap_or_else(|| self.last_modified.clone())
    }

    fn has_partial(&self) -> bool {
        self.received > 0 && self.received < self.content_length
    }

    fn can_resume(&self, r: &Response) -> bool {
        if r.code != 206 {
            return false;
        }
        let body_len = r.header_i64("content-length");
        if self.content_length != body_len + self.received {
            return false;
        }
        match &self.strong_etag {
            Some(e) => {
                if Some(e.as_str()) != r.header("etag") {
                    return false;
                }
            }
            None => {
                if self.url != r.url || self.last_modified != r.header("last-modified").unwrap_or("") {
                    return false;
                }
            }
        }
        let Some((start, end, total)) = parse_content_range(r.header("content-range").unwrap_or("")) else {
            return false;
        };
        start == self.received && end >= start && total == self.content_length && end - start + 1 == body_len
    }
}

/// `bytes 10-99/100` -> (10, 99, 100)
fn parse_content_range(v: &str) -> Option<(i64, i64, i64)> {
    let rest = v.trim().strip_prefix("bytes ")?;
    let (range, total) = rest.split_once('/')?;
    let (start, end) = range.split_once('-')?;
    Some((start.parse().ok()?, end.parse().ok()?, total.parse().ok()?))
}

// -------------------------------------------------------------- response

struct Response {
    code: u16,
    url: String,
    inner: ureq::Response,
}

impl Response {
    fn header(&self, name: &str) -> Option<&str> {
        self.inner.header(name)
    }
    fn header_i64(&self, name: &str) -> i64 {
        self.header(name).and_then(|v| v.trim().parse().ok()).unwrap_or(-1)
    }
}

// ------------------------------------------------------- estado por fonte

struct State<'a> {
    sink: Option<Sink>,
    resume: Option<Resume>,
    counted: i64,
    on_bytes: &'a (dyn Fn(i64) + Sync),
}

impl<'a> State<'a> {
    fn report(&mut self, delta: i64) {
        self.counted += delta;
        (self.on_bytes)(delta);
    }

    /// Fecha e apaga o temporário e devolve ao contador os bytes já somados.
    fn discard(&mut self) {
        if let Some(mut s) = self.sink.take() {
            s.discard();
        }
        if self.counted != 0 {
            (self.on_bytes)(-self.counted);
            self.counted = 0;
        }
    }

    fn commit(&mut self) {
        self.sink = None;
        self.resume = None;
        self.counted = 0;
    }
}

enum Attempt {
    Done,
    RestartFree,
}

/// Baixa `target` tentando cada URL candidata em ordem.
/// `is_cancelled` é consultado a cada bloco lido.
pub fn fetch_file(
    agent: &ureq::Agent,
    urls: &[String],
    target: &Path,
    sha1: Option<&str>,
    retry: usize,
    is_cancelled: &(dyn Fn() -> bool + Sync),
    on_bytes: &(dyn Fn(i64) + Sync),
) -> Result<(), FetchError> {
    if urls.is_empty() {
        return Err(FetchError::msg("Download requires at least one url"));
    }
    let retry = retry.max(1);
    let mut failures: Vec<FetchError> = Vec::new();

    for candidate in urls {
        if url::Url::parse(candidate).is_err() {
            failures.push(FetchError::msg(format!("Invalid URL: {candidate}")));
            continue;
        }
        match download_candidate(agent, candidate, target, sha1, retry, is_cancelled, on_bytes) {
            Ok(()) => return Ok(()),
            Err(e) if e.cancelled => return Err(e),
            Err(e) => failures.push(e),
        }
    }

    let detail = urls.iter().map(|u| format!("- {u}")).collect::<Vec<_>>().join("\n");
    let reasons = failures.iter().map(|f| f.message.clone()).collect::<Vec<_>>().join("; ");
    let code = failures.last().and_then(|f| f.http_code);
    Err(FetchError {
        message: format!("All {} candidate source(s) failed:\n{detail}\n{reasons}", urls.len()),
        http_code: code,
        cancelled: false,
    })
}

fn download_candidate(
    agent: &ureq::Agent,
    url: &str,
    target: &Path,
    sha1: Option<&str>,
    retry: usize,
    is_cancelled: &(dyn Fn() -> bool + Sync),
    on_bytes: &(dyn Fn(i64) + Sync),
) -> Result<(), FetchError> {
    let mut state = State { sink: None, resume: None, counted: 0, on_bytes };
    let mut limit = retry;
    let mut tried = 0usize;
    let mut last: Option<FetchError> = None;

    let outcome = (|| -> Result<(), FetchError> {
        while tried < limit {
            if is_cancelled() {
                return Err(FetchError::cancelled());
            }
            let attempt_no = tried;
            tried += 1;
            match attempt(agent, url, target, sha1, &mut state, is_cancelled) {
                Ok(Attempt::Done) => return Ok(()),
                // retomada inválida ou 416: recomeça sem consumir tentativa
                Ok(Attempt::RestartFree) => limit += 1,
                Err(e) if e.cancelled => return Err(e),
                Err(e) => {
                    // 4xx: este candidato não tem o arquivo
                    if matches!(e.http_code, Some(c) if (400..500).contains(&c)) {
                        return Err(e);
                    }
                    last = Some(e);
                    if attempt_no + 1 < limit {
                        std::thread::sleep(BACKOFF);
                    }
                }
            }
        }
        Err(last.take().unwrap_or_else(|| FetchError::msg("No exceptions")))
    })();

    state.discard_unless_committed(outcome.is_ok());
    outcome.map_err(|e| FetchError { message: format!("Unable to download {url}, {}", e.message), ..e })
}

impl<'a> State<'a> {
    fn discard_unless_committed(&mut self, ok: bool) {
        if !ok {
            self.discard();
        }
    }
}

fn open(agent: &ureq::Agent, start: &str, headers: &[(String, String)]) -> Result<Response, FetchError> {
    let mut current = start.to_string();
    let mut redirects = 0usize;
    loop {
        let mut req = agent.get(&current);
        for (k, v) in headers {
            req = req.set(k, v);
        }
        let resp = match req.call() {
            Ok(r) => r,
            Err(ureq::Error::Status(code, _)) => return Err(FetchError::http(code, &current)),
            Err(ureq::Error::Transport(t)) => return Err(FetchError::msg(t.to_string())),
        };
        let code = resp.status();
        if (300..=308).contains(&code) && code != 304 && code != 306 {
            if redirects >= MAX_REDIRECTS {
                return Err(FetchError::msg("Too much redirects"));
            }
            redirects += 1;
            let loc = resp.header("location").unwrap_or("").trim().to_string();
            if loc.is_empty() {
                return Err(FetchError::msg("Redirected to an empty location"));
            }
            let base = url::Url::parse(&current).map_err(|e| FetchError::msg(e.to_string()))?;
            let next = base.join(&loc).map_err(|e| FetchError::msg(e.to_string()))?;
            if next.scheme() != "http" && next.scheme() != "https" {
                return Err(FetchError::msg(format!("Redirected to non-HTTP URL: {next}")));
            }
            current = next.to_string();
            continue;
        }
        return Ok(Response { code, url: current, inner: resp });
    }
}

fn attempt(
    agent: &ureq::Agent,
    url: &str,
    target: &Path,
    sha1: Option<&str>,
    state: &mut State,
    is_cancelled: &(dyn Fn() -> bool + Sync),
) -> Result<Attempt, FetchError> {
    let mut headers: Vec<(String, String)> = Vec::new();
    let resume_requested = state.resume.as_ref().map(|r| r.has_partial()).unwrap_or(false);
    if resume_requested {
        let r = state.resume.as_ref().unwrap();
        headers.push(("Range".into(), format!("bytes={}-", r.received)));
        headers.push(("If-Range".into(), r.if_range()));
    }

    let response = open(agent, url, &headers)?;
    let code = response.code;

    if resume_requested && code == 416 {
        state.resume = None;
        state.discard();
        return Ok(Attempt::RestartFree);
    }
    if !(200..300).contains(&code) {
        return Err(FetchError::http(code, url));
    }
    let content_length = response.header_i64("content-length");

    if state.sink.is_none() {
        state.sink = Some(Sink::new(target, sha1)?);
        state.resume = Resume::of(&response);
    } else if resume_requested {
        if !state.resume.as_ref().map(|r| r.can_resume(&response)).unwrap_or(false) {
            state.resume = None;
            state.discard();
            return Ok(Attempt::RestartFree);
        }
    } else {
        state.discard();
        state.sink = Some(Sink::new(target, sha1)?);
        state.resume = Resume::of(&response);
    }

    // transferência
    let mut reader = response.inner.into_reader();
    let mut buf = vec![0u8; BUFFER_SIZE];
    let mut written: i64 = 0;
    let transfer = (|| -> Result<(), FetchError> {
        loop {
            if is_cancelled() {
                return Err(FetchError::cancelled());
            }
            let n = reader.read(&mut buf)?;
            if n == 0 {
                break;
            }
            state.sink.as_mut().unwrap().write(&buf[..n])?;
            if let Some(r) = state.resume.as_mut() {
                r.received += n as i64;
            }
            written += n as i64;
            state.report(n as i64);
        }
        if content_length >= 0 && written != content_length {
            return Err(FetchError::msg(format!(
                "Unexpected file size: {written}, expected: {content_length}"
            )));
        }
        Ok(())
    })();

    if let Err(e) = transfer {
        if state.sink.as_ref().map(|s| s.broken).unwrap_or(false) {
            // falha de escrita: nada do que existe é confiável
            state.resume = None;
            state.discard();
        }
        return Err(e);
    }

    if let Err(e) = state.sink.as_mut().unwrap().finish() {
        state.resume = None;
        state.discard();
        return Err(e);
    }
    state.commit();
    Ok(Attempt::Done)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufRead, BufReader};
    use std::net::TcpListener;
    use std::sync::atomic::{AtomicI64, AtomicUsize};
    use std::sync::Arc;

    /// Servidor HTTP mínimo: `routes(path, hit_number) -> (status, body)`.
    fn serve(
        routes: impl Fn(&str, usize) -> (u16, Vec<u8>) + Send + Sync + 'static,
    ) -> (String, Arc<AtomicUsize>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let base = format!("http://{}", listener.local_addr().unwrap());
        let hits = Arc::new(AtomicUsize::new(0));
        let h = hits.clone();
        std::thread::spawn(move || {
            for stream in listener.incoming() {
                let Ok(mut stream) = stream else { continue };
                let mut reader = BufReader::new(stream.try_clone().unwrap());
                let mut line = String::new();
                if reader.read_line(&mut line).is_err() {
                    continue;
                }
                let path = line.split_whitespace().nth(1).unwrap_or("/").to_string();
                loop {
                    let mut l = String::new();
                    if reader.read_line(&mut l).is_err() || l.trim().is_empty() {
                        break;
                    }
                }
                let n = h.fetch_add(1, Ordering::SeqCst);
                let (status, body) = routes(&path, n);
                let head = format!(
                    "HTTP/1.1 {status} X\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
                    body.len()
                );
                let _ = stream.write_all(head.as_bytes());
                let _ = stream.write_all(&body);
            }
        });
        (base, hits)
    }

    fn sha1_hex(data: &[u8]) -> String {
        Sha1::digest(data).iter().map(|b| format!("{:02x}", b)).collect()
    }

    fn agent() -> ureq::Agent {
        build_agent(&HttpConfig::default())
    }

    #[test]
    fn downloads_and_verifies() {
        let body = b"hello catcore".to_vec();
        let b2 = body.clone();
        let (base, _) = serve(move |_, _| (200, b2.clone()));
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("a/b.bin");
        let total = AtomicI64::new(0);
        fetch_file(
            &agent(),
            &[format!("{base}/x")],
            &target,
            Some(&sha1_hex(&body)),
            3,
            &|| false,
            &|d| {
                total.fetch_add(d, Ordering::SeqCst);
            },
        )
        .unwrap();
        assert_eq!(fs::read(&target).unwrap(), body);
        assert_eq!(total.load(Ordering::SeqCst), body.len() as i64);
        // nenhum .part sobrando
        let leftovers = fs::read_dir(target.parent().unwrap()).unwrap().count();
        assert_eq!(leftovers, 1);
    }

    #[test]
    fn bad_checksum_fails_and_rolls_back() {
        let (base, _) = serve(|_, _| (200, b"data".to_vec()));
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("f");
        let total = AtomicI64::new(0);
        let err = fetch_file(
            &agent(),
            &[format!("{base}/x")],
            &target,
            Some("0000000000000000000000000000000000000000"),
            2,
            &|| false,
            &|d| {
                total.fetch_add(d, Ordering::SeqCst);
            },
        )
        .unwrap_err();
        assert!(err.message.contains("Checksum mismatch"));
        assert!(!target.exists());
        assert_eq!(total.load(Ordering::SeqCst), 0, "bytes devolvidos");
        assert_eq!(fs::read_dir(dir.path()).unwrap().count(), 0, "sem .part");
    }

    #[test]
    fn falls_back_to_second_mirror_on_404() {
        let (base, _) = serve(|path, _| {
            if path == "/ok" { (200, b"mirror".to_vec()) } else { (404, Vec::new()) }
        });
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("m");
        fetch_file(
            &agent(),
            &[format!("{base}/missing"), format!("{base}/ok")],
            &target,
            None,
            2,
            &|| false,
            &|_| {},
        )
        .unwrap();
        assert_eq!(fs::read(&target).unwrap(), b"mirror");
    }

    #[test]
    fn retries_on_5xx_then_succeeds() {
        let (base, hits) = serve(|_, n| if n < 2 { (500, Vec::new()) } else { (200, b"ok".to_vec()) });
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("r");
        fetch_file(&agent(), &[format!("{base}/x")], &target, None, 5, &|| false, &|_| {}).unwrap();
        assert_eq!(hits.load(Ordering::SeqCst), 3);
    }

    #[test]
    fn four_oh_four_is_not_retried() {
        let (base, hits) = serve(|_, _| (404, Vec::new()));
        let dir = tempfile::tempdir().unwrap();
        let err = fetch_file(&agent(), &[format!("{base}/x")], &dir.path().join("n"), None, 5, &|| false, &|_| {})
            .unwrap_err();
        assert_eq!(err.http_code, Some(404));
        assert_eq!(hits.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn cancel_stops_early() {
        let (base, _) = serve(|_, _| (200, vec![0u8; 1024]));
        let dir = tempfile::tempdir().unwrap();
        let err = fetch_file(&agent(), &[format!("{base}/x")], &dir.path().join("c"), None, 3, &|| true, &|_| {})
            .unwrap_err();
        assert!(err.cancelled);
        assert_eq!(fs::read_dir(dir.path()).unwrap().count(), 0);
    }

    #[test]
    fn content_range_parsing() {
        assert_eq!(parse_content_range("bytes 10-99/100"), Some((10, 99, 100)));
        assert_eq!(parse_content_range("items 1-2/3"), None);
    }
}
