//! Downloads em lote: paralelismo, rodadas de retentativa, progresso,
//! cancelamento e disjuntor para falhas sistêmicas.
//!
//! Porta do `BatchDownloader.kt` / `DownloadStats.kt`.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;
use std::sync::atomic::{AtomicBool, AtomicI64, AtomicUsize, Ordering};
use std::sync::mpsc;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};

use crate::net::{self, HttpConfig};

/// Falhas permanentes consecutivas (sem nenhum sucesso) que abortam o lote.
pub const SYSTEMIC_FAILURE_LIMIT: usize = 5;
const TICK: Duration = Duration::from_millis(100);

#[derive(Debug, Clone, Deserialize)]
pub struct Request {
    pub urls: Vec<String>,
    pub target: String,
    #[serde(default)]
    pub sha1: Option<String>,
    /// -1 = desconhecido
    #[serde(default = "unknown_size")]
    pub expected_size: i64,
}

fn unknown_size() -> i64 {
    -1
}

#[derive(Debug, Clone, Deserialize)]
pub struct Options {
    #[serde(default = "default_connections")]
    pub max_connections: usize,
    #[serde(default = "default_rounds")]
    pub retry_rounds: usize,
    /// Tentativas por fonte candidata.
    #[serde(default = "default_retry")]
    pub per_source_retries: usize,
    /// Arquivos locais já reaproveitados (entram no progresso).
    #[serde(default)]
    pub preloaded_files: i64,
    #[serde(default)]
    pub preloaded_bytes: i64,
    #[serde(default = "default_ua")]
    pub user_agent: String,
    /// false quando o chamador tolera falhas (conteúdo opcional).
    #[serde(default = "yes")]
    pub systemic_abort: bool,
}

fn default_connections() -> usize {
    64
}
fn default_rounds() -> usize {
    1
}
fn default_retry() -> usize {
    net::DEFAULT_RETRY
}
fn default_ua() -> String {
    "CatLauncher".into()
}
fn yes() -> bool {
    true
}

#[derive(Debug, Clone, Copy, Default, Serialize)]
pub struct Snapshot {
    pub downloaded_bytes: i64,
    pub total_bytes: i64,
    pub downloaded_files: i64,
    pub total_files: i64,
    pub speed: i64,
}

#[derive(Debug, Clone, Serialize)]
pub struct Failure {
    pub index: usize,
    pub path: String,
    pub error: String,
    pub http_code: Option<u16>,
}

#[derive(Debug, Default, Serialize)]
pub struct BatchResult {
    pub failures: Vec<Failure>,
    pub cancelled: bool,
    pub systemic_abort: bool,
    pub completed_files: i64,
}

// ---------------------------------------------------------------- estatística

struct Stats {
    downloaded: AtomicI64,
    total_bytes: AtomicI64, // -1 = desconhecido
    total_files: AtomicI64,
    done_files: AtomicI64,
}

impl Stats {
    fn new() -> Self {
        Self {
            downloaded: AtomicI64::new(0),
            total_bytes: AtomicI64::new(-1),
            total_files: AtomicI64::new(0),
            done_files: AtomicI64::new(0),
        }
    }

    fn register_bytes(&self, bytes: i64) {
        if bytes > 0 {
            let _ = self
                .total_bytes
                .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |p| Some(if p < 0 { bytes } else { p + bytes }));
        }
    }

    fn register_file(&self, expected: i64) {
        self.total_files.fetch_add(1, Ordering::SeqCst);
        self.register_bytes(expected);
    }
}

/// Velocidade em blocos de 1 s: o valor reportado é o tráfego real do último
/// segundo completo.
struct SpeedMeter {
    block_start: Instant,
    block_bytes: i64,
    current: i64,
}

impl SpeedMeter {
    fn new(initial: i64) -> Self {
        Self { block_start: Instant::now(), block_bytes: initial, current: 0 }
    }
    fn refresh(&mut self, bytes: i64) -> i64 {
        let el = self.block_start.elapsed();
        if el >= Duration::from_secs(1) {
            self.current = ((bytes - self.block_bytes).max(0) as f64 / el.as_secs_f64()) as i64;
            self.block_start = Instant::now();
            self.block_bytes = bytes;
        }
        self.current
    }
}

// ------------------------------------------------------------------ handles

fn registry() -> &'static Mutex<HashMap<u64, Arc<AtomicBool>>> {
    static R: OnceLock<Mutex<HashMap<u64, Arc<AtomicBool>>>> = OnceLock::new();
    R.get_or_init(|| Mutex::new(HashMap::new()))
}

static NEXT_HANDLE: AtomicI64 = AtomicI64::new(1);

/// Cria um token de cancelamento acessível por id (para o JNI).
pub fn new_handle() -> (u64, Arc<AtomicBool>) {
    let id = NEXT_HANDLE.fetch_add(1, Ordering::SeqCst) as u64;
    let flag = Arc::new(AtomicBool::new(false));
    registry().lock().unwrap().insert(id, flag.clone());
    (id, flag)
}

pub fn cancel_handle(id: u64) {
    if let Some(f) = registry().lock().unwrap().get(&id) {
        f.store(true, Ordering::SeqCst);
    }
}

pub fn release_handle(id: u64) {
    registry().lock().unwrap().remove(&id);
}

pub fn handle_flag(id: u64) -> Option<Arc<AtomicBool>> {
    registry().lock().unwrap().get(&id).cloned()
}

// --------------------------------------------------------------------- lote

enum Event {
    FileDone(usize),
}

/// Executa o lote. Bloqueia até terminar.
///
/// - `on_tick`: a cada ~100 ms; devolver `false` cancela o lote.
/// - `on_file`: chamado (na thread do chamador) após cada arquivo concluído.
pub fn run_batch(
    requests: &[Request],
    opts: &Options,
    cancel: Arc<AtomicBool>,
    on_tick: &mut dyn FnMut(&Snapshot) -> bool,
    on_file: &mut dyn FnMut(usize),
) -> BatchResult {
    let n = requests.len();
    let stats = Stats::new();
    stats.total_files.store(opts.preloaded_files, Ordering::SeqCst);
    stats.done_files.store(opts.preloaded_files, Ordering::SeqCst);
    stats.downloaded.store(opts.preloaded_bytes.max(0), Ordering::SeqCst);
    stats.register_bytes(opts.preloaded_bytes);
    for r in requests {
        stats.register_file(r.expected_size);
    }

    let agent = net::build_agent(&HttpConfig {
        user_agent: opts.user_agent.clone(),
        ..HttpConfig::default()
    });

    let abort = AtomicBool::new(false);
    let next = AtomicUsize::new(0);
    let consecutive_failures = AtomicUsize::new(0);
    let failures: Mutex<Vec<Failure>> = Mutex::new(Vec::new());
    let workers = opts.max_connections.max(1).min(n.max(1));
    let (tx, rx) = mpsc::channel::<Event>();

    let is_cancelled = || cancel.load(Ordering::Relaxed) || abort.load(Ordering::Relaxed);

    let mut meter = SpeedMeter::new(stats.downloaded.load(Ordering::SeqCst));
    let snapshot = |meter: &mut SpeedMeter| {
        let d = stats.downloaded.load(Ordering::SeqCst);
        Snapshot {
            downloaded_bytes: d,
            total_bytes: stats.total_bytes.load(Ordering::SeqCst),
            downloaded_files: stats.done_files.load(Ordering::SeqCst),
            total_files: stats.total_files.load(Ordering::SeqCst),
            speed: meter.refresh(d),
        }
    };

    std::thread::scope(|scope| {
        for _ in 0..workers {
            let tx = tx.clone();
            let (stats, agent, next, failures, consecutive, abort, is_cancelled) =
                (&stats, &agent, &next, &failures, &consecutive_failures, &abort, &is_cancelled);
            scope.spawn(move || {
                loop {
                    if is_cancelled() {
                        break;
                    }
                    let i = next.fetch_add(1, Ordering::SeqCst);
                    if i >= n {
                        break;
                    }
                    let req = &requests[i];
                    let on_bytes = |d: i64| {
                        stats.downloaded.fetch_add(d, Ordering::Relaxed);
                    };
                    let mut last: Option<net::FetchError> = None;
                    let mut ok = false;
                    for _ in 0..=opts.retry_rounds {
                        match net::fetch_file(
                            agent,
                            &req.urls,
                            Path::new(&req.target),
                            req.sha1.as_deref(),
                            opts.per_source_retries,
                            is_cancelled,
                            &on_bytes,
                        ) {
                            Ok(()) => {
                                ok = true;
                                break;
                            }
                            Err(e) if e.cancelled => {
                                last = Some(e);
                                break;
                            }
                            Err(e) => last = Some(e),
                        }
                    }
                    if ok {
                        // arquivo sem tamanho declarado: completa o denominador
                        if req.expected_size <= 0 {
                            if let Ok(m) = std::fs::metadata(&req.target) {
                                stats.register_bytes(m.len() as i64);
                            }
                        }
                        stats.done_files.fetch_add(1, Ordering::SeqCst);
                        consecutive.store(0, Ordering::SeqCst);
                        let _ = tx.send(Event::FileDone(i));
                    } else if let Some(e) = last {
                        if e.cancelled {
                            break;
                        }
                        failures.lock().unwrap().push(Failure {
                            index: i,
                            path: req.target.clone(),
                            error: e.message,
                            http_code: e.http_code,
                        });
                        // disjuntor: lote sem nenhum sucesso e falhas seguidas
                        if opts.systemic_abort && stats.done_files.load(Ordering::SeqCst) == 0 {
                            let c = consecutive.fetch_add(1, Ordering::SeqCst) + 1;
                            if c >= SYSTEMIC_FAILURE_LIMIT {
                                abort.store(true, Ordering::SeqCst);
                            }
                        }
                    }
                }
            });
        }
        drop(tx);

        // thread do chamador: eventos de arquivo + ticks de progresso
        let mut last_tick = Instant::now();
        loop {
            match rx.recv_timeout(TICK) {
                Ok(Event::FileDone(i)) => on_file(i),
                Err(mpsc::RecvTimeoutError::Timeout) => {}
                Err(mpsc::RecvTimeoutError::Disconnected) => break,
            }
            if last_tick.elapsed() >= TICK {
                last_tick = Instant::now();
                if !on_tick(&snapshot(&mut meter)) {
                    cancel.store(true, Ordering::SeqCst);
                }
            }
        }
    });

    on_tick(&snapshot(&mut meter));

    let mut failures = failures.into_inner().unwrap();
    failures.sort_by_key(|f| f.index);
    let systemic = abort.load(Ordering::SeqCst);
    BatchResult {
        failures,
        cancelled: cancel.load(Ordering::SeqCst) && !systemic,
        systemic_abort: systemic,
        completed_files: stats.done_files.load(Ordering::SeqCst),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufRead, BufReader, Write};
    use std::net::TcpListener;

    fn serve(routes: impl Fn(&str) -> (u16, Vec<u8>) + Send + Sync + 'static) -> String {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let base = format!("http://{}", listener.local_addr().unwrap());
        let routes = Arc::new(routes);
        std::thread::spawn(move || {
            for stream in listener.incoming() {
                let Ok(mut stream) = stream else { continue };
                let routes = routes.clone();
                std::thread::spawn(move || {
                    let mut reader = BufReader::new(stream.try_clone().unwrap());
                    let mut line = String::new();
                    let _ = reader.read_line(&mut line);
                    let path = line.split_whitespace().nth(1).unwrap_or("/").to_string();
                    loop {
                        let mut l = String::new();
                        if reader.read_line(&mut l).is_err() || l.trim().is_empty() {
                            break;
                        }
                    }
                    let (status, body) = routes(&path);
                    let head = format!(
                        "HTTP/1.1 {status} X\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
                        body.len()
                    );
                    let _ = stream.write_all(head.as_bytes());
                    let _ = stream.write_all(&body);
                });
            }
        });
        base
    }

    fn opts() -> Options {
        serde_json::from_str("{}").unwrap()
    }

    fn req(base: &str, name: &str, dir: &Path) -> Request {
        Request {
            urls: vec![format!("{base}/{name}")],
            target: dir.join(name).to_string_lossy().into_owned(),
            sha1: None,
            expected_size: -1,
        }
    }

    #[test]
    fn parallel_batch_downloads_everything() {
        let base = serve(|p| (200, p.as_bytes().to_vec()));
        let dir = tempfile::tempdir().unwrap();
        let reqs: Vec<Request> = (0..40).map(|i| req(&base, &format!("f{i}"), dir.path())).collect();
        let mut done = Vec::new();
        let mut ticks = 0;
        let res = run_batch(
            &reqs,
            &opts(),
            Arc::new(AtomicBool::new(false)),
            &mut |_| {
                ticks += 1;
                true
            },
            &mut |i| done.push(i),
        );
        assert!(res.failures.is_empty());
        assert_eq!(res.completed_files, 40);
        assert_eq!(done.len(), 40);
        assert!(ticks >= 1);
        for i in 0..40 {
            assert_eq!(std::fs::read(dir.path().join(format!("f{i}"))).unwrap(), format!("/f{i}").into_bytes());
        }
    }

    #[test]
    fn reports_failures_per_file() {
        let base = serve(|p| if p == "/bad" { (404, Vec::new()) } else { (200, b"x".to_vec()) });
        let dir = tempfile::tempdir().unwrap();
        let reqs = vec![req(&base, "good", dir.path()), req(&base, "bad", dir.path())];
        let res = run_batch(&reqs, &opts(), Arc::new(AtomicBool::new(false)), &mut |_| true, &mut |_| {});
        assert_eq!(res.failures.len(), 1);
        assert_eq!(res.failures[0].index, 1);
        assert_eq!(res.failures[0].http_code, Some(404));
        assert!(!res.systemic_abort);
    }

    #[test]
    fn systemic_failure_aborts_batch() {
        let base = serve(|_| (404, Vec::new()));
        let dir = tempfile::tempdir().unwrap();
        let reqs: Vec<Request> = (0..200).map(|i| req(&base, &format!("f{i}"), dir.path())).collect();
        let mut o = opts();
        o.max_connections = 1;
        let res = run_batch(&reqs, &o, Arc::new(AtomicBool::new(false)), &mut |_| true, &mut |_| {});
        assert!(res.systemic_abort);
        assert!(res.failures.len() < 200);
    }

    #[test]
    fn tolerant_mode_does_not_abort() {
        let base = serve(|_| (404, Vec::new()));
        let dir = tempfile::tempdir().unwrap();
        let reqs: Vec<Request> = (0..12).map(|i| req(&base, &format!("f{i}"), dir.path())).collect();
        let mut o = opts();
        o.systemic_abort = false;
        let res = run_batch(&reqs, &o, Arc::new(AtomicBool::new(false)), &mut |_| true, &mut |_| {});
        assert!(!res.systemic_abort);
        assert_eq!(res.failures.len(), 12);
    }

    #[test]
    fn tick_false_cancels() {
        let base = serve(|_| {
            std::thread::sleep(Duration::from_millis(400));
            (200, b"x".to_vec())
        });
        let dir = tempfile::tempdir().unwrap();
        let reqs: Vec<Request> = (0..50).map(|i| req(&base, &format!("f{i}"), dir.path())).collect();
        let mut o = opts();
        o.max_connections = 2;
        let res = run_batch(&reqs, &o, Arc::new(AtomicBool::new(false)), &mut |_| false, &mut |_| {});
        assert!(res.cancelled);
        assert!(res.completed_files < 50);
    }

    #[test]
    fn handles_register_and_cancel() {
        let (id, flag) = new_handle();
        assert!(!flag.load(Ordering::SeqCst));
        cancel_handle(id);
        assert!(flag.load(Ordering::SeqCst));
        release_handle(id);
        assert!(handle_flag(id).is_none());
    }
}
