//! Perfil de desempenho: flags de JVM/GC aplicadas na entrada do jogo.
//!
//! O Kotlin passa o perfil escolhido, a versão do Java, os núcleos, a RAM do jogo e os
//! argumentos JVM que já existem (os do usuário valem mais): o Rust devolve só os
//! argumentos que ainda faltam, sem repetir nenhuma chave que o usuário já definiu.

use serde::Deserialize;

#[derive(Debug, Default, Deserialize)]
pub struct PerfParams {
    /// `off`, `auto`, `low`, `balanced` ou `quality`; outro valor equivale a `off`.
    #[serde(default)]
    pub profile: String,
    #[serde(default)]
    pub java_major: i32,
    #[serde(default)]
    pub cores: i32,
    #[serde(default)]
    pub ram_mb: i32,
    /// Argumentos JVM já montados (usuário + launcher).
    #[serde(default)]
    pub existing: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Profile {
    Off,
    Low,
    Balanced,
    Quality,
}

/// Resolve o nome do perfil; `auto` escolhe pelo hardware.
pub fn resolve(p: &PerfParams) -> Profile {
    match p.profile.trim().to_ascii_lowercase().as_str() {
        "low" => Profile::Low,
        "balanced" => Profile::Balanced,
        "quality" => Profile::Quality,
        "auto" => {
            if p.cores <= 4 || p.ram_mb < 3072 {
                Profile::Low
            } else if p.cores >= 8 && p.ram_mb >= 6144 {
                Profile::Quality
            } else {
                Profile::Balanced
            }
        }
        _ => Profile::Off,
    }
}

/// Seletores de coletor: se o usuário já escolheu um, nenhuma flag de GC do perfil entra.
const GC_SELECTORS: [&str; 7] = [
    "UseSerialGC",
    "UseParallelGC",
    "UseParallelOldGC",
    "UseG1GC",
    "UseZGC",
    "UseShenandoahGC",
    "UseConcMarkSweepGC",
];

/// A chave de um argumento: `-XX:+Foo`/`-XX:-Foo`/`-XX:Foo=1` -> `Foo`; `-Xmn64M` -> `-Xmn`.
fn key_of(arg: &str) -> String {
    if let Some(rest) = arg.strip_prefix("-XX:") {
        let rest = rest.trim_start_matches(['+', '-']);
        return rest.split('=').next().unwrap_or(rest).to_string();
    }
    if arg.starts_with("-Xmn") {
        return "-Xmn".to_string();
    }
    arg.to_string()
}

struct Flag {
    arg: String,
    /// Faz parte do ajuste de GC (some junto se o usuário já escolheu o coletor).
    gc: bool,
}

fn flag(arg: impl Into<String>, gc: bool) -> Flag {
    Flag { arg: arg.into(), gc }
}

fn flags_for(profile: Profile, p: &PerfParams) -> Vec<Flag> {
    let cores = p.cores.max(1);
    let mut out: Vec<Flag> = Vec::new();
    if profile != Profile::Off {
        // Rede de segurança: uma flag que o JRE não conhece vira aviso, não falha de abertura.
        out.push(flag("-XX:+IgnoreUnrecognizedVMOptions", false));
        // Início mais rápido: pula a verificação de bytecode das classes carregadas do jogo/mods
        // (a verificação das classes do próprio JDK nunca é feita). Só em 8..=21, onde a flag existe.
        if (8..=21).contains(&p.java_major) {
            out.push(flag("-XX:-BytecodeVerificationRemote", false));
        }
    }
    match profile {
        Profile::Off => return out,
        Profile::Low => {
            // Pouca CPU/RAM: coletor simples, sem threads de GC concorrentes.
            out.push(flag("-XX:+UseSerialGC", true));
            if p.ram_mb > 0 {
                let young = (p.ram_mb * 35 / 100).max(64);
                out.push(flag(format!("-Xmn{young}M"), true));
            }
            if cores <= 4 {
                // Menos threads de compilação disputando CPU com o jogo.
                out.push(flag("-XX:CICompilerCount=2", false));
            }
        }
        Profile::Balanced | Profile::Quality => {
            let quality = profile == Profile::Quality;
            // G1NewSizePercent / G1MaxNewSizePercent / G1ReservePercent são experimentais.
            out.push(flag("-XX:+UnlockExperimentalVMOptions", true));
            out.push(flag("-XX:+UseG1GC", true));
            out.push(flag(
                format!("-XX:MaxGCPauseMillis={}", if quality { 40 } else { 30 }),
                true,
            ));
            out.push(flag("-XX:+ParallelRefProcEnabled", true));
            out.push(flag(
                format!("-XX:G1NewSizePercent={}", if quality { 40 } else { 30 }),
                true,
            ));
            out.push(flag(
                format!("-XX:G1MaxNewSizePercent={}", if quality { 60 } else { 50 }),
                true,
            ));
            out.push(flag(
                format!("-XX:G1ReservePercent={}", if quality { 20 } else { 15 }),
                true,
            ));
            let parallel = if quality { (cores - 2).max(2) } else { (cores / 2).max(2) };
            out.push(flag(format!("-XX:ParallelGCThreads={parallel}"), true));
            out.push(flag(format!("-XX:ConcGCThreads={}", (cores / 4).max(1)), true));
        }
    }
    // Comum a todos os perfis ligados: não cria o arquivo mmap de estatísticas da JVM.
    out.push(flag("-XX:-UsePerfData", false));
    out
}

/// Os argumentos que o perfil acrescenta, sem repetir o que `existing` já define.
pub fn profile_args(p: &PerfParams) -> Vec<String> {
    let profile = resolve(p);
    if profile == Profile::Off {
        return Vec::new();
    }
    let existing_keys: Vec<String> = p.existing.iter().map(|a| key_of(a)).collect();
    let user_chose_gc = existing_keys
        .iter()
        .any(|k| GC_SELECTORS.contains(&k.as_str()));

    let mut out: Vec<String> = Vec::new();
    for f in flags_for(profile, p) {
        if f.gc && user_chose_gc {
            continue;
        }
        let key = key_of(&f.arg);
        if existing_keys.contains(&key) || out.iter().any(|a| key_of(a) == key) {
            continue;
        }
        out.push(f.arg);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn params(profile: &str, cores: i32, ram_mb: i32, existing: &[&str]) -> PerfParams {
        PerfParams {
            profile: profile.to_string(),
            java_major: 21,
            cores,
            ram_mb,
            existing: existing.iter().map(|s| s.to_string()).collect(),
        }
    }

    #[test]
    fn off_and_unknown_add_nothing() {
        assert!(profile_args(&params("off", 8, 4096, &[])).is_empty());
        assert!(profile_args(&params("", 8, 4096, &[])).is_empty());
        assert!(profile_args(&params("turbo", 8, 4096, &[])).is_empty());
    }

    #[test]
    fn low_uses_serial_gc_and_sizes_young_generation() {
        let a = profile_args(&params("low", 4, 1000, &[]));
        assert!(a.contains(&"-XX:+UseSerialGC".to_string()));
        assert!(a.contains(&"-Xmn350M".to_string()));
        assert!(a.contains(&"-XX:CICompilerCount=2".to_string()));
        assert!(a.contains(&"-XX:-UsePerfData".to_string()));
        assert!(!a.iter().any(|x| x.contains("G1")));
    }

    #[test]
    fn young_generation_has_a_floor() {
        let a = profile_args(&params("low", 4, 100, &[]));
        assert!(a.contains(&"-Xmn64M".to_string()));
    }

    #[test]
    fn balanced_unlocks_experimental_before_g1_tuning() {
        let a = profile_args(&params("balanced", 6, 4096, &[]));
        let unlock = a.iter().position(|x| x == "-XX:+UnlockExperimentalVMOptions").unwrap();
        let g1 = a.iter().position(|x| x == "-XX:G1NewSizePercent=30").unwrap();
        assert!(unlock < g1);
        assert!(a.contains(&"-XX:ParallelGCThreads=3".to_string()));
        assert!(a.contains(&"-XX:ConcGCThreads=1".to_string()));
    }

    #[test]
    fn quality_is_more_generous_than_balanced() {
        let a = profile_args(&params("quality", 8, 8192, &[]));
        assert!(a.contains(&"-XX:MaxGCPauseMillis=40".to_string()));
        assert!(a.contains(&"-XX:G1NewSizePercent=40".to_string()));
        assert!(a.contains(&"-XX:ParallelGCThreads=6".to_string()));
    }

    #[test]
    fn auto_follows_the_hardware() {
        assert_eq!(resolve(&params("auto", 4, 8192, &[])), Profile::Low);
        assert_eq!(resolve(&params("auto", 8, 2048, &[])), Profile::Low);
        assert_eq!(resolve(&params("auto", 6, 4096, &[])), Profile::Balanced);
        assert_eq!(resolve(&params("auto", 8, 8192, &[])), Profile::Quality);
    }

    #[test]
    fn user_chosen_gc_wins_and_removes_all_gc_tuning() {
        let a = profile_args(&params("balanced", 6, 4096, &["-XX:+UseParallelGC"]));
        assert!(!a.iter().any(|x| x.contains("G1") || x.contains("GCThreads")));
        assert!(!a.contains(&"-XX:+UseG1GC".to_string()));
        assert!(a.contains(&"-XX:-UsePerfData".to_string()));
    }

    #[test]
    fn user_value_of_the_same_key_is_kept_once() {
        let a = profile_args(&params("balanced", 6, 4096, &["-XX:MaxGCPauseMillis=10"]));
        assert!(!a.iter().any(|x| x.starts_with("-XX:MaxGCPauseMillis")));
        assert!(a.contains(&"-XX:+UseG1GC".to_string()));
    }

    #[test]
    fn user_xmn_wins() {
        let a = profile_args(&params("low", 4, 2000, &["-Xmn128M"]));
        assert!(!a.iter().any(|x| x.starts_with("-Xmn")));
    }

    #[test]
    fn startup_flags_come_first_and_respect_java_version() {
        let a = profile_args(&params("low", 4, 2000, &[]));
        assert_eq!(a[0], "-XX:+IgnoreUnrecognizedVMOptions");
        assert!(a.contains(&"-XX:-BytecodeVerificationRemote".to_string()));

        let mut p = params("low", 4, 2000, &[]);
        p.java_major = 25;
        assert!(!profile_args(&p).contains(&"-XX:-BytecodeVerificationRemote".to_string()));
        p.java_major = 0;
        assert!(!profile_args(&p).contains(&"-XX:-BytecodeVerificationRemote".to_string()));
    }

    #[test]
    fn user_can_keep_bytecode_verification() {
        let a = profile_args(&params("low", 4, 2000, &["-XX:+BytecodeVerificationRemote"]));
        assert!(!a.iter().any(|x| x.contains("BytecodeVerificationRemote")));
    }

    #[test]
    fn no_duplicate_keys() {
        let a = profile_args(&params("quality", 8, 8192, &[]));
        let mut keys: Vec<String> = a.iter().map(|x| key_of(x)).collect();
        let n = keys.len();
        keys.sort();
        keys.dedup();
        assert_eq!(n, keys.len());
    }

    #[test]
    fn key_of_handles_all_forms() {
        assert_eq!(key_of("-XX:+UseG1GC"), "UseG1GC");
        assert_eq!(key_of("-XX:-UsePerfData"), "UsePerfData");
        assert_eq!(key_of("-XX:MaxGCPauseMillis=30"), "MaxGCPauseMillis");
        assert_eq!(key_of("-Xmn350M"), "-Xmn");
        assert_eq!(key_of("-Dfoo=bar"), "-Dfoo=bar");
    }
}
