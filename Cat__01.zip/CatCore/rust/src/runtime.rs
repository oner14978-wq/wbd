//! Gerenciamento de runtimes Java: leitura, seleção, instalação.

use serde::Serialize;
use std::fs::{self, File};
use std::io::{BufReader, BufWriter};
use std::path::{Component, Path, PathBuf};

use crate::version;

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct RuntimeInfo {
    pub name: String,
    pub version_string: Option<String>,
    pub arch: Option<String>,
    pub java_version: i32,
    pub is_jdk8: bool,
}

impl RuntimeInfo {
    fn broken(name: &str) -> Self {
        Self {
            name: name.to_string(),
            version_string: None,
            arch: None,
            java_version: 0,
            is_jdk8: false,
        }
    }
}

fn extract_until(content: &str, what_for: &str, terminator: char) -> Option<String> {
    let start = content.find(what_for)? + what_for.len();
    let rest = &content[start..];
    let end = rest.find(terminator)?;
    Some(rest[..end].to_string())
}

pub fn is_jdk8(runtime_dir: &Path) -> bool {
    runtime_dir.join("jre").exists() && runtime_dir.join("bin/javac").exists()
}

/// Lê `release` do runtime. Runtime sem `release` válido => "quebrado".
pub fn load_runtime(root: &Path, name: &str) -> RuntimeInfo {
    let dir = root.join(name);
    let Ok(content) = fs::read_to_string(dir.join("release")) else {
        return RuntimeInfo::broken(name);
    };
    let ver = extract_until(&content, "JAVA_VERSION=\"", '"');
    let arch = extract_until(&content, "OS_ARCH=\"", '"');
    match (ver, arch) {
        (Some(v), Some(a)) => RuntimeInfo {
            name: name.to_string(),
            java_version: version::java_major(&v),
            version_string: Some(v),
            arch: Some(a),
            is_jdk8: is_jdk8(&dir),
        },
        _ => RuntimeInfo::broken(name),
    }
}

/// Todos os runtimes, do mais novo para o mais antigo.
pub fn list_runtimes(root: &Path) -> Result<Vec<RuntimeInfo>, String> {
    if !root.exists() {
        return Ok(Vec::new());
    }
    let rd = fs::read_dir(root).map_err(|e| e.to_string())?;
    let mut list: Vec<RuntimeInfo> = rd
        .filter_map(|e| e.ok())
        .filter(|e| e.path().is_dir())
        .map(|e| load_runtime(root, &e.file_name().to_string_lossy()))
        .collect();
    list.sort_by(|a, b| {
        let va = a.version_string.as_deref().unwrap_or(&a.name);
        let vb = b.version_string.as_deref().unwrap_or(&b.name);
        version::compare(vb, va)
    });
    Ok(list)
}

pub fn exact_runtime(list: &[RuntimeInfo], major: i32) -> Option<&RuntimeInfo> {
    list.iter().find(|r| r.java_version == major)
}

/// Runtime com menor versão >= `major` (`findNearestPositive`).
pub fn nearest_runtime(list: &[RuntimeInfo], major: i32) -> Option<&RuntimeInfo> {
    let mut best: Option<&RuntimeInfo> = None;
    let mut min_delta = i32::MAX;
    for r in list {
        if r.java_version < major {
            continue;
        }
        let delta = r.java_version - major;
        if delta == 0 {
            return Some(r);
        }
        if delta < min_delta {
            min_delta = delta;
            best = Some(r);
        }
    }
    best
}

fn safe_join(dest: &Path, entry: &Path) -> Result<PathBuf, String> {
    let mut out = dest.to_path_buf();
    for c in entry.components() {
        match c {
            Component::Normal(p) => out.push(p),
            Component::CurDir => {}
            _ => return Err(format!("entrada tar insegura: {}", entry.display())),
        }
    }
    Ok(out)
}

/// Extrai `.tar.xz` em `dest`. `on_entry` recebe o nome de cada entrada e
/// devolve `false` para cancelar a extração.
/// Retorna o número de entradas processadas.
pub fn extract_tar_xz(
    src: &Path,
    dest: &Path,
    on_entry: &mut dyn FnMut(&str) -> bool,
) -> Result<u64, String> {
    fs::create_dir_all(dest).map_err(|e| e.to_string())?;

    // xz -> tar temporário em disco (evita carregar o JRE inteiro na RAM)
    let tmp_tar = dest.join(".catcore-extract.tar");
    {
        let mut input = BufReader::new(File::open(src).map_err(|e| format!("abrir {}: {}", src.display(), e))?);
        let mut output = BufWriter::new(File::create(&tmp_tar).map_err(|e| e.to_string())?);
        lzma_rs::xz_decompress(&mut input, &mut output).map_err(|e| format!("xz: {:?}", e))?;
    }

    let result = (|| -> Result<u64, String> {
        let mut archive = tar::Archive::new(File::open(&tmp_tar).map_err(|e| e.to_string())?);
        let mut count = 0u64;
        for entry in archive.entries().map_err(|e| e.to_string())? {
            let mut entry = entry.map_err(|e| e.to_string())?;
            let rel = entry.path().map_err(|e| e.to_string())?.into_owned();
            if !on_entry(&rel.to_string_lossy()) {
                return Err("cancelled".to_string());
            }
            let target = safe_join(dest, &rel)?;
            if let Some(parent) = target.parent() {
                fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            let kind = entry.header().entry_type();
            if kind.is_symlink() {
                #[cfg(unix)]
                {
                    if let Ok(Some(link)) = entry.link_name() {
                        let _ = fs::remove_file(&target);
                        let _ = std::os::unix::fs::symlink(link.as_ref(), &target);
                    }
                }
            } else if kind.is_dir() {
                fs::create_dir_all(&target).map_err(|e| e.to_string())?;
            } else if kind.is_file() {
                let size = entry.header().size().unwrap_or(0);
                let same = fs::metadata(&target).map(|m| m.len() == size).unwrap_or(false);
                if !same {
                    let mut out = File::create(&target).map_err(|e| e.to_string())?;
                    std::io::copy(&mut entry, &mut out).map_err(|e| e.to_string())?;
                }
                #[cfg(unix)]
                {
                    use std::os::unix::fs::PermissionsExt;
                    if let Ok(mode) = entry.header().mode() {
                        let _ = fs::set_permissions(&target, fs::Permissions::from_mode(mode));
                    }
                }
            }
            count += 1;
        }
        Ok(count)
    })();

    let _ = fs::remove_file(&tmp_tar);
    result
}

fn collect_packs(dir: &Path, out: &mut Vec<PathBuf>) {
    let Ok(rd) = fs::read_dir(dir) else { return };
    for e in rd.filter_map(|e| e.ok()) {
        let p = e.path();
        if p.is_dir() {
            collect_packs(&p, out);
        } else if p.extension().map(|x| x == "pack").unwrap_or(false) {
            out.push(p);
        }
    }
}

/// Converte `.pack` em `.jar` (apenas Java 8) usando `libunpack200.so`.
pub fn unpack200(native_lib_dir: &Path, runtime_path: &Path) {
    let mut packs = Vec::new();
    collect_packs(runtime_path, &mut packs);
    for pack in packs {
        let src = pack.to_string_lossy().into_owned();
        let dst = src.replace(".pack", "");
        let _ = std::process::Command::new("./libunpack200.so")
            .current_dir(native_lib_dir)
            .args(["-r", &src, &dst])
            .status();
    }
}

fn copy_replace(from: &Path, to: &Path) -> std::io::Result<()> {
    if to.exists() {
        fs::remove_file(to)?;
    }
    if let Some(parent) = to.parent() {
        fs::create_dir_all(parent)?;
    }
    fs::copy(from, to).map(|_| ())
}

/// Ajustes pós-instalação: freetype, `libawt_xawt.so`, `libjsound.so`.
pub fn post_prepare(root: &Path, name: &str, native_lib_dir: &Path) -> Result<(), String> {
    let dest = root.join(name);
    if !dest.exists() {
        return Ok(());
    }
    let info = load_runtime(root, name);
    let mut lib_folder = String::from("lib");
    if let Some(arch) = &info.arch {
        if dest.join(&lib_folder).join(arch).exists() {
            lib_folder = format!("lib/{}", arch);
        }
    }
    let jdk8 = is_jdk8(&dest);
    if jdk8 {
        lib_folder = format!("jre/{}", lib_folder);
    }
    let libdir = dest.join(&lib_folder);

    let ft_in = libdir.join("libfreetype.so.6");
    let ft_out = libdir.join("libfreetype.so");
    if ft_in.exists() {
        let differs = !ft_out.exists()
            || fs::metadata(&ft_in).map(|m| m.len()).ok() != fs::metadata(&ft_out).map(|m| m.len()).ok();
        if differs {
            fs::rename(&ft_in, &ft_out).map_err(|e| format!("Failed to rename freetype: {}", e))?;
        }
    }

    let xawt = native_lib_dir.join("libawt_xawt.so");
    copy_replace(&xawt, &libdir.join("libawt_xawt.so")).map_err(|e| e.to_string())?;

    let jsound = native_lib_dir.join("libjsound.so");
    if jsound.exists() {
        copy_replace(&jsound, &libdir.join("libjsound.so")).map_err(|e| e.to_string())?;
    }
    Ok(())
}

/// Instala um runtime a partir de um `.tar.xz` completo.
pub fn install_runtime(
    src: &Path,
    root: &Path,
    name: &str,
    native_lib_dir: &Path,
    on_entry: &mut dyn FnMut(&str) -> bool,
) -> Result<RuntimeInfo, String> {
    let dest = root.join(name);
    let mut run = || -> Result<RuntimeInfo, String> {
        if dest.exists() {
            fs::remove_dir_all(&dest).map_err(|e| e.to_string())?;
        }
        extract_tar_xz(src, &dest, on_entry)?;
        unpack200(native_lib_dir, &dest);
        post_prepare(root, name, native_lib_dir)?;
        Ok(load_runtime(root, name))
    };
    run().map_err(|e| {
        let _ = fs::remove_dir_all(&dest);
        e
    })
}

/// Instala runtime dividido em pacote universal + binários da plataforma.
pub fn install_runtime_bin_pack(
    universal: &Path,
    platform_bins: &Path,
    root: &Path,
    name: &str,
    bin_pack_version: &str,
    native_lib_dir: &Path,
    on_entry: &mut dyn FnMut(&str) -> bool,
) -> Result<RuntimeInfo, String> {
    let dest = root.join(name);
    let mut run = || -> Result<RuntimeInfo, String> {
        if dest.exists() {
            fs::remove_dir_all(&dest).map_err(|e| e.to_string())?;
        }
        extract_tar_xz(universal, &dest, on_entry)?;
        extract_tar_xz(platform_bins, &dest, on_entry)?;
        unpack200(native_lib_dir, &dest);
        fs::write(dest.join("version"), bin_pack_version).map_err(|e| e.to_string())?;
        Ok(load_runtime(root, name))
    };
    run().map_err(|e| {
        let _ = fs::remove_dir_all(&dest);
        e
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mk(root: &Path, name: &str, ver: &str, arch: &str) {
        let d = root.join(name);
        fs::create_dir_all(&d).unwrap();
        fs::write(
            d.join("release"),
            format!("JAVA_VERSION=\"{}\"\nOS_ARCH=\"{}\"\n", ver, arch),
        )
        .unwrap();
    }

    #[test]
    fn load_and_pick() {
        let t = tempfile::tempdir().unwrap();
        mk(t.path(), "jre-8", "1.8.0_392", "aarch64");
        mk(t.path(), "jre-17", "17.0.9", "aarch64");
        mk(t.path(), "jre-21", "21.0.2", "aarch64");
        fs::create_dir_all(t.path().join("broken")).unwrap();

        let list = list_runtimes(t.path()).unwrap();
        assert_eq!(exact_runtime(&list, 17).unwrap().name, "jre-17");
        assert_eq!(nearest_runtime(&list, 18).unwrap().name, "jre-21");
        assert!(nearest_runtime(&list, 22).is_none());
        assert_eq!(load_runtime(t.path(), "jre-8").java_version, 8);
        assert_eq!(load_runtime(t.path(), "broken").java_version, 0);
    }
}
