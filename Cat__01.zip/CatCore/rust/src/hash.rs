//! Verificação SHA-1 de arquivos.

use sha1::{Digest, Sha1};
use std::fs::File;
use std::io::Read;
use std::path::Path;

pub fn sha1_file(path: &Path) -> std::io::Result<String> {
    let mut file = File::open(path)?;
    let mut hasher = Sha1::new();
    let mut buf = [0u8; 64 * 1024];
    loop {
        let n = file.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
    }
    let digest = hasher.finalize();
    Ok(digest.iter().map(|b| format!("{:02x}", b)).collect())
}

/// Mesma semântica de `compareSHA1` do Kotlin antigo:
/// arquivo inexistente -> false; erro de leitura -> `default`;
/// sem hash esperado -> `default`.
pub fn compare_sha1(path: &Path, expected: Option<&str>, default: bool) -> bool {
    if !path.exists() {
        return false;
    }
    match sha1_file(path) {
        Ok(actual) => expected
            .map(|e| e.eq_ignore_ascii_case(&actual))
            .unwrap_or(default),
        Err(_) => default,
    }
}
