-keepclasseswithmembernames class com.movtery.zalithlauncher.core.** {
    native <methods>;
}
