/*
 * Zalith Launcher 2
 * Copyright (C) 2025-2026 MovTery <movtery228@qq.com> and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/gpl-3.0.txt>.
 */

package com.movtery.zalithlauncher.core

/**
 * Ponte nativa do CatCore (Rust). Cada função corresponde a um símbolo JNI
 * `Java_com_movtery_zalithlauncher_core_CatCoreNative_<nome>` em `libcatcore.so`.
 *
 * Dados estruturados trafegam como JSON. Erros (e panics) viram
 * [IllegalStateException]. Use a fachada `CatCore` (módulo CatLauncher) em vez
 * de chamar este objeto diretamente.
 */
object CatCoreNative {
    init {
        System.loadLibrary("catcore")
    }

    // versões
    @JvmStatic external fun parseVersionManifest(json: String): String
    @JvmStatic external fun mergeUnlistedVersions(manifestJson: String, unlistedJson: String): String
    @JvmStatic external fun classifyVersion(type: String, aprilFools: Boolean): String
    @JvmStatic external fun compareVersions(a: String, b: String): Int

    // bibliotecas
    @JvmStatic external fun processLibraries(librariesJson: String): String
    @JvmStatic external fun uniqueLibraries(librariesJson: String): String
    @JvmStatic external fun libraryPath(libraryJson: String): String
    @JvmStatic external fun detectLwjglVersion(librariesJson: String): Int
    @JvmStatic external fun planLibraries(librariesJson: String, targetDir: String): String
    @JvmStatic external fun planAssets(indexJson: String, resourcesDir: String, assetsDir: String): String

    // lançamento
    @JvmStatic external fun launchClasspath(paramsJson: String): String
    @JvmStatic external fun jvmArgs(paramsJson: String): String
    @JvmStatic external fun perfJvmArgs(paramsJson: String): String
    @JvmStatic external fun verifyFiles(requestJson: String): String
    @JvmStatic external fun clientArgs(paramsJson: String): String
    @JvmStatic external fun splitPreservingQuotes(input: String): String

    // runtimes
    @JvmStatic external fun loadRuntime(root: String, name: String): String
    @JvmStatic external fun listRuntimes(root: String): String
    @JvmStatic external fun pickRuntime(root: String, major: Int, exact: Boolean): String
    @JvmStatic external fun postPrepareRuntime(root: String, name: String, nativeLibDir: String): String

    /** [onEntry] recebe o nome de cada entrada; devolver `false` cancela a extração. */
    @JvmStatic external fun installRuntime(
        src: String,
        root: String,
        name: String,
        nativeLibDir: String,
        onEntry: ((String) -> Boolean)?
    ): String

    @JvmStatic external fun installRuntimeBinPack(
        universal: String,
        platformBins: String,
        root: String,
        name: String,
        binPackVersion: String,
        nativeLibDir: String,
        onEntry: ((String) -> Boolean)?
    ): String

    // arquivos
    @JvmStatic external fun compareSha1(path: String, expected: String?, default: Boolean): Boolean
    @JvmStatic external fun sha1File(path: String): String

    // downloads
    @JvmStatic external fun newBatchHandle(): Long
    @JvmStatic external fun cancelBatch(handle: Long)
    @JvmStatic external fun releaseBatchHandle(handle: Long)

    /**
     * Executa um lote de downloads (bloqueante). Os callbacks rodam na thread
     * chamadora: [onProgress] recebe `[bytes, totalBytes, arquivos, totalArquivos, velocidade]`
     * e devolve `false` para cancelar; [onFile] recebe o índice do arquivo concluído.
     * Retorna JSON com falhas por arquivo.
     */
    @JvmStatic external fun downloadBatch(
        handle: Long,
        requestsJson: String,
        optionsJson: String,
        onProgress: ((LongArray) -> Boolean)?,
        onFile: ((Int) -> Unit)?
    ): String
}
