# Alterações — Remover TODAS as animações de entrada do CAT Launcher

Copie os arquivos por cima do projeto mantendo os caminhos. NÃO COMPILADO (sem Android SDK/Gradle aqui): rode `./gradlew :CatLauncher:assembleDebug`.

## Como foi feito (global, na raiz)
- `utils/animation/NoEntryAnimations.kt` (NOVO): substitutos de `fadeIn`, `slideInHorizontally/Vertically`, `scaleIn`, `expandIn/Vertically/Horizontally`, `animateContentSize`, `AnimatedVisibility` (entrada padrão = nenhuma) e `Crossfade` (sem fade). Mesmas assinaturas; ~35 arquivos só trocaram o `import`.
- `AnimationUtils.kt`: `getAnimateTween/getEnterTween` agora devolvem `snap()`.
- `SwapTimeline.isSwapClosed()` = sempre `true` (sem deslocamento, fade, escalonamento nem espera entre telas). `rememberSwapTween()` = `snap()`.
- `_Animated.kt`: `Modifier.animated(...)` virou no-op.
- `Animatable(0.95f)` (zoom-in de diálogos/cards, 27 arquivos) -> `Animatable(1f)`; cartões Neon nascem com escala/alpha 1.
- `WelcomeScreen`: título "WELCOME!" aparece completo (sem digitação).
- `Shimmer.kt`: opacidade fixa (sem pulsar).
- `VersionsManageScreen`: removido `.animateItem()`.
- `FmAnimations.FADE_IN_MS = 0` (gerenciador de arquivos).
- Módulo `Guide`: animações desligadas por padrão; furos/dica/cartão já nascem no estado final.
- `themes.xml` (claro e escuro): tema base do app sem animação de janela (todas as Activities).

## Mantido de propósito
Indicador de progresso da tela Loading, brilho/pulso ambiente dos cartões Neon, cursor piscante do Welcome, animações de toque (pressed) e saídas fora das telas. Dizem respeito a feedback/estado, não a entrada.
