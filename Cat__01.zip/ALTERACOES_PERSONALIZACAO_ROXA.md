# Nova tela "Personalização do Personagem" (layout roxo da imagem de referência)

Arquivos alterados/novos (copie por cima do projeto):
- CatLauncher/src/main/java/.../ui/screens/content/elements/CharacterCustomizer.kt (tela reescrita)
- CatLauncher/src/main/java/.../game/account/wardrobe/CharacterCosmetics.kt (catálogo reescrito)
- CatLauncher/src/main/res/drawable/ic_cc_*.xml (ícones novos)
- CatLauncher/src/main/res/values{,-pt,-pt-rBR}/strings.xml (textos cc_* acrescentados no final)

NÃO COMPILADO/TESTADO: sem Android SDK neste ambiente. Rode ./gradlew :ZalithLauncher:assembleDebug e envie erros.

## Adicionar Conta (integração)
- AccountManageScreen.kt: LocalLoginOperation.Edit (todos os botões "Adicionar Conta") agora abre CharacterCustomizerDialog em modo de criação (createMode = true) no lugar de LocalLoginDialog.
- AccountManageViewModel.kt: novo intent CreateLocalAccountWithLook (salva a conta, aplica skin e capa).
- CharacterCustomizer.kt: campo de nome de usuário (validação + "usar mesmo assim"), Salvar cria a conta.
- strings: cc_username_hint.
