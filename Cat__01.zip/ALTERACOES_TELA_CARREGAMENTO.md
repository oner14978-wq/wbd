# Alterações — Nova tela de carregamento do Cat Launcher

## Arquivos (copie por cima do projeto, mantendo os caminhos)
NOVO
- `CatLauncher/src/main/java/com/movtery/zalithlauncher/ui/screens/content/elements/GameLoadingScreen.kt`

ALTERADOS
- `.../ui/activities/MainActivity.kt` (o diálogo antigo "Iniciar o jogo" deu lugar à `GameLoadingScreen`)
- `.../game/launch/GameLaunchFlow.kt` (pesos por etapa, 100% real e janela da animação final)
- `.../coroutine/TitledTask.kt` (campo opcional `weight`, padrão 1f; não afeta instalações)

## Como funciona
- Aparece só depois de clicar em Jogar (fluxo de lançamento). Instalação/download de versões continua usando o diálogo próprio.
- Porcentagem = progresso real ponderado das etapas: login (1.5), mods (1), verificação/reparo dos arquivos (6), preparo final (1). Nunca regride, mínimo exibido 1%.
- Chega a 100% só quando o preparo termina de verdade. Aí toca a animação final (clarão + pulso + esmaecer, 900 ms) e o Minecraft abre sozinho. O tempo é limitado, então não fica preso em 100%.
- Sem avanço real por 1,5 s: entra a animação de espera (faixa de luz na barra + moldura pulsando). O número não muda.
- Sem botões extras: Voltar (gesto/botão do sistema) cancela o lançamento.

## NÃO TESTADO
Escrito sem Android SDK/Gradle/aparelho: não compilado nem executado. Rode `./gradlew :CatLauncher:assembleDebug` e me envie qualquer erro.
